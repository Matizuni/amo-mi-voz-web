<template>
  <section class="create-resource amv-view-shell">
    <!-- =====================================================
         VOLVER
    ====================================================== -->

    <RouterLink
      to="/aula/recursos"
      class="create-resource__back"
    >
      ← Volver a Recursos
    </RouterLink>

    <!-- =====================================================
         HEADER
    ====================================================== -->

    <header class="create-resource__header">
      <div>
        <p class="create-resource__eyebrow">
          Profesor · Biblioteca
        </p>

        <h1>
          Publicar recurso
        </h1>

        <p class="create-resource__subtitle">
          Sube partituras, audios, documentos y
          material de apoyo para tus estudiantes.
        </p>
      </div>

      <aside class="cloud-status">
        <span>
          SUPABASE
        </span>

        <strong>
          Almacenamiento en línea
        </strong>

        <small>
          Storage + Database
        </small>
      </aside>
    </header>

    <!-- =====================================================
         FORMULARIO
    ====================================================== -->

    <form
      class="resource-form"
      @submit.prevent="publishResource"
    >
      <!-- ===================================================
           01 · INFORMACIÓN
      ==================================================== -->

      <section class="form-section">
        <header class="form-section__header">
          <span>
            01
          </span>

          <div>
            <p>
              Información
            </p>

            <h2>
              Datos del recurso
            </h2>
          </div>
        </header>

        <div class="form-group">
          <label for="title">
            Título
          </label>

          <input
            id="title"
            v-model.trim="form.title"
            type="text"
            required
            placeholder="Ej. Concierto Navidad · Soprano"
          >
        </div>

        <div class="form-group">
          <label for="description">
            Descripción
          </label>

          <textarea
            id="description"
            v-model.trim="form.description"
            rows="5"
            placeholder="Describe para qué sirve este recurso..."
          ></textarea>
        </div>
      </section>

      <!-- ===================================================
           02 · CLASE
      ==================================================== -->

      <section class="form-section">
        <header class="form-section__header">
          <span>
            02
          </span>

          <div>
            <p>
              Programa
            </p>

            <h2>
              Clase asociada
            </h2>
          </div>
        </header>

        <div
          v-if="isLoadingLessons"
          class="lessons-loading"
        >
          Cargando clases...
        </div>

        <div
          v-else-if="lessonsError"
          class="inline-error"
        >
          <span>
            !
          </span>

          <div>
            <strong>
              No pudimos cargar las clases
            </strong>

            <p>
              {{ lessonsError }}
            </p>
          </div>

          <button
            type="button"
            @click="loadLessons"
          >
            Reintentar
          </button>
        </div>

        <div
          v-else
          class="form-group"
        >
          <label for="lesson">
            Clase
          </label>

          <select
            id="lesson"
            v-model.number="form.lessonId"
            required
          >
            <option
              disabled
              value=""
            >
              Selecciona una clase
            </option>

            <option
  v-for="lesson in lessons"
  :key="lesson.id"
  :value="lesson.id"
>
  {{ getLessonOptionLabel(lesson) }}
</option>
          </select>
        </div>
      </section>

      <!-- ===================================================
           03 · TIPO
      ==================================================== -->

      <section class="form-section">
        <header class="form-section__header">
          <span>
            03
          </span>

          <div>
            <p>
              Formato
            </p>

            <h2>
              Tipo de material
            </h2>
          </div>
        </header>

        <div class="type-selector">
          <button
            v-for="type in resourceTypes"
            :key="type.value"
            type="button"
            :class="{
              active:
                form.type === type.value
            }"
            @click="
              form.type = type.value
            "
          >
            <span>
              {{ type.icon }}
            </span>

            <strong>
              {{ type.label }}
            </strong>

            <small>
              {{ type.description }}
            </small>
          </button>
        </div>
      </section>

      <!-- ===================================================
           04 · VOZ
      ==================================================== -->

      <section class="form-section">
        <header class="form-section__header">
          <span>
            04
          </span>

          <div>
            <p>
              Destinatarios
            </p>

            <h2>
              Sección vocal
            </h2>
          </div>
        </header>

        <p class="form-help">
          General será visible para todos.
          Si eliges una cuerda, el recurso podrá
          destacarse para esos estudiantes.
        </p>

        <div class="voice-selector">
          <button
            v-for="voice in voices"
            :key="voice.value"
            type="button"
            :class="{
              active:
                form.voice === voice.value
            }"
            @click="
              form.voice = voice.value
            "
          >
            <span>
              {{ voice.short }}
            </span>

            <strong>
              {{ voice.label }}
            </strong>
          </button>
        </div>
      </section>

      <!-- ===================================================
           05 · ARCHIVO
      ==================================================== -->

      <section class="form-section">
        <header class="form-section__header">
          <span>
            05
          </span>

          <div>
            <p>
              Archivo
            </p>

            <h2>
              Subir material
            </h2>
          </div>
        </header>

        <label
          class="upload-zone"
          :class="{
            'upload-zone--selected':
              selectedFile
          }"
        >
          <input
            type="file"
            :accept="acceptTypes"
            required
            @change="handleFileChange"
          >

          <template v-if="!selectedFile">
            <div class="upload-zone__icon">
              ↑
            </div>

            <strong>
              Selecciona un archivo
            </strong>

            <span>
              PDF, audio, video o documento
            </span>

            <small>
              Tamaño máximo: 100 MB
            </small>
          </template>

          <template v-else>
            <div class="upload-zone__icon">
              ✓
            </div>

            <strong>
              {{ selectedFile.name }}
            </strong>

            <span>
              {{ formatBytes(selectedFile.size) }}
            </span>

            <small>
              {{
                selectedFile.type ||
                'Tipo de archivo desconocido'
              }}
            </small>
          </template>
        </label>

        <button
          v-if="selectedFile"
          type="button"
          class="remove-file"
          @click="clearFile"
        >
          Quitar archivo
        </button>
      </section>

      <!-- ===================================================
           PREVIEW
      ==================================================== -->

      <section class="resource-preview">
        <div class="resource-preview__top">
          <span>
            VISTA PREVIA
          </span>

          <span>
            {{
              getVoiceLabel(
                form.voice
              )
            }}
          </span>
        </div>

        <div class="resource-preview__content">
          <div class="resource-preview__icon">
            {{
              getTypeIcon(
                form.type
              )
            }}
          </div>

          <div>
            <small>
              {{
                getTypeLabel(
                  form.type
                )
              }}
            </small>

            <h2>
              {{
                form.title ||
                'Título del recurso'
              }}
            </h2>

            <p>
              {{
                form.description ||
                'Sin descripción.'
              }}
            </p>
          </div>
        </div>

        <div class="resource-preview__meta">
          <span>
  {{ selectedLessonLabel }}
</span>

          <span>
            {{
              getVoiceLabel(
                form.voice
              )
            }}
          </span>

          <span v-if="selectedFile">
            {{
              formatBytes(
                selectedFile.size
              )
            }}
          </span>
        </div>
      </section>

      <!-- ===================================================
           PROGRESO
      ==================================================== -->

      <section
        v-if="isSaving"
        class="upload-progress"
      >
        <div
          class="upload-progress__bar"
        >
          <div
            :style="{
              width:
                `${progress}%`
            }"
          ></div>
        </div>

        <div class="upload-progress__text">
          <strong>
            {{ progressLabel }}
          </strong>

          <span>
            {{ progress }}%
          </span>
        </div>
      </section>

      <!-- ===================================================
           ERROR
      ==================================================== -->

      <section
        v-if="errorMessage"
        class="form-error"
      >
        <span>
          !
        </span>

        <div>
          <strong>
            No pudimos publicar el recurso
          </strong>

          <p>
            {{ errorMessage }}
          </p>
        </div>
      </section>

      <!-- ===================================================
           ACCIONES
      ==================================================== -->

      <footer class="form-actions">
        <RouterLink
          to="/aula/recursos"
          class="cancel-button"
        >
          Cancelar
        </RouterLink>

        <button
          type="submit"
          class="publish-button"
          :disabled="!canPublish"
        >
          {{
            isSaving
              ? 'Publicando...'
              : 'Publicar recurso'
          }}
        </button>
      </footer>
    </form>
  </section>
</template>

<script setup>
import {
  computed,
  onMounted,
  reactive,
  ref
} from 'vue'

import {
  RouterLink,
  useRouter
} from 'vue-router'

import {
  supabase
} from '@/lib/supabase'

import {
  fetchLessons
} from '@/services/lessonService'

import {
  insertMaterial
} from '@/services/materialService'

const router = useRouter()

/* =========================================================
   ESTADO
========================================================= */

const lessons =
  ref([])

const isLoadingLessons =
  ref(true)

const lessonsError =
  ref('')

const selectedFile =
  ref(null)

const isSaving =
  ref(false)

const errorMessage =
  ref('')

const progress =
  ref(0)

const progressLabel =
  ref('Preparando archivo...')

/* =========================================================
   FORM
========================================================= */

const form =
  reactive({
    title: '',
    description: '',
    lessonId: '',
    type: 'pdf',
    voice: 'general'
  })

/* =========================================================
   TIPOS
========================================================= */

const resourceTypes = [
  {
    value: 'pdf',
    label: 'PDF',
    icon: 'PDF',
    description:
      'Guías y documentos'
  },
  {
    value: 'score',
    label: 'Partitura',
    icon: '♫',
    description:
      'Material musical'
  },
  {
    value: 'audio',
    label: 'Audio',
    icon: '♪',
    description:
      'Guías vocales'
  },
  {
    value: 'video',
    label: 'Video',
    icon: '▶',
    description:
      'Material audiovisual'
  },
  {
    value: 'other',
    label: 'Otro',
    icon: 'FILE',
    description:
      'Otros archivos'
  }
]

const voices = [
  {
    value: 'general',
    label: 'General',
    short: 'ALL'
  },
  {
    value: 'Soprano',
    label: 'Soprano',
    short: 'S'
  },
  {
    value: 'Alto',
    label: 'Alto',
    short: 'A'
  },
  {
    value: 'Tenor',
    label: 'Tenor',
    short: 'T'
  },
  {
    value: 'Bajo',
    label: 'Bajo',
    short: 'B'
  }
]

/* =========================================================
   CLASES
========================================================= */

const loadLessons =
  async () => {
    isLoadingLessons.value =
      true

    lessonsError.value =
      ''

    try {
      lessons.value =
        await fetchLessons()
    } catch (error) {
      console.error(
        'Error cargando clases:',
        error
      )

      lessonsError.value =
        error?.message ||
        'No se pudieron cargar las clases.'
    } finally {
      isLoadingLessons.value =
        false
    }
  }

  /* =========================================================
   NUMERACIÓN ACADÉMICA DE CLASES
========================================================= */

const getLessonUnitId = lesson => {
  return (
    lesson?.unitId ??
    lesson?.unit_id ??
    null
  )
}

const getLessonPosition = lesson => {
  if (!lesson) {
    return null
  }

  const unitId =
    getLessonUnitId(lesson)

  const unitLessons =
    lessons.value.filter(item => {
      return (
        String(
          getLessonUnitId(item)
        ) ===
        String(unitId)
      )
    })

  const index =
    unitLessons.findIndex(item => {
      return (
        Number(item.id) ===
        Number(lesson.id)
      )
    })

  return index >= 0
    ? index + 1
    : null
}

const cleanLessonTitle = title => {
  return String(title || '')
    .replace(
      /^\s*clase\s+\d+\s*[·\-:]\s*/i,
      ''
    )
    .trim()
}

const getLessonOptionLabel = lesson => {
  const position =
    getLessonPosition(lesson)

  const title =
    cleanLessonTitle(
      lesson?.title
    )

  if (!position) {
    return title || 'Clase'
  }

  return title
    ? `Clase ${position} · ${title}`
    : `Clase ${position}`
}

const selectedLesson =
  computed(() => {
    if (!form.lessonId) {
      return null
    }

    return (
      lessons.value.find(
        lesson =>
          Number(lesson.id) ===
          Number(form.lessonId)
      ) || null
    )
  })

const selectedLessonLabel =
  computed(() => {
    if (!selectedLesson.value) {
      return 'Clase no seleccionada'
    }

    return getLessonOptionLabel(
      selectedLesson.value
    )
  })

/* =========================================================
   ARCHIVO
========================================================= */

const handleFileChange =
  event => {
    const file =
      event.target.files?.[0]

    if (!file) {
      return
    }

    errorMessage.value =
      ''

    const maxSize =
      100 * 1024 * 1024

    if (
      file.size >
      maxSize
    ) {
      errorMessage.value =
        'El archivo supera el límite de 100 MB.'

      event.target.value = ''

      selectedFile.value =
        null

      return
    }

    selectedFile.value =
      file

    /*
     * Podemos sugerir automáticamente
     * el tipo según MIME.
     */

    if (
      file.type ===
      'application/pdf'
    ) {
      if (
        form.type !== 'score'
      ) {
        form.type = 'pdf'
      }
    } else if (
      file.type.startsWith(
        'audio/'
      )
    ) {
      form.type = 'audio'
    } else if (
      file.type.startsWith(
        'video/'
      )
    ) {
      form.type = 'video'
    }
  }

const clearFile = () => {
  selectedFile.value =
    null
}

/* =========================================================
   PUBLICAR
========================================================= */

const publishResource =
  async () => {
    if (
      !canPublish.value
    ) {
      return
    }

    const file =
      selectedFile.value

    isSaving.value =
      true

    errorMessage.value =
      ''

    progress.value = 10

    progressLabel.value =
      'Preparando archivo...'

    let uploadedStoragePath =
      ''

    try {
      /* ===============================================
         1. NOMBRE SEGURO
      ================================================ */

      const safeFileName =
        sanitizeFileName(
          file.name
        )

      const voiceFolder =
        String(
          form.voice ||
          'general'
        )
          .toLowerCase()
          .replace(/\s+/g, '-')

      const storagePath =
        [
          `clase-${form.lessonId}`,
          voiceFolder,
          `${Date.now()}-${safeFileName}`
        ].join('/')

      uploadedStoragePath =
        storagePath

      /* ===============================================
         2. STORAGE
      ================================================ */

      progress.value = 30

      progressLabel.value =
        'Subiendo archivo...'

      const {
        data: uploadData,
        error: uploadError
      } = await supabase
        .storage
        .from(
          'aula-materiales'
        )
        .upload(
          storagePath,
          file,
          {
            cacheControl:
              '3600',

            upsert:
              false,

            contentType:
              file.type ||
              undefined
          }
        )

      if (uploadError) {
        throw uploadError
      }

      progress.value = 65

      progressLabel.value =
        'Creando enlace...'

      /* ===============================================
         3. URL PÚBLICA
      ================================================ */

      const {
        data: publicUrlData
      } = supabase
        .storage
        .from(
          'aula-materiales'
        )
        .getPublicUrl(
          uploadData.path
        )

      const publicUrl =
        publicUrlData
          ?.publicUrl

      if (!publicUrl) {
        throw new Error(
          'No se pudo generar la URL pública del archivo.'
        )
      }

      /* ===============================================
         4. DATABASE
      ================================================ */

      progress.value = 80

      progressLabel.value =
        'Guardando recurso...'

      const createdMaterial =
        await insertMaterial({
          lessonId:
            Number(
              form.lessonId
            ),

          type:
            form.type,

          voice:
            form.voice,

          title:
            form.title.trim(),

          description:
            form.description.trim(),

          url:
            publicUrl,

          storagePath:
            uploadData.path,

          fileName:
            file.name,

          fileSize:
            file.size,

          mimeType:
            file.type
        })

      console.log(
        'Recurso guardado:',
        createdMaterial
      )

      progress.value = 100

      progressLabel.value =
        'Recurso publicado'

      setTimeout(() => {
        router.push(
          '/aula/recursos'
        )
      }, 500)
    } catch (error) {
      console.error(
        'Error publicando recurso:',
        error
      )

      /*
       * Si el archivo llegó a Storage
       * pero falló Database,
       * intentamos eliminarlo.
       */

      if (
        uploadedStoragePath
      ) {
        try {
          await supabase
            .storage
            .from(
              'aula-materiales'
            )
            .remove([
              uploadedStoragePath
            ])
        } catch (
          cleanupError
        ) {
          console.error(
            'Error limpiando archivo huérfano:',
            cleanupError
          )
        }
      }

      errorMessage.value =
        error?.message ||
        'No se pudo publicar el recurso.'

      progress.value = 0
    } finally {
      isSaving.value =
        false
    }
  }

/* =========================================================
   VALIDACIÓN
========================================================= */

const canPublish =
  computed(() => {
    return Boolean(
      !isSaving.value &&
      form.title.trim() &&
      form.lessonId &&
      form.type &&
      form.voice &&
      selectedFile.value
    )
  })

/* =========================================================
   ACCEPT
========================================================= */

const acceptTypes =
  computed(() => {
    const accepts = {
      pdf:
        '.pdf,application/pdf',

      score:
        '.pdf,application/pdf',

      audio:
        'audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac',

      video:
        'video/*,.mp4,.webm,.mov,.m4v',

      other:
        '*/*'
    }

    return (
      accepts[form.type] ||
      '*/*'
    )
  })

/* =========================================================
   HELPERS
========================================================= */

const sanitizeFileName =
  fileName => {
    return String(fileName)
      .normalize('NFD')
      .replace(
        /[\u0300-\u036f]/g,
        ''
      )
      .replace(
        /[^a-zA-Z0-9._-]/g,
        '-'
      )
      .replace(
        /-+/g,
        '-'
      )
  }

const getTypeLabel = type => {
  return (
    resourceTypes.find(
      item =>
        item.value === type
    )?.label ||
    'Material'
  )
}

const getTypeIcon = type => {
  return (
    resourceTypes.find(
      item =>
        item.value === type
    )?.icon ||
    'FILE'
  )
}

const getVoiceLabel = voice => {
  return (
    voices.find(
      item =>
        item.value === voice
    )?.label ||
    'General'
  )
}

const formatBytes = bytes => {
  const value =
    Number(bytes)

  if (!value) {
    return '0 B'
  }

  if (value < 1024) {
    return `${value} B`
  }

  if (
    value <
    1024 * 1024
  ) {
    return `${(
      value /
      1024
    ).toFixed(1)} KB`
  }

  return `${(
    value /
    (1024 * 1024)
  ).toFixed(1)} MB`
}

/* =========================================================
   INIT
========================================================= */

onMounted(() => {
  loadLessons()
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/abstracts/variables' as variables;

/* =========================================================
   BASE
========================================================= */

.create-resource {
  width: 100%;
  max-width: 1050px;
  margin: 0 auto;
}

.create-resource__back {
  display: inline-block;
  margin-bottom:
    variables.$spacing-xl;
  color:
    variables.$color-primary;
  font-weight:
    variables.$font-weight-semibold;
  text-decoration: none;
}

/* =========================================================
   HEADER
========================================================= */

.create-resource__header {
  display: flex;
  gap:
    variables.$spacing-2xl;
  align-items: flex-end;
  justify-content: space-between;
  margin-bottom:
    variables.$spacing-3xl;
}

.create-resource__header > div {
  max-width: 800px;
}

.create-resource__eyebrow {
  margin-bottom:
    variables.$spacing-sm;
  color:
    variables.$color-primary;
  font-size:
    variables.$font-size-sm;
  font-weight:
    variables.$font-weight-semibold;
  letter-spacing: 0.15em;
  text-transform: uppercase;
}

.create-resource__header h1 {
  margin-bottom:
    variables.$spacing-md;
  font-size:
    clamp(
      3rem,
      6vw,
      5rem
    );
}

.create-resource__subtitle {
  max-width: 700px;
  line-height: 1.6;
  opacity: 0.6;
}

.cloud-status {
  min-width: 210px;
  padding:
    variables.$spacing-lg;
  border:
    1px solid
    variables.$color-primary;
  border-radius:
    variables.$radius-lg;
  background:
    variables.$color-surface;
}

.cloud-status span,
.cloud-status strong,
.cloud-status small {
  display: block;
}

.cloud-status span {
  margin-bottom: 5px;
  color:
    variables.$color-primary;
  font-size:
    variables.$font-size-xs;
  letter-spacing: 0.12em;
}

.cloud-status small {
  margin-top: 5px;
  opacity: 0.45;
}

/* =========================================================
   FORM
========================================================= */

.resource-form {
  display: grid;
  gap:
    variables.$spacing-xl;
}

.form-section {
  padding:
    variables.$spacing-2xl;
  border:
    1px solid
    variables.$color-border;
  border-radius:
    variables.$radius-lg;
  background:
    variables.$color-surface;
}

.form-section__header {
  display: flex;
  gap:
    variables.$spacing-md;
  align-items: center;
  margin-bottom:
    variables.$spacing-xl;
}

.form-section__header > span {
  display: grid;
  width: 48px;
  height: 48px;
  flex-shrink: 0;
  place-items: center;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 50%;
  color:
    variables.$color-primary;
}

.form-section__header p {
  margin: 0;
  color:
    variables.$color-primary;
  font-size:
    variables.$font-size-xs;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}

.form-section__header h2 {
  margin:
    3px
    0
    0;
}

.form-group {
  display: grid;
  gap:
    variables.$spacing-sm;
  margin-bottom:
    variables.$spacing-lg;
}

.form-group:last-child {
  margin-bottom: 0;
}

.form-group label {
  color:
    variables.$color-primary;
  font-size:
    variables.$font-size-sm;
  font-weight:
    variables.$font-weight-semibold;
}

.form-group input,
.form-group textarea,
.form-group select {
  width: 100%;
  padding:
    variables.$spacing-md;
  border:
    1px solid
    variables.$color-border;
  border-radius:
    variables.$radius-lg;
  outline: none;
  background:
    variables.$color-background;
  color:
    variables.$color-white;
  font: inherit;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
  border-color:
    variables.$color-primary;
}

.form-group textarea {
  line-height: 1.6;
  resize: vertical;
}

.form-help {
  margin:
    0
    0
    variables.$spacing-lg;
  line-height: 1.55;
  opacity: 0.5;
}

/* =========================================================
   TIPOS
========================================================= */

.type-selector {
  display: grid;
  gap: 10px;
  grid-template-columns:
    repeat(
      5,
      minmax(0, 1fr)
    );
}

.type-selector button {
  display: grid;
  gap: 7px;
  min-height: 130px;
  padding:
    variables.$spacing-md;
  place-items: center;
  border:
    1px solid
    variables.$color-border;
  border-radius:
    variables.$radius-lg;
  background:
    variables.$color-background;
  color:
    variables.$color-white;
  font: inherit;
  cursor: pointer;
  opacity: 0.55;
}

.type-selector button.active {
  border-color:
    variables.$color-primary;
  color:
    variables.$color-primary;
  opacity: 1;
}

.type-selector button > span {
  display: grid;
  width: 44px;
  height: 44px;
  place-items: center;
  border:
    1px solid
    currentColor;
  border-radius: 50%;
  font-size: 0.7rem;
}

.type-selector small {
  text-align: center;
}

/* =========================================================
   VOZ
========================================================= */

.voice-selector {
  display: grid;
  gap: 10px;
  grid-template-columns:
    repeat(
      5,
      minmax(0, 1fr)
    );
}

.voice-selector button {
  display: grid;
  gap: 7px;
  padding:
    variables.$spacing-md;
  place-items: center;
  border:
    1px solid
    variables.$color-border;
  border-radius:
    variables.$radius-lg;
  background:
    variables.$color-background;
  color:
    variables.$color-white;
  font: inherit;
  cursor: pointer;
  opacity: 0.55;
}

.voice-selector button.active {
  border-color:
    variables.$color-primary;
  color:
    variables.$color-primary;
  opacity: 1;
}

.voice-selector button span {
  display: grid;
  min-width: 38px;
  height: 38px;
  padding:
    0
    5px;
  place-items: center;
  border:
    1px solid
    currentColor;
  border-radius: 50%;
}

/* =========================================================
   UPLOAD
========================================================= */

.upload-zone {
  display: grid;
  min-height: 260px;
  gap: 8px;
  place-items: center;
  align-content: center;
  padding:
    variables.$spacing-xl;
  border:
    1px dashed
    variables.$color-border;
  border-radius:
    variables.$radius-lg;
  background:
    variables.$color-background;
  text-align: center;
  cursor: pointer;
}

.upload-zone:hover,
.upload-zone--selected {
  border-color:
    variables.$color-primary;
}

.upload-zone input {
  display: none;
}

.upload-zone__icon {
  display: grid;
  width: 70px;
  height: 70px;
  margin-bottom: 8px;
  place-items: center;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-size: 1.8rem;
}

.upload-zone > span,
.upload-zone > small {
  opacity: 0.5;
}

.remove-file {
  margin-top:
    variables.$spacing-md;
  padding: 0;
  border: 0;
  background: transparent;
  color: #ff7777;
  font: inherit;
  cursor: pointer;
}

/* =========================================================
   PREVIEW
========================================================= */

.resource-preview {
  padding:
    variables.$spacing-2xl;
  border:
    1px solid
    variables.$color-primary;
  border-radius:
    variables.$radius-lg;
  background:
    radial-gradient(
      circle at 90% 10%,
      rgba(
        variables.$color-primary,
        0.13
      ),
      transparent 35%
    ),
    variables.$color-surface;
}

.resource-preview__top {
  display: flex;
  justify-content: space-between;
  margin-bottom:
    variables.$spacing-xl;
}

.resource-preview__top span {
  color:
    variables.$color-primary;
  font-size:
    variables.$font-size-xs;
  letter-spacing: 0.1em;
}

.resource-preview__content {
  display: grid;
  gap:
    variables.$spacing-lg;
  align-items: center;
  grid-template-columns:
    auto
    1fr;
}

.resource-preview__icon {
  display: grid;
  width: 70px;
  height: 70px;
  place-items: center;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 50%;
  color:
    variables.$color-primary;
}

.resource-preview__content small {
  color:
    variables.$color-primary;
}

.resource-preview__content h2 {
  margin:
    5px
    0;
}

.resource-preview__content p {
  margin: 0;
  opacity: 0.55;
}

.resource-preview__meta {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-top:
    variables.$spacing-xl;
}

.resource-preview__meta span {
  padding:
    5px
    9px;
  border:
    1px solid
    variables.$color-border;
  border-radius: 999px;
  font-size:
    variables.$font-size-xs;
  opacity: 0.6;
}

/* =========================================================
   PROGRESO
========================================================= */

.upload-progress {
  padding:
    variables.$spacing-lg;
  border:
    1px solid
    variables.$color-border;
  border-radius:
    variables.$radius-lg;
  background:
    variables.$color-surface;
}

.upload-progress__bar {
  height: 6px;
  overflow: hidden;
  border-radius: 999px;
  background:
    variables.$color-background;
}

.upload-progress__bar div {
  height: 100%;
  border-radius: inherit;
  background:
    variables.$color-primary;
  transition:
    width
    0.2s ease;
}

.upload-progress__text {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.upload-progress__text strong {
  color:
    variables.$color-primary;
}

/* =========================================================
   ERROR
========================================================= */

.form-error,
.inline-error {
  display: flex;
  gap:
    variables.$spacing-md;
  align-items: center;
  padding:
    variables.$spacing-lg;
  border:
    1px solid
    #d85151;
  border-radius:
    variables.$radius-lg;
  background:
    rgba(
      216,
      81,
      81,
      0.06
    );
}

.form-error > span,
.inline-error > span {
  display: grid;
  width: 35px;
  height: 35px;
  flex-shrink: 0;
  place-items: center;
  border:
    1px solid
    #d85151;
  border-radius: 50%;
  color: #ff7777;
}

.form-error strong,
.inline-error strong {
  color: #ff7777;
}

.form-error p,
.inline-error p {
  margin:
    4px
    0
    0;
  opacity: 0.65;
}

.inline-error button {
  margin-left: auto;
  padding:
    8px
    12px;
  border:
    1px solid
    #d85151;
  border-radius:
    variables.$radius-lg;
  background: transparent;
  color: #ff7777;
  font: inherit;
  cursor: pointer;
}

.lessons-loading {
  opacity: 0.5;
}

/* =========================================================
   ACTIONS
========================================================= */

.form-actions {
  display: flex;
  gap:
    variables.$spacing-md;
  justify-content: flex-end;
  padding:
    variables.$spacing-md;
  border:
    1px solid
    variables.$color-border;
  border-radius:
    variables.$radius-lg;
  background:
    variables.$color-surface;
}

.cancel-button,
.publish-button {
  padding:
    variables.$spacing-md
    variables.$spacing-xl;
  border-radius:
    variables.$radius-lg;
  font: inherit;
  font-weight:
    variables.$font-weight-semibold;
  text-decoration: none;
  cursor: pointer;
}

.cancel-button {
  border:
    1px solid
    variables.$color-border;
  background: transparent;
  color:
    variables.$color-white;
}

.publish-button {
  border:
    1px solid
    variables.$color-primary;
  background:
    variables.$color-primary;
  color:
    variables.$color-white;
}

.publish-button:disabled {
  opacity: 0.35;
  cursor: default;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {
  .create-resource__header {
    align-items: stretch;
    flex-direction: column;
  }

  .cloud-status {
    width: 100%;
  }

  .type-selector {
    grid-template-columns:
      repeat(
        2,
        minmax(0, 1fr)
      );
  }

  .voice-selector {
    grid-template-columns:
      repeat(
        2,
        minmax(0, 1fr)
      );
  }
}

@media (max-width: 650px) {
  .form-section,
  .resource-preview {
    padding:
      variables.$spacing-xl;
  }

  .type-selector,
  .voice-selector {
    grid-template-columns: 1fr;
  }

  .resource-preview__content {
    grid-template-columns: 1fr;
  }

  .form-actions {
    flex-direction: column;
  }

  .cancel-button,
  .publish-button {
    width: 100%;
    text-align: center;
  }
}


/* =========================================================
   V6.2 · PUBLICAR RECURSO · PREMIUM LIGHT LMS
   Corrige superficies oscuras heredadas del tema global
========================================================= */

.create-resource {
  --cr-ink: #152033;
  --cr-ink-soft: #344359;
  --cr-muted: #6f7c8f;
  --cr-line: #dbe3ec;
  --cr-line-strong: #cbd6e2;
  --cr-surface: #ffffff;
  --cr-surface-soft: #f7f9fc;
  --cr-wine: #9f1945;
  --cr-wine-dark: #7f1237;
  --cr-gold: #d9a91d;
  --cr-gold-dark: #987000;
  --cr-gold-soft: #fff8e7;
  --cr-red: #be4856;
  --cr-red-soft: #fff3f5;

  color: var(--cr-ink);
}

/* Volver */
.create-resource .create-resource__back {
  color: var(--cr-gold-dark) !important;
}

.create-resource .create-resource__back:hover {
  color: var(--cr-wine) !important;
}

/* Header */
.create-resource .create-resource__eyebrow {
  color: var(--cr-gold-dark) !important;
}

.create-resource .create-resource__header h1 {
  color: var(--cr-ink) !important;
}

.create-resource .create-resource__subtitle {
  color: var(--cr-muted) !important;
  opacity: 1 !important;
}

.create-resource .cloud-status {
  border-color: #ead79c !important;
  background: linear-gradient(145deg, #ffffff, #fffaf0) !important;
  box-shadow: 0 8px 22px rgba(31, 48, 73, 0.045) !important;
}

.create-resource .cloud-status span {
  color: var(--cr-gold-dark) !important;
}

.create-resource .cloud-status strong {
  color: var(--cr-ink) !important;
}

.create-resource .cloud-status small {
  color: var(--cr-muted) !important;
  opacity: 1 !important;
}

/* Secciones */
.create-resource .form-section {
  border-color: var(--cr-line) !important;
  background: var(--cr-surface) !important;
  box-shadow: 0 9px 26px rgba(31, 48, 73, 0.04) !important;
}

.create-resource .form-section__header {
  padding-bottom: 16px;
  border-bottom: 1px solid #edf1f5;
}

.create-resource .form-section__header > span {
  border-color: #e5c35a !important;
  background: var(--cr-gold-soft) !important;
  color: var(--cr-gold-dark) !important;
}

.create-resource .form-section__header p {
  color: var(--cr-gold-dark) !important;
}

.create-resource .form-section__header h2 {
  color: var(--cr-ink) !important;
}

/* Campos */
.create-resource .form-group label {
  color: var(--cr-ink-soft) !important;
}

.create-resource .form-group input,
.create-resource .form-group textarea,
.create-resource .form-group select {
  border-color: var(--cr-line) !important;
  background: #ffffff !important;
  color: var(--cr-ink) !important;
  box-shadow: inset 0 1px 2px rgba(31, 48, 73, 0.02) !important;
}

.create-resource .form-group input::placeholder,
.create-resource .form-group textarea::placeholder {
  color: #98a2b3 !important;
}

.create-resource .form-group input:hover,
.create-resource .form-group textarea:hover,
.create-resource .form-group select:hover {
  border-color: var(--cr-line-strong) !important;
}

.create-resource .form-group input:focus,
.create-resource .form-group textarea:focus,
.create-resource .form-group select:focus {
  border-color: var(--cr-wine) !important;
  box-shadow: 0 0 0 3px rgba(159, 25, 69, 0.1) !important;
}

.create-resource .form-group select option {
  background: #ffffff;
  color: var(--cr-ink);
}

.create-resource .form-help,
.create-resource .lessons-loading {
  color: var(--cr-muted) !important;
  opacity: 1 !important;
}

/* Tipo de material */
.create-resource .type-selector button {
  border-color: var(--cr-line) !important;
  background: var(--cr-surface-soft) !important;
  color: var(--cr-ink-soft) !important;
  opacity: 1 !important;
}

.create-resource .type-selector button:hover {
  border-color: #d8c16a !important;
  background: #fffdf7 !important;
}

.create-resource .type-selector button.active {
  border-color: #d7ad24 !important;
  background: var(--cr-gold-soft) !important;
  color: var(--cr-gold-dark) !important;
  box-shadow: 0 6px 16px rgba(217, 169, 29, 0.08) !important;
}

.create-resource .type-selector button > span {
  background: #ffffff !important;
}

.create-resource .type-selector small {
  color: inherit !important;
}

/* Sección vocal */
.create-resource .voice-selector button {
  border-color: var(--cr-line) !important;
  background: var(--cr-surface-soft) !important;
  color: var(--cr-ink-soft) !important;
  opacity: 1 !important;
}

.create-resource .voice-selector button:hover {
  border-color: #d8c16a !important;
  background: #fffdf7 !important;
}

.create-resource .voice-selector button.active {
  border-color: #d7ad24 !important;
  background: var(--cr-gold-soft) !important;
  color: var(--cr-gold-dark) !important;
  box-shadow: 0 6px 16px rgba(217, 169, 29, 0.08) !important;
}

.create-resource .voice-selector button span {
  background: #ffffff !important;
}

/* Upload */
.create-resource .upload-zone {
  border-color: #cbd6e2 !important;
  background: #f8fafc !important;
  color: var(--cr-ink-soft) !important;
}

.create-resource .upload-zone:hover,
.create-resource .upload-zone--selected {
  border-color: var(--cr-wine) !important;
  background: #fffafb !important;
}

.create-resource .upload-zone__icon {
  border-color: #d8b443 !important;
  background: var(--cr-gold-soft) !important;
  color: var(--cr-gold-dark) !important;
}

.create-resource .upload-zone > strong {
  color: var(--cr-ink) !important;
}

.create-resource .upload-zone > span,
.create-resource .upload-zone > small {
  color: var(--cr-muted) !important;
  opacity: 1 !important;
}

.create-resource .remove-file {
  color: var(--cr-red) !important;
}

/* Preview */
.create-resource .resource-preview {
  border-color: #ead79c !important;
  background:
    radial-gradient(
      circle at 90% 10%,
      rgba(217, 169, 29, 0.10),
      transparent 35%
    ),
    #ffffff !important;
  box-shadow: 0 9px 26px rgba(31, 48, 73, 0.04) !important;
}

.create-resource .resource-preview__top span {
  color: var(--cr-gold-dark) !important;
}

.create-resource .resource-preview__icon {
  border-color: #d8b443 !important;
  background: var(--cr-gold-soft) !important;
  color: var(--cr-gold-dark) !important;
}

.create-resource .resource-preview__content small {
  color: var(--cr-gold-dark) !important;
}

.create-resource .resource-preview__content h2 {
  color: var(--cr-ink) !important;
}

.create-resource .resource-preview__content p {
  color: var(--cr-muted) !important;
  opacity: 1 !important;
}

.create-resource .resource-preview__meta span {
  border-color: var(--cr-line) !important;
  background: var(--cr-surface-soft) !important;
  color: var(--cr-ink-soft) !important;
  opacity: 1 !important;
}

/* Progreso */
.create-resource .upload-progress {
  border-color: var(--cr-line) !important;
  background: #ffffff !important;
}

.create-resource .upload-progress__bar {
  background: #e9eef4 !important;
}

.create-resource .upload-progress__bar div {
  background: var(--cr-wine) !important;
}

.create-resource .upload-progress__text {
  color: var(--cr-muted) !important;
}

.create-resource .upload-progress__text strong {
  color: var(--cr-wine) !important;
}

/* Error */
.create-resource .form-error,
.create-resource .inline-error {
  border-color: #e5b7bd !important;
  background: var(--cr-red-soft) !important;
  color: var(--cr-ink-soft) !important;
}

.create-resource .form-error > span,
.create-resource .inline-error > span {
  border-color: #d98590 !important;
  color: var(--cr-red) !important;
  background: #ffffff !important;
}

.create-resource .form-error strong,
.create-resource .inline-error strong {
  color: var(--cr-red) !important;
}

.create-resource .form-error p,
.create-resource .inline-error p {
  color: var(--cr-muted) !important;
  opacity: 1 !important;
}

/* Acciones */
.create-resource .form-actions {
  border-color: var(--cr-line) !important;
  background: #ffffff !important;
  box-shadow: 0 8px 22px rgba(31, 48, 73, 0.04) !important;
}

.create-resource .cancel-button {
  border-color: var(--cr-line-strong) !important;
  background: #ffffff !important;
  color: var(--cr-ink-soft) !important;
}

.create-resource .cancel-button:hover {
  background: var(--cr-surface-soft) !important;
  color: var(--cr-wine) !important;
}

.create-resource .publish-button {
  border-color: var(--cr-wine) !important;
  background: var(--cr-wine) !important;
  color: #ffffff !important;
  box-shadow: 0 7px 16px rgba(159, 25, 69, 0.14) !important;
}

.create-resource .publish-button:hover:not(:disabled) {
  border-color: var(--cr-wine-dark) !important;
  background: var(--cr-wine-dark) !important;
}

.create-resource .publish-button:disabled {
  border-color: #e0e6ed !important;
  background: #eef2f6 !important;
  color: #9aa6b5 !important;
  box-shadow: none !important;
  opacity: 1 !important;
}

/* Responsive refinado */
@media (max-width: 900px) {
  .create-resource .cloud-status {
    min-width: 0;
  }
}

@media (max-width: 650px) {
  .create-resource .form-section__header {
    align-items: flex-start;
  }

  .create-resource .form-section__header > span {
    width: 42px;
    height: 42px;
  }
}

</style>


<style lang="scss">
/* AMV UI POLISH 2026 — visual consistency, accessibility and mobile resilience. */
.amv-view-shell {
  --amv-ui-wine: #9f1945;
  --amv-ui-wine-deep: #7f1237;
  --amv-ui-gold: #d9a91d;
  --amv-ui-purple: #7657d9;
  --amv-ui-cyan: #20b8ae;
  --amv-ui-ink: #172033;
  --amv-ui-muted: #6f7c8f;
  --amv-ui-line: rgba(122, 137, 158, 0.20);
  --amv-ui-focus: rgba(159, 25, 69, 0.38);
  --amv-ui-radius-sm: 12px;
  --amv-ui-radius-md: 18px;
  --amv-ui-radius-lg: 26px;
  --amv-ui-shadow: 0 18px 55px rgba(17, 25, 39, 0.09);
  --amv-ui-shadow-hover: 0 22px 65px rgba(17, 25, 39, 0.14);
  position: relative;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  isolation: isolate;
  overflow-x: clip;
  -webkit-tap-highlight-color: transparent;
}

.amv-view-shell::before {
  content: '';
  position: absolute;
  inset: -150px -120px auto auto;
  width: 420px;
  height: 420px;
  pointer-events: none;
  border-radius: 50%;
  background:
    radial-gradient(circle at 35% 35%, rgba(159, 25, 69, 0.10), transparent 52%),
    radial-gradient(circle at 68% 62%, rgba(217, 169, 29, 0.08), transparent 58%);
  filter: blur(6px);
  opacity: 0.82;
  z-index: -1;
}

.amv-view-shell :where(*, *::before, *::after) {
  box-sizing: border-box;
}

.amv-view-shell :where(img, video, svg, canvas) {
  max-width: 100%;
}

.amv-view-shell :where(h1, h2, h3, h4, h5, h6) {
  text-wrap: balance;
}

.amv-view-shell :where(p, li, td, th, label, small) {
  overflow-wrap: anywhere;
}

.amv-view-shell :where(a, button, input, select, textarea, [role='button']) {
  touch-action: manipulation;
}

.amv-view-shell :where(button, input, select, textarea) {
  font: inherit;
}

.amv-view-shell :where(button) {
  min-height: 42px;
}

.amv-view-shell :where(input, select, textarea) {
  max-width: 100%;
}

.amv-view-shell :where(a, button, input, select, textarea, [role='button']):focus-visible {
  outline: 3px solid var(--amv-ui-focus);
  outline-offset: 3px;
}

.amv-view-shell :where(button, [role='button']):disabled,
.amv-view-shell :where(input, select, textarea):disabled {
  cursor: not-allowed;
}

.amv-view-shell :where(.button, .btn, .lux-button, .amv-primary-btn, .amv-secondary-action,
  .primary-action, .secondary-action, .danger-action, .text-link, .action-link,
  .lightbox__close, .lightbox__nav, .today-button, .quick-action) {
  -webkit-user-select: none;
  user-select: none;
}

/* Premium surface language without changing each view's semantic palette. */
.amv-view-shell :where(.card, .panel, .surface, .summary-card, .metric-card,
  .focus-card, .next-class-card, .insight-card, .agenda-card, .quiz-card,
  .resource-card, .student-card, .lesson-card, .task-card, .format-card,
  .production, .sound-console, .state-card, .empty-card, .workspace,
  .profile-card, .profile-panel, .vocal-card, .weighted-student, .weighted-category) {
  border-radius: var(--amv-ui-radius-md);
}

.amv-view-shell :where(.resource-card, .student-card, .lesson-card, .metric-card,
  .focus-card, .next-class-card, .summary-card, .insight-card, .quiz-card,
  .task-card, .format-card, .production, .state-card, .empty-card) {
  transition:
    transform 180ms ease,
    box-shadow 180ms ease,
    border-color 180ms ease,
    background-color 180ms ease;
}

@media (hover: hover) and (pointer: fine) {
  .amv-view-shell :where(.resource-card, .student-card, .lesson-card, .metric-card,
    .focus-card, .next-class-card, .summary-card, .insight-card, .quiz-card,
    .task-card, .format-card, .production):not(.is-disabled):hover {
    transform: translateY(-2px);
  }
}

/* Toolbars wrap rather than squeezing controls into unreadable rows. */
.amv-view-shell :where(.toolbar, .students-toolbar, .calendar-toolbar, .resources-controls,
  .resources-controls__row, .gradebook-legacy-toolbar, .hero-actions, .actions,
  .action-row, .question-actions, .filters, .public-jump-nav, .classes-header__actions,
  .result-action-row, .form-actions, .footer-actions) {
  min-width: 0;
}

.amv-view-shell :where(.table-shell, .quiz-table-wrap, .table-wrap, .grade-table-wrap,
  .data-table-wrap, .scroll-region, .horizontal-scroll) {
  max-width: 100%;
  overflow-x: auto;
  overflow-y: visible;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: thin;
}

.amv-view-shell :where(.table-shell table, .quiz-table-wrap table, .table-wrap table,
  .grade-table-wrap table, .data-table-wrap table) {
  max-width: none;
}

/* Prevent long controls and badges from forcing page-level horizontal overflow. */
.amv-view-shell :where(.badge, .pill, .chip, .status-pill, .source-badge, .event-chip,
  .lesson-detail, .student-card__voice, .student-card__status, .course-kicker,
  .hero-stat, .count, .filename, .meta, .eyebrow) {
  max-width: 100%;
}

/* Dialogs/lightboxes stay usable on short laptop and phone viewports. */
.amv-view-shell :where(.modal, .dialog, .drawer, .lightbox, .lightbox__content,
  .modal__content, .dialog__content, [role='dialog']) {
  max-width: min(100%, 100vw);
}

.amv-view-shell :where(.modal__content, .dialog__content, .lightbox__content,
  [role='dialog']) {
  max-height: calc(100dvh - 28px);
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Public pages: a cleaner editorial frame around content-heavy sections. */
.amv-view-shell :where(.hero, .hero-panel, .calendar-hero, .resources-hero, .amv-hero,
  .students__header, .gradebook__hero, .classes-header, .contact-hero, .training-hero,
  .academy-hero, .inscription-hero) {
  isolation: isolate;
}

.amv-view-shell :where(.hero__grid, .hero-panel__grid, .resources-hero__grid) {
  min-width: 0;
}

/* Mobile-first resilience. Existing view-specific breakpoints still win where more
   specific rules exist, while these defaults catch edge cases and tiny screens. */
@media (max-width: 760px) {
  .amv-view-shell {
    overflow-x: clip;
  }

  .amv-view-shell :where(.hero, .hero-panel, .amv-hero, .calendar-hero,
    .resources-hero, .classes-header, .students__header, .gradebook__hero) {
    border-radius: 22px;
  }

  .amv-view-shell :where(.hero__grid, .hero-panel__grid, .resources-hero__grid,
    .calendar-layout, .quiz-layout, .program-layout, .student-profile__grid,
    .dashboard-grid, .content-grid, .page-grid, .split-layout) {
    grid-template-columns: minmax(0, 1fr) !important;
  }

  .amv-view-shell :where(.hero-actions, .actions, .action-row, .form-actions,
    .footer-actions, .question-actions, .students__header-actions, .hero-stat,
    .calendar-toolbar, .resources-controls__row) {
    flex-wrap: wrap;
  }

  .amv-view-shell :where(.hero-actions > *, .form-actions > *, .footer-actions > *,
    .question-actions > *, .result-action > *, .result-next-step__actions > *) {
    min-width: min(100%, 190px);
  }

  .amv-view-shell :where(.display-title, .page-title, .hero-title, .section-title,
    .hero-panel__title, .amv-hero h1, .calendar-hero h1, .students__header h1,
    .gradebook__hero h1) {
    font-size: clamp(1.8rem, 7vw, 3rem);
    line-height: 1.05;
  }

  .amv-view-shell :where(.metric-grid, .focus-grid, .student-grid, .resource-grid,
    .lessons-list, .quiz-stack, .summary-grid, .insight-row, .calendar-insight-row,
    .format__grid, .sound__grid, .skills__grid, .productions__grid) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .amv-view-shell :where(.students-toolbar, .resources-controls, .calendar-toolbar,
    .gradebook-legacy-toolbar, .classes-header, .section-heading, .profile-actions) {
    gap: 10px;
  }

  .amv-view-shell :where(input, select, textarea, .select, .search-input) {
    min-height: 44px;
  }
}

@media (max-width: 520px) {
  .amv-view-shell :where(.metric-grid, .focus-grid, .student-grid, .resource-grid,
    .lessons-list, .quiz-stack, .summary-grid, .insight-row, .calendar-insight-row,
    .format__grid, .sound__grid, .skills__grid, .productions__grid) {
    grid-template-columns: minmax(0, 1fr);
  }

  .amv-view-shell :where(.hero, .hero-panel, .amv-hero, .calendar-hero,
    .resources-hero, .classes-header, .students__header, .gradebook__hero) {
    border-radius: 18px;
  }

  .amv-view-shell :where(.card, .panel, .surface, .summary-card, .metric-card,
    .focus-card, .next-class-card, .insight-card, .agenda-card, .quiz-card,
    .resource-card, .student-card, .lesson-card, .task-card, .format-card,
    .production, .state-card, .empty-card) {
    border-radius: 16px;
  }

  .amv-view-shell :where(.hero-actions > *, .form-actions > *, .footer-actions > *,
    .question-actions > *, .result-action > *, .result-next-step__actions > *) {
    width: 100%;
    min-width: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .amv-view-shell,
  .amv-view-shell :where(*, *::before, *::after) {
    scroll-behavior: auto !important;
    transition-duration: 0.01ms !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
  }
}
</style>
