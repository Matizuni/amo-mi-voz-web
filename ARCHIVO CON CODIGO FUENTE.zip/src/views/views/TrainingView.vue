<template>

  <main class="training-page amv-view-shell">
    <a class="amv-skip-link" href="#amv-main-content">
      Ir al contenido principal
    </a>

    <!-- =====================================================*
        HERO
*    ====================================================== -->

    <section id="amv-main-content" class="hero">

      <div class="hero__grid"></div>

      <div class="hero__glow"></div>

      <div class="container hero__layout">

        <div class="hero__copy">

          <div class="eyebrow">

            <span></span>

            PROGRAMA FORMATIVO · AMO MI VOZ

          </div>

          <h1>

            Formación musical

            <em>con propósito.</em>

          </h1>

          <p class="hero__lead">

            Un proceso integral para desarrollar la voz,

            comprender la música, fortalecer la interpretación

            y adquirir experiencia artística real.

          </p>

          <div class="hero__actions">

            <RouterLink

              to="/inscripcion"

              class="button button--primary"

            >

              Quiero inscribirme

              <span>→</span>

            </RouterLink>

            <a

              href="#programa"

              class="button button--ghost"

            >

              Conocer el programa

            </a>

          </div>

          <div class="hero__facts">

            <div>

              <small>MODALIDAD</small>

              <strong>Presencial</strong>

            </div>

            <div>

              <small>DÍA</small>

              <strong>Sábados</strong>

            </div>

            <div>

              <small>HORARIO</small>

              <strong>16:00–18:00</strong>

            </div>

            <div>

              <small>SEDE</small>

              <strong>La Calera</strong>

            </div>

          </div>

        </div>

        <!-- ALUMNO 3 -->

        <div class="hero__visual">

          <figure class="hero-photo">

            <img

              :src="student3"

              alt="Estudiante de la Academia de Talentos Amo Mi Voz"

            / decoding="async">

            <div class="photo-shade"></div>

            <figcaption>

              <span>FORMACIÓN ARTÍSTICA</span>

              <strong>

                Aprender haciendo.

              </strong>

            </figcaption>

          </figure>

          <div class="floating-card floating-card--top">

            <span>01</span>

            <div>

              <small>PROCESO</small>

              <strong>Progresivo</strong>

            </div>

          </div>

          <div class="floating-card floating-card--bottom">

            <span>♪</span>

            <div>

              <small>EXPERIENCIA</small>

              <strong>Aula + escenario</strong>

            </div>

          </div>

        </div>

      </div>

    </section>
    <nav class="public-jump-nav" aria-label="Explorar esta página">
      <span>EXPLORAR</span>
        <a href="#programa">Propuesta</a>
        <a href="#pilares-formacion">Pilares</a>
        <a href="#recorrido-formacion">Recorrido</a>
        <a href="#faq-formacion">Preguntas</a>
      <RouterLink to="/inscripcion">Inscribirme →</RouterLink>
    </nav>


    <!-- =====================================================*
        MANIFIESTO
*    ====================================================== -->

    <section

      id="programa"

      class="manifesto"

    >

      <div class="container manifesto__grid">

        <div>

          <span class="eyebrow eyebrow--simple">

            NUESTRA PROPUESTA

          </span>

          <h2 class="display-title">

            Mucho más que

            <em>aprender canciones.</em>

          </h2>

        </div>

        <div class="manifesto__text">

          <p class="manifesto__lead">

            Formarse musicalmente significa aprender

            a escuchar, comprender, experimentar,

            interpretar y comunicar.

          </p>

          <p>

            La técnica vocal, la teoría musical,

            el entrenamiento auditivo, el repertorio

            y la interpretación se integran dentro

            de un mismo proceso.

          </p>

          <p>

            Nuestro objetivo es que el estudiante

            no dependa siempre de alguien que le diga

            qué hacer, sino que progresivamente pueda

            comprender y tomar decisiones musicales.

          </p>

          <div class="manifesto__signature">

            <span></span>

            <strong>

              Comprender la música para expresarla

              con libertad.

            </strong>

          </div>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        HISTORIA VISUAL
*    ====================================================== -->

    <section class="story">

      <div class="container">

        <header class="section-header">

          <div>

            <span class="eyebrow eyebrow--simple">

              EL PROCESO

            </span>

            <h2 class="display-title">

              Primero descubrimos.

              <em>Después construimos.</em>

            </h2>

          </div>

          <p>

            Cada estudiante llega con una historia,

            una voz y objetivos diferentes.

          </p>

        </header>

        <div class="story__grid">

          <!-- ALUMNO 4 -->

          <figure class="story-card story-card--portrait">

            <img

              :src="student4"

              alt="Estudiante durante su proceso vocal"

            / decoding="async">

            <div class="story-card__overlay"></div>

            <figcaption>

              <small>01 · DESCUBRIR</small>

              <strong>

                Conocer

                <em>tu propia voz.</em>

              </strong>

              <p>

                Reconocer fortalezas, necesidades,

                hábitos y posibilidades.

              </p>

            </figcaption>

          </figure>

          <!-- ALUMNO 5 -->

          <figure class="story-card story-card--landscape">

            <img

              :src="student5"

              alt="Actividad formativa en Amo Mi Voz"

            / decoding="async">

            <div class="story-card__overlay"></div>

            <figcaption>

              <small>02 · DESARROLLAR</small>

              <strong>

                Construir herramientas.

              </strong>

              <p>

                Técnica, oído, ritmo,

                musicalidad e interpretación.

              </p>

            </figcaption>

          </figure>

          <article class="story-card story-card--message">

            <span>03</span>

            <small>INTEGRAR</small>

            <h3>

              Lo aprendido

              comienza a convertirse

              <em>en música.</em>

            </h3>

            <p>

              El objetivo no es acumular ejercicios.

              Es poder utilizarlos dentro del repertorio.

            </p>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        PILARES
*    ====================================================== -->

    <section id="pilares-formacion" class="pillars">

      <div class="container">

        <header class="section-header">

          <div>

            <span class="eyebrow eyebrow--simple">

              PILARES FORMATIVOS

            </span>

            <h2 class="display-title">

              Una formación

              <em>integral.</em>

            </h2>

          </div>

          <p>

            Diferentes áreas de aprendizaje

            trabajando para un mismo desarrollo artístico.

          </p>

        </header>

        <div class="pillars__grid">

          <article

            v-for="pillar in pillars"

            :key="pillar.number"

            class="pillar"

          >

            <header>

              <span>

                {{ pillar.number }}

              </span>

              <strong>

                {{ pillar.symbol }}

              </strong>

            </header>

            <h3>

              {{ pillar.title }}

            </h3>

            <p>

              {{ pillar.description }}

            </p>

            <ul>

              <li

                v-for="item in pillar.items"

                :key="item"

              >

                <span>+</span>

                {{ item }}

              </li>

            </ul>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        METODOLOGÍA        ALUMNO 6
*    ====================================================== -->

    <section class="method">

      <div class="container method__grid">

        <div class="method__visual">

          <figure>

            <img

              :src="student6"

              alt="Estudiante participando del proceso de aprendizaje"

            / decoding="async">

            <div class="photo-shade photo-shade--strong"></div>

            <figcaption>

              <small>

                METODOLOGÍA AMO MI VOZ

              </small>

              <strong>

                Comprender.

                <em>Experimentar.</em>

                Aplicar.

              </strong>

            </figcaption>

          </figure>

          <div class="method__badge">

            <strong>05</strong>

            <span>ETAPAS</span>

          </div>

        </div>

        <div class="method__content">

          <span class="eyebrow eyebrow--simple">

            CÓMO APRENDEMOS

          </span>

          <h2 class="display-title">

            Comprender para

            <em>poder hacer.</em>

          </h2>

          <p class="method__lead">

            Cada concepto se presenta de forma comprensible

            y rápidamente comienza a relacionarse

            con experiencias musicales concretas.

          </p>

          <div class="method__steps">

            <article

              v-for="step in methodSteps"

              :key="step.number"

            >

              <span class="method__number">

                {{ step.number }}

              </span>

              <div>

                <small>

                  {{ step.label }}

                </small>

                <h3>

                  {{ step.title }}

                </h3>

                <p>

                  {{ step.description }}

                </p>

              </div>

            </article>

          </div>

          <blockquote>

            <span>“</span>

            <p>

              La teoría adquiere sentido cuando

              puedes escucharla, sentirla y utilizarla.

            </p>

          </blockquote>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        ÁREAS DE APRENDIZAJE
*    ====================================================== -->

    <section class="learning">

      <div class="container">

        <header class="section-header section-header--center">

          <div>

            <span class="eyebrow eyebrow--simple">

              ¿QUÉ APRENDEMOS?

            </span>

            <h2 class="display-title">

              Herramientas que

              <em>se conectan entre sí.</em>

            </h2>

          </div>

          <p>

            Técnica, oído, teoría, interpretación

            y escenario forman parte de una misma experiencia.

          </p>

        </header>

        <div class="learning__grid">

          <article

            v-for="area in learningAreas"

            :key="area.title"

            class="learning-card"

          >

            <span class="learning-card__icon">

              {{ area.icon }}

            </span>

            <div>

              <h3>

                {{ area.title }}

              </h3>

              <p>

                {{ area.description }}

              </p>

            </div>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        RECORRIDO
*    ====================================================== -->

    <section id="recorrido-formacion" class="journey">

      <div class="container">

        <header class="section-header">

          <div>

            <span class="eyebrow eyebrow--simple">

              RECORRIDO DEL ESTUDIANTE

            </span>

            <h2 class="display-title">

              Un proceso

              <em>progresivo.</em>

            </h2>

          </div>

          <p>

            El punto de partida cambia,

            pero la formación mantiene una dirección clara.

          </p>

        </header>

        <div class="journey__grid">

          <article

            v-for="stage in stages"

            :key="stage.number"

          >

            <span class="journey__number">

              {{ stage.number }}

            </span>

            <small>

              {{ stage.label }}

            </small>

            <h3>

              {{ stage.title }}

            </h3>

            <p>

              {{ stage.description }}

            </p>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        CLASE
*    ====================================================== -->

    <section class="classroom">

      <div class="container classroom__grid">

        <div class="classroom__intro">

          <span class="eyebrow eyebrow--simple">

            UNA CLASE AMO MI VOZ

          </span>

          <h2 class="display-title">

            Cada sesión tiene

            <em>un propósito.</em>

          </h2>

          <p>

            La práctica se organiza para conectar

            preparación vocal, conceptos musicales,

            entrenamiento y repertorio.

          </p>

          <div class="classroom__facts">

            <div>

              <small>DÍA</small>

              <strong>Sábados</strong>

            </div>

            <div>

              <small>HORARIO</small>

              <strong>16:00–18:00</strong>

            </div>

            <div>

              <small>MODALIDAD</small>

              <strong>Presencial</strong>

            </div>

            <div>

              <small>SEDE</small>

              <strong>Pueblito Artesanal</strong>

            </div>

          </div>

        </div>

        <div class="classroom__timeline">

          <article

            v-for="block in classBlocks"

            :key="block.number"

          >

            <span>

              {{ block.number }}

            </span>

            <div>

              <small>

                {{ block.label }}

              </small>

              <h3>

                {{ block.title }}

              </h3>

              <p>

                {{ block.description }}

              </p>

            </div>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        ESCENARIO        ALUMNO 7
*    ====================================================== -->

    <section class="stage">

      <div class="stage__glow"></div>

      <div class="container stage__grid">

        <div class="stage__copy">

          <span class="eyebrow eyebrow--simple">

            FORMACIÓN ESCÉNICA

          </span>

          <h2 class="display-title">

            El escenario también

            <em>es parte de la clase.</em>

          </h2>

          <p>

            Aprender música también implica

            aprender a comunicarla.

          </p>

          <p>

            Por eso trabajamos repertorio,

            interpretación, uso de micrófono,

            escucha colectiva, ensayos

            y experiencias reales frente a público.

          </p>

          <div class="tags">

            <span>Interpretación</span>

            <span>Micrófono</span>

            <span>Ensambles</span>

            <span>Conciertos</span>

            <span>Musicales</span>

          </div>

          <div class="stage__statement">

            <span>→</span>

            <p>

              La meta no es solamente cantar correctamente.

              Es poder sostener una interpretación

              y compartirla con otras personas.

            </p>

          </div>

        </div>

        <div class="stage__visual">

          <figure>

            <img

              :src="student7"

              alt="Estudiante durante una experiencia escénica"

            / decoding="async">

            <div class="photo-shade photo-shade--strong"></div>

            <figcaption>

              <small>

                DEL AULA AL ESCENARIO

              </small>

              <strong>

                Prepararse.

                <em>Ensayar.</em>

                Presentarse.

              </strong>

            </figcaption>

          </figure>

          <span class="stage__badge">

            ♪ EXPERIENCIA REAL

          </span>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        OBJETIVOS
*    ====================================================== -->

    <section class="results">

      <div class="container">

        <header class="section-header section-header--center">

          <div>

            <span class="eyebrow eyebrow--simple">

              OBJETIVOS FORMATIVOS

            </span>

            <h2 class="display-title">

              ¿Qué buscamos

              <em>desarrollar?</em>

            </h2>

          </div>

          <p>

            El crecimiento artístico

            es técnico, musical y personal.

          </p>

        </header>

        <div class="results__grid">

          <article

            v-for="result in results"

            :key="result.title"

          >

            <span>

              {{ result.icon }}

            </span>

            <h3>

              {{ result.title }}

            </h3>

            <p>

              {{ result.description }}

            </p>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        COMUNIDAD        ALUMNO 8
*    ====================================================== -->

    <section class="community">

      <div class="container community__grid">

        <figure class="community__photo">

          <img

            :src="student8"

            alt="Estudiante formando parte de la comunidad Amo Mi Voz"

          / decoding="async">

          <div class="photo-shade"></div>

          <figcaption>

            <span>

              COMUNIDAD ARTÍSTICA

            </span>

          </figcaption>

        </figure>

        <div class="community__content">

          <span class="eyebrow eyebrow--simple">

            APRENDER CON OTROS

          </span>

          <h2 class="display-title">

            Crecer también

            <em>es compartir.</em>

          </h2>

          <p>

            La música es una experiencia individual,

            pero también profundamente colectiva.

          </p>

          <p>

            Cantar junto a otros desarrolla escucha,

            responsabilidad, autonomía, respeto

            y conciencia del rol que cada persona

            cumple dentro de un conjunto.

          </p>

          <div class="community__values">

            <span>Escucha</span>

            <span>Respeto</span>

            <span>Colaboración</span>

            <span>Confianza</span>

          </div>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        PARA QUIÉN
*    ====================================================== -->

    <section class="audience">

      <div class="container audience__grid">

        <div>

          <span class="eyebrow eyebrow--simple">

            ¿PARA QUIÉN ES?

          </span>

          <h2 class="display-title">

            No necesitas llegar

            <em>sabiendo.</em>

          </h2>

          <p class="audience__intro">

            Trabajamos desde el punto real

            en el que se encuentra cada estudiante.

          </p>

        </div>

        <div class="audience__list">

          <article

            v-for="person in audiences"

            :key="person.number"

          >

            <span>

              {{ person.number }}

            </span>

            <div>

              <strong>

                {{ person.title }}

              </strong>

              <p>

                {{ person.description }}

              </p>

            </div>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        GRAN CIERRE VISUAL        ALUMNO 9
*    ====================================================== -->

    <section class="closing-photo">

      <img

        :src="student9"

        alt="Experiencia artística de la Academia Amo Mi Voz"

      / decoding="async">

      <div class="closing-photo__overlay"></div>

      <div class="container closing-photo__content">

        <span class="eyebrow">

          <span></span>

          AMO MI VOZ

        </span>

        <h2>

          Aprender música

          <em>viviendo música.</em>

        </h2>

        <p>

          Técnica, conocimiento, interpretación,

          comunidad y escenario formando parte

          de un mismo camino.

        </p>

      </div>

    </section>

    <!-- =====================================================*
        FAQ
*    ====================================================== -->

    <section id="faq-formacion" class="faq">

      <div class="container faq__grid">

        <div>

          <span class="eyebrow eyebrow--simple">

            PREGUNTAS FRECUENTES

          </span>

          <h2 class="display-title">

            Antes de

            <em>comenzar.</em>

          </h2>

        </div>

        <div class="faq__list">

          <article

            v-for="(item, index) in faqs"

            :key="item.question"

          >

            <button

              type="button"

              :aria-expanded="openFaq === index"

              @click="toggleFaq(index)"

            >

              <span>

                {{ item.question }}

              </span>

              <strong>

                {{ openFaq === index ? '−' : '+' }}

              </strong>

            </button>

            <Transition name="faq">

              <div

                v-if="openFaq === index"

                class="faq__answer"

              >

                <p>

                  {{ item.answer }}

                </p>

              </div>

            </Transition>

          </article>

        </div>

      </div>

    </section>

    <!-- =====================================================*
        CTA FINAL
*    ====================================================== -->

    <section class="cta">

      <div class="cta__grid"></div>

      <div class="cta__glow"></div>

      <div class="container cta__content">

        <span class="eyebrow eyebrow--simple">

          TU PROCESO PUEDE COMENZAR AQUÍ

        </span>

        <h2>

          Descubre lo que

          <em>puede hacer tu voz.</em>

        </h2>

        <p>

          Cuéntanos sobre ti y da el primer paso

          hacia tu proceso artístico y musical.

        </p>

        <RouterLink

          to="/inscripcion"

          class="button button--primary button--large"

        >

          Solicitar inscripción

          <span>→</span>

        </RouterLink>

        <small>

          Academia de Talentos Amo Mi Voz · La Calera

        </small>

      </div>

    </section>

      <PublicQuickActions />
  </main>

</template>

<script setup>
import PublicQuickActions from '@/components/public/PublicQuickActions.vue'


import { ref } from 'vue'

import student3 from '@/assets/images/alumno-3.png'

import student4 from '@/assets/images/alumno-4.png'

import student5 from '@/assets/images/alumno-5.png'

import student6 from '@/assets/images/alumno-6.png'

import student7 from '@/assets/images/alumno-7.png'

import student8 from '@/assets/images/alumno-8.png'

import student9 from '@/assets/images/alumno-9.png'

const openFaq = ref(0)

const pillars = [

  {

    number: '01',

    symbol: '◌',

    title: 'Técnica vocal',

    description:

      'Desarrollar la voz desde una práctica consciente, progresiva y saludable.',

    items: [

      'Respiración y apoyo',

      'Coordinación vocal',

      'Resonancia',

      'Afinación',

      'Extensión y comodidad vocal'

    ]

  },

  {

    number: '02',

    symbol: '♪',

    title: 'Teoría musical',

    description:

      'Comprender los elementos que organizan la música para utilizarlos al cantar.',

    items: [

      'Pulso y ritmo',

      'Figuras musicales',

      'Intervalos',

      'Escalas',

      'Lectura musical'

    ]

  },

  {

    number: '03',

    symbol: '≈',

    title: 'Entrenamiento auditivo',

    description:

      'Desarrollar la capacidad de escuchar, reconocer y reproducir elementos musicales.',

    items: [

      'Afinación auditiva',

      'Intervalos',

      'Melodía',

      'Ritmo',

      'Escucha coral'

    ]

  },

  {

    number: '04',

    symbol: '◆',

    title: 'Interpretación',

    description:

      'Transformar una ejecución correcta en una experiencia artística capaz de comunicar.',

    items: [

      'Texto y emoción',

      'Fraseo',

      'Dinámicas',

      'Presencia',

      'Identidad artística'

    ]

  },

  {

    number: '05',

    symbol: '◎',

    title: 'Trabajo coral',

    description:

      'Aprender a escuchar al conjunto, sostener una parte y construir sonido colectivo.',

    items: [

      'Afinación grupal',

      'Empaste',

      'Voces SATB',

      'Balance',

      'Ensamble'

    ]

  },

  {

    number: '06',

    symbol: '▰',

    title: 'Escenario',

    description:

      'Llevar lo aprendido a situaciones reales de ensayo, concierto y presentación.',

    items: [

      'Uso de micrófono',

      'Ensayos generales',

      'Repertorio',

      'Conciertos',

      'Musicales'

    ]

  }

]

const methodSteps = [

  {

    number: '01',

    label: 'COMPRENDER',

    title: 'Descubrimos el concepto',

    description:

      'Entendemos qué estamos trabajando y por qué es importante.'

  },

  {

    number: '02',

    label: 'ESCUCHAR',

    title: 'Lo reconocemos en la música',

    description:

      'Relacionamos los contenidos con referencias auditivas reales.'

  },

  {

    number: '03',

    label: 'EXPERIMENTAR',

    title: 'Lo llevamos al cuerpo y a la voz',

    description:

      'Los ejercicios convierten el conocimiento en experiencia.'

  },

  {

    number: '04',

    label: 'APLICAR',

    title: 'Lo usamos en repertorio',

    description:

      'Las herramientas comienzan a aparecer dentro de canciones.'

  },

  {

    number: '05',

    label: 'PRESENTAR',

    title: 'Lo llevamos al escenario',

    description:

      'Integramos aprendizaje, interpretación y experiencia escénica.'

  }

]

const learningAreas = [

  {

    icon: '♪',

    title: 'Afinación',

    description:

      'Escuchar y controlar con mayor precisión las alturas musicales.'

  },

  {

    icon: '◒',

    title: 'Respiración',

    description:

      'Coordinar aire, apoyo y emisión con mayor estabilidad.'

  },

  {

    icon: '≈',

    title: 'Resonancia',

    description:

      'Explorar la proyección, riqueza y color del sonido.'

  },

  {

    icon: '♩',

    title: 'Ritmo',

    description:

      'Comprender pulso, subdivisión y figuras musicales.'

  },

  {

    icon: '↗',

    title: 'Intervalos',

    description:

      'Reconocer relaciones entre notas y desarrollar oído.'

  },

  {

    icon: 'S',

    title: 'Lectura musical',

    description:

      'Interpretar progresivamente elementos de una partitura.'

  },

  {

    icon: '◉',

    title: 'Interpretación',

    description:

      'Trabajar intención, fraseo, emoción y comunicación.'

  },

  {

    icon: '▰',

    title: 'Micrófono',

    description:

      'Aprender distancia, control dinámico y técnica escénica.'

  },

  {

    icon: 'SATB',

    title: 'Coro',

    description:

      'Desarrollar escucha colectiva, independencia y ensamble.'

  }

]

const stages = [

  {

    number: '01',

    label: 'DESCUBRIR',

    title: 'Conocer tu voz',

    description:

      'Identificamos fortalezas, hábitos y necesidades.'

  },

  {

    number: '02',

    label: 'CONSTRUIR',

    title: 'Crear herramientas',

    description:

      'Desarrollamos técnica, oído y comprensión musical.'

  },

  {

    number: '03',

    label: 'APLICAR',

    title: 'Trabajar repertorio',

    description:

      'Utilizamos las herramientas dentro de canciones.'

  },

  {

    number: '04',

    label: 'INTEGRAR',

    title: 'Cantar con otros',

    description:

      'Aprendemos a sostener nuestro rol dentro del conjunto.'

  },

  {

    number: '05',

    label: 'COMUNICAR',

    title: 'Subir al escenario',

    description:

      'Transformamos el aprendizaje en experiencia artística.'

  }

]

const classBlocks = [

  {

    number: '01',

    label: 'ACTIVACIÓN',

    title: 'Preparación corporal y vocal',

    description:

      'Respiración, coordinación, activación y calentamiento.'

  },

  {

    number: '02',

    label: 'APRENDIZAJE',

    title: 'Concepto técnico o musical',

    description:

      'Estudiamos un contenido específico de forma comprensible.'

  },

  {

    number: '03',

    label: 'ENTRENAMIENTO',

    title: 'Ejercicios y práctica',

    description:

      'Convertimos el concepto en una habilidad concreta.'

  },

  {

    number: '04',

    label: 'REPERTORIO',

    title: 'Aplicación musical',

    description:

      'Llevamos las herramientas directamente a canciones.'

  },

  {

    number: '05',

    label: 'ENSAMBLE',

    title: 'Trabajo colectivo',

    description:

      'Escuchamos, coordinamos y preparamos repertorio grupal.'

  }

]

const results = [

  {

    icon: '01',

    title: 'Conciencia vocal',

    description:

      'Comprender mejor cómo funciona y responde la propia voz.'

  },

  {

    icon: '02',

    title: 'Afinación',

    description:

      'Desarrollar oído, precisión y control melódico.'

  },

  {

    icon: '03',

    title: 'Comprensión musical',

    description:

      'Entender ritmo, melodía, intervalos y lectura.'

  },

  {

    icon: '04',

    title: 'Autonomía',

    description:

      'Aprender herramientas para estudiar por cuenta propia.'

  },

  {

    icon: '05',

    title: 'Confianza escénica',

    description:

      'Interpretar y comunicar con mayor seguridad.'

  },

  {

    icon: '06',

    title: 'Trabajo colectivo',

    description:

      'Desarrollar escucha, responsabilidad y colaboración.'

  }

]

const audiences = [

  {

    number: '01',

    title: 'Personas que están comenzando',

    description:

      'Puedes iniciar sin conocimientos musicales previos.'

  },

  {

    number: '02',

    title: 'Cantantes que quieren avanzar',

    description:

      'Para quienes buscan ordenar y profundizar su formación.'

  },

  {

    number: '03',

    title: 'Personas que quieren ganar seguridad',

    description:

      'Desarrollamos interpretación y confianza escénica progresiva.'

  },

  {

    number: '04',

    title: 'Personas que aman la música',

    description:

      'Transformamos interés y curiosidad en herramientas concretas.'

  }

]

const faqs = [

  {

    question:

      '¿Necesito saber cantar para entrar?',

    answer:

      'No. Trabajamos desde el nivel real de cada estudiante y puedes comenzar sin experiencia previa.'

  },

  {

    question:

      '¿Necesito saber leer partituras?',

    answer:

      'No. La lectura y teoría musical se incorporan progresivamente dentro de las clases.'

  },

  {

    question:

      '¿Las clases son solamente de canto?',

    answer:

      'No. Integramos técnica vocal, teoría musical, entrenamiento auditivo, interpretación, repertorio, trabajo coral y experiencia escénica.'

  },

  {

    question:

      '¿Se realizan presentaciones?',

    answer:

      'Sí. El escenario forma parte del proceso mediante ensayos, conciertos y proyectos artísticos.'

  },

  {

    question:

      '¿Qué pasa después de inscribirme?',

    answer:

      'Recibimos tu solicitud, la revisamos y posteriormente nos ponemos en contacto contigo. Una vez completada la matrícula podrás acceder también al Aula Virtual.'

  }

]

function toggleFaq(index) {

  openFaq.value =

    openFaq.value === index

      ? null

      : index

}

</script>

<style scoped lang="scss">

@use '@/assets/styles/abstracts/variables' as variables;

@use '@/assets/styles/abstracts/mixins' as mixins;

/* =========================================================*
   GLOBAL
*========================================================= */

.training-page {

  --surface: #0d0d0d;

  --surface-soft: #111;

  --border: #292929;

  --muted: #797979;

  min-height: 100vh;

  overflow: hidden;

  color: #f5f5f5;

  background: #080808;

}

.container {

  width: min(1200px, 100%);

  margin: 0 auto;

}

.eyebrow {

  display: flex;

  gap: 9px;

  align-items: center;

  color: variables.$color-primary;

  font-size: 0.63rem;

  font-weight: 900;

  letter-spacing: 0.19em;

  text-transform: uppercase;

}

.eyebrow > span {

  width: 7px;

  height: 7px;

  border-radius: 50%;

  background: variables.$color-primary;

  box-shadow:

    0 0 15px rgba(212, 175, 55, 0.55);

}

.eyebrow--simple {

  display: block;

}

.display-title {

  margin: 17px 0 0;

  font-size:

    clamp(2.8rem, 5vw, 5.1rem);

  line-height: 0.94;

  letter-spacing: -0.06em;

}

.display-title em {

  display: block;

  color: variables.$color-primary;

  font-style: normal;

}

.button {

  display: inline-flex;

  gap: 10px;

  align-items: center;

  justify-content: center;

  min-height: 49px;

  padding: 13px 21px;

  border-radius: 9px;

  font-size: 0.71rem;

  font-weight: 900;

  text-decoration: none;

  transition:

    transform 0.2s ease,

    border-color 0.2s ease,

    box-shadow 0.2s ease;

}

.button:hover {

  transform: translateY(-2px);

}

.button--primary {

  border: 1px solid variables.$color-primary;

  color: #090909;

  background: variables.$color-primary;

}

.button--primary:hover {

  box-shadow:

    0 16px 45px rgba(212, 175, 55, 0.16);

}

.button--ghost {

  border: 1px solid #353535;

  color: #b6b6b6;

  background: transparent;

}

.button--ghost:hover {

  border-color: #555;

}

.button--large {

  min-height: 57px;

  padding: 14px 27px;

}

.photo-shade {

  position: absolute;

  inset: 0;

  background:

    linear-gradient(

      to top,

      rgba(0, 0, 0, 0.9),

      transparent 60%

    );

}

.photo-shade--strong {

  background:

    linear-gradient(

      to top,

      rgba(0, 0, 0, 0.94),

      rgba(0, 0, 0, 0.05) 65%

    );

}

/* =========================================================*
   HERO
*========================================================= */

.hero {

  position: relative;

  padding: 165px 24px 120px;

  background: #090909;

}

.hero__grid {

  position: absolute;

  inset: 0;

  background:

    linear-gradient(

      90deg,

      rgba(255, 255, 255, 0.013) 1px,

      transparent 1px

    ),

    linear-gradient(

      rgba(255, 255, 255, 0.013) 1px,

      transparent 1px

    );

  background-size: 72px 72px;

  mask-image:

    linear-gradient(

      to bottom,

      black,

      transparent 95%

    );

}

.hero__glow {

  position: absolute;

  top: 40px;

  right: -250px;

  width: 700px;

  height: 700px;

  border-radius: 50%;

  background:

    rgba(212, 175, 55, 0.07);

  filter: blur(160px);

}

.hero__layout {

  position: relative;

  z-index: 2;

  display: grid;

  gap: 75px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      minmax(0, 1.1fr)

      minmax(400px, 0.9fr);

    align-items: center;

  }

}

.hero h1 {

  margin: 21px 0 0;

  font-size:

    clamp(3.7rem, 7vw, 7.1rem);

  line-height: 0.88;

  letter-spacing: -0.07em;

}

.hero h1 em {

  display: block;

  color: variables.$color-primary;

  font-style: normal;

}

.hero__lead {

  max-width: 690px;

  margin: 31px 0 0;

  color: #959595;

  font-size: 0.98rem;

  line-height: 1.85;

}

.hero__actions {

  display: flex;

  gap: 10px;

  flex-wrap: wrap;

  margin-top: 34px;

}

.hero__facts {

  display: grid;

  grid-template-columns:

    repeat(4, 1fr);

  gap: 1px;

  overflow: hidden;

  margin-top: 43px;

  border: 1px solid var(--border);

  border-radius: 11px;

  background: var(--border);

}

.hero__facts > div {

  padding: 14px;

  background: #0c0c0c;

}

.hero__facts small,

.hero__facts strong {

  display: block;

}

.hero__facts small {

  margin-bottom: 5px;

  color: #585858;

  font-size: 0.47rem;

  font-weight: 900;

  letter-spacing: 0.12em;

}

.hero__facts strong {

  font-size: 0.66rem;

}

/* =========================================================*
   HERO VISUAL
*========================================================= */

.hero__visual {

  position: relative;

  min-height: 600px;

}

.hero-photo {

  position: absolute;

  overflow: hidden;

  inset: 0 22px 22px 0;

  margin: 0;

  border: 1px solid #303030;

  border-radius: 25px;

  background: #111;

  box-shadow:

    0 50px 110px rgba(0, 0, 0, 0.5);

}

.hero-photo img {

  width: 100%;

  height: 100%;

  object-fit: cover;

  transition:

    transform 0.8s ease;

}

.hero-photo:hover img {

  transform: scale(1.025);

}

.hero-photo figcaption {

  position: absolute;

  z-index: 2;

  right: 29px;

  bottom: 29px;

  left: 29px;

}

.hero-photo figcaption span {

  display: block;

  color: variables.$color-primary;

  font-size: 0.51rem;

  font-weight: 900;

  letter-spacing: 0.16em;

}

.hero-photo figcaption strong {

  display: block;

  margin-top: 7px;

  font-size: 1.25rem;

}

.floating-card {

  position: absolute;

  z-index: 5;

  display: flex;

  gap: 11px;

  align-items: center;

  padding: 12px 15px;

  border:

    1px solid

    rgba(212, 175, 55, 0.23);

  border-radius: 11px;

  background:

    rgba(10, 10, 10, 0.9);

  backdrop-filter: blur(14px);

}

.floating-card > span {

  display: grid;

  width: 33px;

  height: 33px;

  place-items: center;

  border-radius: 50%;

  color: #090909;

  background: variables.$color-primary;

  font-size: 0.55rem;

  font-weight: 900;

}

.floating-card small,

.floating-card strong {

  display: block;

}

.floating-card small {

  color: #636363;

  font-size: 0.44rem;

  font-weight: 900;

}

.floating-card strong {

  margin-top: 2px;

  font-size: 0.64rem;

}

.floating-card--top {

  top: 35px;

  left: -30px;

}

.floating-card--bottom {

  right: 0;

  bottom: 0;

}

/* =========================================================*
   MANIFESTO
*========================================================= */

.manifesto {

  padding: 125px 24px;

}

.manifesto__grid {

  display: grid;

  gap: 70px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      0.9fr 1.1fr;

  }

}

.manifesto__text {

  max-width: 680px;

}

.manifesto__text p {

  color: #7c7c7c;

  font-size: 0.86rem;

  line-height: 1.85;

}

.manifesto__lead {

  margin-top: 0;

  color: #cacaca !important;

  font-size: 1.04rem !important;

}

.manifesto__signature {

  display: flex;

  gap: 15px;

  align-items: center;

  margin-top: 29px;

}

.manifesto__signature > span {

  width: 48px;

  height: 1px;

  background: variables.$color-primary;

}

.manifesto__signature strong {

  color: variables.$color-primary;

  font-size: 0.7rem;

}

/* =========================================================*
   SECTION HEADER
*========================================================= */

.section-header {

  display: grid;

  gap: 30px;

  margin-bottom: 50px;

  @include mixins.respond-to(md) {

    grid-template-columns:

      1fr 0.42fr;

    align-items: end;

  }

}

.section-header > p {

  margin: 0;

  color: #777;

  font-size: 0.78rem;

  line-height: 1.75;

}

.section-header--center {

  grid-template-columns: 1fr;

  justify-items: center;

  text-align: center;

}

.section-header--center > p {

  max-width: 560px;

}

/* =========================================================*
   STORY
*========================================================= */

.story {

  padding: 25px 24px 125px;

}

.story__grid {

  display: grid;

  gap: 13px;

  @include mixins.respond-to(md) {

    grid-template-columns:

      1fr 1fr;

    grid-template-rows:

      320px 320px;

  }

}

.story-card {

  position: relative;

  overflow: hidden;

  min-height: 350px;

  margin: 0;

  border: 1px solid var(--border);

  border-radius: 18px;

}

.story-card--portrait {

  @include mixins.respond-to(md) {

    grid-row: 1 / 3;

  }

}

.story-card img {

  width: 100%;

  height: 100%;

  object-fit: cover;

  transition:

    transform 0.75s ease;

}

.story-card:hover img {

  transform: scale(1.025);

}

.story-card__overlay {

  position: absolute;

  inset: 0;

  background:

    linear-gradient(

      to top,

      rgba(0, 0, 0, 0.92),

      rgba(0, 0, 0, 0.05) 60%

    );

}

.story-card figcaption {

  position: absolute;

  z-index: 2;

  right: 25px;

  bottom: 26px;

  left: 25px;

}

.story-card figcaption small {

  color: variables.$color-primary;

  font-size: 0.5rem;

  font-weight: 900;

  letter-spacing: 0.15em;

}

.story-card figcaption strong {

  display: block;

  margin-top: 8px;

  font-size:

    clamp(1.4rem, 3vw, 2.5rem);

  line-height: 1;

}

.story-card figcaption strong em {

  display: block;

  color: variables.$color-primary;

  font-style: normal;

}

.story-card figcaption p {

  max-width: 430px;

  margin: 10px 0 0;

  color: #aaa;

  font-size: 0.68rem;

  line-height: 1.55;

}

.story-card--message {

  display: flex;

  flex-direction: column;

  justify-content: flex-end;

  padding: 28px;

  background:

    radial-gradient(

      circle at 90% 10%,

      rgba(212, 175, 55, 0.09),

      transparent 40%

    ),

    #101010;

}

.story-card--message > span {

  display: grid;

  width: 42px;

  height: 42px;

  margin-bottom: auto;

  place-items: center;

  border-radius: 50%;

  color: #090909;

  background: variables.$color-primary;

  font-size: 0.58rem;

  font-weight: 900;

}

.story-card--message small {

  color: variables.$color-primary;

  font-size: 0.49rem;

  font-weight: 900;

  letter-spacing: 0.15em;

}

.story-card--message h3 {

  max-width: 500px;

  margin: 9px 0 12px;

  font-size: clamp(1.5rem, 3vw, 2.4rem);

  line-height: 1;

}

.story-card--message h3 em {

  color: variables.$color-primary;

  font-style: normal;

}

.story-card--message p {

  max-width: 490px;

  margin: 0;

  color: #777;

  font-size: 0.68rem;

  line-height: 1.6;

}

/* =========================================================*
   PILLARS
*========================================================= */

.pillars,

.learning,

.classroom,

.results,

.faq {

  padding: 125px 24px;

  background: #0b0b0b;

}

.pillars__grid {

  display: grid;

  gap: 13px;

  @include mixins.respond-to(md) {

    grid-template-columns:

      repeat(2, 1fr);

  }

  @include mixins.respond-to(lg) {

    grid-template-columns:

      repeat(3, 1fr);

  }

}

.pillar {

  padding: 27px;

  border: 1px solid var(--border);

  border-radius: 17px;

  background: #101010;

  transition:

    transform 0.25s ease,

    border-color 0.25s ease;

}

.pillar:hover {

  transform: translateY(-4px);

  border-color:

    rgba(212, 175, 55, 0.3);

}

.pillar header {

  display: flex;

  align-items: center;

  justify-content: space-between;

}

.pillar header > span {

  color: variables.$color-primary;

  font-size: 0.54rem;

  font-weight: 900;

}

.pillar header > strong {

  display: grid;

  width: 37px;

  height: 37px;

  place-items: center;

  border:

    1px solid

    rgba(212, 175, 55, 0.22);

  border-radius: 50%;

  color: variables.$color-primary;

  font-size: 0.62rem;

}

.pillar h3 {

  margin: 24px 0 11px;

  font-size: 1.12rem;

}

.pillar > p {

  min-height: 67px;

  margin: 0;

  color: #777;

  font-size: 0.71rem;

  line-height: 1.65;

}

.pillar ul {

  display: grid;

  gap: 8px;

  margin: 21px 0 0;

  padding: 18px 0 0;

  border-top: 1px solid #262626;

  list-style: none;

}

.pillar li {

  color: #898989;

  font-size: 0.64rem;

}

.pillar li span {

  margin-right: 6px;

  color: variables.$color-primary;

}

/* =========================================================*
   METHOD
*========================================================= */

.method {

  padding: 130px 24px;

}

.method__grid {

  display: grid;

  gap: 75px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      0.9fr 1.1fr;

    align-items: start;

  }

}

.method__visual {

  position: relative;

  @include mixins.respond-to(lg) {

    position: sticky;

    top: 120px;

  }

}

.method__visual figure {

  position: relative;

  overflow: hidden;

  min-height: 720px;

  margin: 0;

  border: 1px solid var(--border);

  border-radius: 23px;

}

.method__visual img {

  width: 100%;

  height: 100%;

  min-height: 720px;

  object-fit: cover;

}

.method__visual figcaption {

  position: absolute;

  z-index: 2;

  right: 30px;

  bottom: 31px;

  left: 30px;

}

.method__visual figcaption small {

  color: variables.$color-primary;

  font-size: 0.49rem;

  font-weight: 900;

  letter-spacing: 0.15em;

}

.method__visual figcaption strong {

  display: block;

  margin-top: 10px;

  font-size: clamp(2rem, 4vw, 3.6rem);

  line-height: 0.97;

}

.method__visual figcaption strong em {

  display: block;

  color: variables.$color-primary;

  font-style: normal;

}

.method__badge {

  position: absolute;

  top: 28px;

  right: -22px;

  display: grid;

  width: 92px;

  height: 92px;

  place-content: center;

  border-radius: 50%;

  color: #090909;

  text-align: center;

  background: variables.$color-primary;

}

.method__badge strong {

  display: block;

  font-size: 1.5rem;

}

.method__badge span {

  display: block;

  font-size: 0.4rem;

  font-weight: 900;

  letter-spacing: 0.12em;

}

.method__lead {

  max-width: 580px;

  margin: 24px 0 30px;

  color: #868686;

  font-size: 0.82rem;

  line-height: 1.8;

}

.method__steps {

  display: grid;

  gap: 10px;

}

.method__steps article {

  display: flex;

  gap: 18px;

  padding: 21px;

  border: 1px solid var(--border);

  border-radius: 14px;

  background: var(--surface);

  transition:

    transform 0.2s ease,

    border-color 0.2s ease;

}

.method__steps article:hover {

  transform: translateX(4px);

  border-color:

    rgba(212, 175, 55, 0.24);

}

.method__number {

  display: grid;

  width: 39px;

  height: 39px;

  flex: 0 0 auto;

  place-items: center;

  border:

    1px solid

    rgba(212, 175, 55, 0.25);

  border-radius: 50%;

  color: variables.$color-primary;

  font-size: 0.53rem;

  font-weight: 900;

}

.method__steps small {

  color: variables.$color-primary;

  font-size: 0.46rem;

  font-weight: 900;

  letter-spacing: 0.13em;

}

.method__steps h3 {

  margin: 6px 0;

  font-size: 0.9rem;

}

.method__steps p {

  margin: 0;

  color: #707070;

  font-size: 0.65rem;

  line-height: 1.6;

}

.method blockquote {

  display: flex;

  gap: 13px;

  margin: 24px 0 0;

  padding: 18px;

  border: 0;

  border-left:

    2px solid

    variables.$color-primary;

  background:

    rgba(212, 175, 55, 0.025);

}

.method blockquote > span {

  color: variables.$color-primary;

  font-size: 1.8rem;

  line-height: 0.8;

}

.method blockquote p {

  margin: 0;

  color: #aaa;

  font-size: 0.72rem;

  font-style: italic;

  line-height: 1.65;

}

/* =========================================================*
   LEARNING
*========================================================= */

.learning__grid {

  display: grid;

  gap: 11px;

  @include mixins.respond-to(md) {

    grid-template-columns:

      repeat(2, 1fr);

  }

  @include mixins.respond-to(lg) {

    grid-template-columns:

      repeat(3, 1fr);

  }

}

.learning-card {

  display: flex;

  gap: 14px;

  padding: 20px;

  border: 1px solid var(--border);

  border-radius: 14px;

  background: #101010;

}

.learning-card__icon {

  display: grid;

  width: 43px;

  height: 43px;

  flex: 0 0 auto;

  place-items: center;

  border:

    1px solid

    rgba(212, 175, 55, 0.24);

  border-radius: 50%;

  color: variables.$color-primary;

  font-size: 0.54rem;

  font-weight: 900;

}

.learning-card h3 {

  margin: 2px 0 6px;

  font-size: 0.81rem;

}

.learning-card p {

  margin: 0;

  color: #707070;

  font-size: 0.63rem;

  line-height: 1.55;

}

/* =========================================================*
   JOURNEY
*========================================================= */

.journey {

  padding: 125px 24px;

}

.journey__grid {

  display: grid;

  gap: 11px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      repeat(5, 1fr);

  }

}

.journey__grid article {

  padding: 22px;

  border: 1px solid var(--border);

  border-radius: 15px;

  background: var(--surface);

}

.journey__number {

  display: grid;

  width: 38px;

  height: 38px;

  margin-bottom: 22px;

  place-items: center;

  border-radius: 50%;

  color: #090909;

  background: variables.$color-primary;

  font-size: 0.54rem;

  font-weight: 900;

}

.journey__grid small {

  color: variables.$color-primary;

  font-size: 0.46rem;

  font-weight: 900;

  letter-spacing: 0.13em;

}

.journey__grid h3 {

  margin: 8px 0 9px;

  font-size: 0.88rem;

}

.journey__grid p {

  margin: 0;

  color: #6d6d6d;

  font-size: 0.63rem;

  line-height: 1.6;

}

/* =========================================================*
   CLASSROOM
*========================================================= */

.classroom__grid {

  display: grid;

  gap: 65px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      0.8fr 1.2fr;

  }

}

.classroom__intro > p {

  max-width: 500px;

  margin-top: 23px;

  color: #787878;

  font-size: 0.79rem;

  line-height: 1.75;

}

.classroom__facts {

  display: grid;

  grid-template-columns:

    repeat(2, 1fr);

  gap: 1px;

  overflow: hidden;

  margin-top: 28px;

  border: 1px solid var(--border);

  border-radius: 11px;

  background: var(--border);

}

.classroom__facts > div {

  padding: 14px;

  background: #0c0c0c;

}

.classroom__facts small,

.classroom__facts strong {

  display: block;

}

.classroom__facts small {

  margin-bottom: 5px;

  color: #575757;

  font-size: 0.45rem;

  font-weight: 900;

  letter-spacing: 0.11em;

}

.classroom__facts strong {

  font-size: 0.64rem;

}

.classroom__timeline {

  display: grid;

  gap: 10px;

}

.classroom__timeline article {

  display: flex;

  gap: 17px;

  padding: 20px;

  border: 1px solid var(--border);

  border-radius: 13px;

  background: #101010;

}

.classroom__timeline article > span {

  display: grid;

  width: 34px;

  height: 34px;

  flex: 0 0 auto;

  place-items: center;

  border:

    1px solid

    rgba(212, 175, 55, 0.24);

  border-radius: 50%;

  color: variables.$color-primary;

  font-size: 0.5rem;

  font-weight: 900;

}

.classroom__timeline small {

  color: variables.$color-primary;

  font-size: 0.45rem;

  font-weight: 900;

  letter-spacing: 0.12em;

}

.classroom__timeline h3 {

  margin: 5px 0;

  font-size: 0.85rem;

}

.classroom__timeline p {

  margin: 0;

  color: #6d6d6d;

  font-size: 0.63rem;

  line-height: 1.55;

}

/* =========================================================*
   STAGE
*========================================================= */

.stage {

  position: relative;

  overflow: hidden;

  padding: 135px 24px;

}

.stage__glow {

  position: absolute;

  top: 50%;

  left: 50%;

  width: 800px;

  height: 700px;

  border-radius: 50%;

  background:

    rgba(212, 175, 55, 0.05);

  transform:

    translate(-50%, -50%);

  filter: blur(170px);

}

.stage__grid {

  position: relative;

  z-index: 2;

  display: grid;

  gap: 75px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      0.9fr 1.1fr;

    align-items: center;

  }

}

.stage__copy > p {

  max-width: 610px;

  color: #7e7e7e;

  font-size: 0.8rem;

  line-height: 1.8;

}

.tags,

.community__values {

  display: flex;

  gap: 7px;

  flex-wrap: wrap;

  margin-top: 25px;

}

.tags span,

.community__values span {

  padding: 8px 11px;

  border: 1px solid #303030;

  border-radius: 999px;

  color: #888;

  font-size: 0.57rem;

  font-weight: 800;

}

.stage__statement {

  display: flex;

  gap: 12px;

  margin-top: 27px;

  padding: 16px;

  border: 1px solid var(--border);

  border-radius: 11px;

  background: var(--surface);

}

.stage__statement > span {

  color: variables.$color-primary;

}

.stage__statement p {

  margin: 0;

  color: #777;

  font-size: 0.64rem;

  line-height: 1.6;

}

.stage__visual {

  position: relative;

}

.stage__visual figure {

  position: relative;

  overflow: hidden;

  min-height: 650px;

  margin: 0;

  border: 1px solid var(--border);

  border-radius: 24px;

}

.stage__visual img {

  width: 100%;

  height: 100%;

  min-height: 650px;

  object-fit: cover;

}

.stage__visual figcaption {

  position: absolute;

  z-index: 2;

  right: 30px;

  bottom: 30px;

  left: 30px;

}

.stage__visual figcaption small {

  color: variables.$color-primary;

  font-size: 0.48rem;

  font-weight: 900;

  letter-spacing: 0.15em;

}

.stage__visual figcaption strong {

  display: block;

  margin-top: 10px;

  font-size: clamp(2rem, 4vw, 3.7rem);

  line-height: 0.97;

}

.stage__visual figcaption strong em {

  display: block;

  color: variables.$color-primary;

  font-style: normal;

}

.stage__badge {

  position: absolute;

  top: 27px;

  right: -17px;

  padding: 10px 14px;

  border-radius: 999px;

  color: #090909;

  background: variables.$color-primary;

  font-size: 0.47rem;

  font-weight: 900;

  letter-spacing: 0.09em;

}

/* =========================================================*
   RESULTS
*========================================================= */

.results__grid {

  display: grid;

  gap: 11px;

  @include mixins.respond-to(md) {

    grid-template-columns:

      repeat(2, 1fr);

  }

  @include mixins.respond-to(lg) {

    grid-template-columns:

      repeat(3, 1fr);

  }

}

.results__grid article {

  padding: 25px;

  border: 1px solid var(--border);

  border-radius: 15px;

  background: #101010;

}

.results__grid article > span {

  color: variables.$color-primary;

  font-size: 0.52rem;

  font-weight: 900;

}

.results__grid h3 {

  margin: 18px 0 8px;

  font-size: 0.9rem;

}

.results__grid p {

  margin: 0;

  color: #707070;

  font-size: 0.64rem;

  line-height: 1.6;

}

/* =========================================================*
   COMMUNITY
*========================================================= */

.community {

  padding: 130px 24px;

}

.community__grid {

  display: grid;

  gap: 70px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      1.05fr 0.95fr;

    align-items: center;

  }

}

.community__photo {

  position: relative;

  overflow: hidden;

  min-height: 610px;

  margin: 0;

  border: 1px solid var(--border);

  border-radius: 22px;

}

.community__photo img {

  width: 100%;

  height: 100%;

  min-height: 610px;

  object-fit: cover;

}

.community__photo figcaption {

  position: absolute;

  z-index: 2;

  bottom: 25px;

  left: 25px;

}

.community__photo figcaption span {

  color: variables.$color-primary;

  font-size: 0.49rem;

  font-weight: 900;

  letter-spacing: 0.15em;

}

.community__content > p {

  max-width: 560px;

  color: #7c7c7c;

  font-size: 0.8rem;

  line-height: 1.8;

}

/* =========================================================*
   AUDIENCE
*========================================================= */

.audience {

  padding: 125px 24px;

  background: #0b0b0b;

}

.audience__grid {

  display: grid;

  gap: 70px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      0.8fr 1.2fr;

  }

}

.audience__intro {

  max-width: 450px;

  margin-top: 23px;

  color: #777;

  font-size: 0.77rem;

  line-height: 1.75;

}

.audience__list {

  display: grid;

  gap: 10px;

}

.audience__list article {

  display: flex;

  gap: 17px;

  padding: 20px;

  border: 1px solid var(--border);

  border-radius: 13px;

  background: var(--surface);

}

.audience__list article > span {

  color: variables.$color-primary;

  font-size: 0.5rem;

  font-weight: 900;

}

.audience__list strong {

  display: block;

  font-size: 0.78rem;

}

.audience__list p {

  margin: 5px 0 0;

  color: #6d6d6d;

  font-size: 0.64rem;

  line-height: 1.55;

}

/* =========================================================*
   CLOSING PHOTO
*========================================================= */

.closing-photo {

  position: relative;

  min-height: 760px;

  overflow: hidden;

}

.closing-photo > img {

  position: absolute;

  width: 100%;

  height: 100%;

  object-fit: cover;

}

.closing-photo__overlay {

  position: absolute;

  inset: 0;

  background:

    linear-gradient(

      90deg,

      rgba(0, 0, 0, 0.93) 0%,

      rgba(0, 0, 0, 0.68) 44%,

      rgba(0, 0, 0, 0.2) 100%

    );

}

.closing-photo__content {

  position: relative;

  z-index: 2;

  display: flex;

  min-height: 760px;

  flex-direction: column;

  justify-content: center;

  padding: 70px 24px;

}

.closing-photo h2 {

  max-width: 800px;

  margin: 19px 0 0;

  font-size:

    clamp(3rem, 6vw, 6.2rem);

  line-height: 0.9;

  letter-spacing: -0.065em;

}

.closing-photo h2 em {

  display: block;

  color: variables.$color-primary;

  font-style: normal;

}

.closing-photo__content > p {

  max-width: 540px;

  margin-top: 24px;

  color: #aaa;

  font-size: 0.82rem;

  line-height: 1.75;

}

/* =========================================================*
   FAQ
*========================================================= */

.faq__grid {

  display: grid;

  gap: 70px;

  @include mixins.respond-to(lg) {

    grid-template-columns:

      0.7fr 1.3fr;

  }

}

.faq__list {

  border-top: 1px solid var(--border);

}

.faq__list article {

  border-bottom: 1px solid var(--border);

}

.faq__list button {

  display: flex;

  gap: 20px;

  align-items: center;

  justify-content: space-between;

  width: 100%;

  padding: 22px 0;

  border: 0;

  color: #ddd;

  background: transparent;

  font: inherit;

  font-size: 0.75rem;

  font-weight: 800;

  text-align: left;

  cursor: pointer;

}

.faq__list button:hover {

  color: variables.$color-primary;

}

.faq__list button strong {

  color: variables.$color-primary;

  font-size: 1.05rem;

}

.faq__answer {

  overflow: hidden;

}

.faq__answer p {

  max-width: 680px;

  margin: 0;

  padding-bottom: 22px;

  color: #737373;

  font-size: 0.67rem;

  line-height: 1.65;

}

.faq-enter-active,

.faq-leave-active {

  transition:

    opacity 0.2s ease,

    transform 0.2s ease;

}

.faq-enter-from,

.faq-leave-to {

  opacity: 0;

  transform: translateY(-5px);

}

/* =========================================================*
   CTA
*========================================================= */

.cta {

  position: relative;

  overflow: hidden;

  padding: 140px 24px;

  background: #090909;

}

.cta__grid {

  position: absolute;

  inset: 0;

  background:

    linear-gradient(

      90deg,

      rgba(255, 255, 255, 0.012) 1px,

      transparent 1px

    ),

    linear-gradient(

      rgba(255, 255, 255, 0.012) 1px,

      transparent 1px

    );

  background-size: 70px 70px;

}

.cta__glow {

  position: absolute;

  top: 50%;

  left: 50%;

  width: 850px;

  height: 500px;

  border-radius: 50%;

  background:

    rgba(212, 175, 55, 0.075);

  transform:

    translate(-50%, -50%);

  filter: blur(170px);

}

.cta__content {

  position: relative;

  z-index: 2;

  display: grid;

  justify-items: center;

  text-align: center;

}

.cta h2 {

  max-width: 970px;

  margin: 18px 0 0;

  font-size:

    clamp(3.2rem, 7vw, 6.8rem);

  line-height: 0.89;

  letter-spacing: -0.07em;

}

.cta h2 em {

  display: block;

  color: variables.$color-primary;

  font-style: normal;

}

.cta__content > p {

  max-width: 560px;

  margin: 25px 0 30px;

  color: #818181;

  font-size: 0.82rem;

  line-height: 1.7;

}

.cta__content > small {

  margin-top: 20px;

  color: #4f4f4f;

  font-size: 0.49rem;

  font-weight: 800;

  letter-spacing: 0.12em;

  text-transform: uppercase;

}

/* =========================================================*
   RESPONSIVE
*========================================================= */

@media (max-width: 1000px) {

  .hero__visual {

    min-height: 620px;

  }

  .method__visual figure,

  .method__visual img {

    min-height: 600px;

  }

}

@media (max-width: 900px) {

  .hero {

    padding:

      145px 20px

      90px;

  }

  .manifesto,

  .pillars,

  .method,

  .learning,

  .journey,

  .classroom,

  .stage,

  .results,

  .community,

  .audience,

  .faq {

    padding:

      90px 20px;

  }

  .story {

    padding:

      10px 20px

      90px;

  }

  .cta {

    padding:

      110px 20px;

  }

  .closing-photo,

  .closing-photo__content {

    min-height: 620px;

  }

}

@media (max-width: 700px) {

  .hero {

    padding:

      130px 17px

      75px;

  }

  .hero h1 {

    font-size:

      clamp(3rem, 14vw, 5rem);

  }

  .hero__actions {

    flex-direction: column;

  }

  .hero__actions .button {

    width: 100%;

  }

  .hero__facts {

    grid-template-columns:

      repeat(2, 1fr);

  }

  .hero__visual {

    min-height: 500px;

  }

  .hero-photo {

    inset: 0;

  }

  .floating-card--top {

    top: 15px;

    left: 14px;

  }

  .floating-card--bottom {

    right: 14px;

    bottom: 14px;

  }

  .method__badge,

  .stage__badge {

    right: 14px;

  }

  .method__visual figure,

  .method__visual img,

  .stage__visual figure,

  .stage__visual img,

  .community__photo,

  .community__photo img {

    min-height: 500px;

  }

  .closing-photo__overlay {

    background:

      linear-gradient(

        to top,

        rgba(0, 0, 0, 0.94),

        rgba(0, 0, 0, 0.35)

      );

  }

  .classroom__facts {

    grid-template-columns: 1fr;

  }

}

@media (max-width: 520px) {

  .hero__facts {

    grid-template-columns: 1fr;

  }

  .hero__visual {

    min-height: 430px;

  }

  .floating-card {

    padding: 9px 10px;

  }

  .floating-card > span {

    width: 28px;

    height: 28px;

  }

  .pillar {

    padding: 22px;

  }

  .method__steps article,

  .classroom__timeline article,

  .audience__list article {

    padding: 17px;

  }

  .method__visual figure,

  .method__visual img,

  .stage__visual figure,

  .stage__visual img,

  .community__photo,

  .community__photo img {

    min-height: 440px;

  }

  .closing-photo,

  .closing-photo__content {

    min-height: 560px;

  }

}



/* =========================================================
   AMV PUBLIC MAX · 2026
   Diseño institucional light-first + marketing + accesibilidad
========================================================= */

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page) {
  --amv-bg: #f4f6f9;
  --amv-surface: #ffffff;
  --amv-soft: #f8fafc;
  --amv-ink: #152033;
  --amv-copy: #344359;
  --amv-muted: #6f7c8f;
  --amv-line: #dbe3ec;
  --amv-line-strong: #c8d4e1;
  --amv-wine: #9f1945;
  --amv-wine-dark: #771333;
  --amv-wine-soft: #fff1f5;
  --amv-gold: #d5a720;
  --amv-gold-dark: #916b00;
  --amv-gold-soft: #fff8e8;
  --amv-green: #2d8f66;
  --amv-shadow: 0 12px 30px rgba(31,48,73,.055);

  min-height: 100vh !important;
  overflow: clip !important;
  color: var(--amv-ink) !important;
  background: var(--amv-bg) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  :is(a,button,input,select,textarea) {
  -webkit-tap-highlight-color: transparent;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  :focus-visible {
  outline: 3px solid rgba(159,25,69,.28) !important;
  outline-offset: 3px !important;
}

/* HERO: cinematic, pero no toda la web negra */
:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > :is(.hero,.academy-hero) {
  color: #fff !important;
  background:
    radial-gradient(circle at 82% 20%, rgba(159,25,69,.18), transparent 28%),
    linear-gradient(135deg,#101a2d,#18263e) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > :is(.hero,.academy-hero) :is(h1,h2,h3,strong) {
  color: #fff;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > :is(.hero,.academy-hero) :is(em,h1 span) {
  color: #f0c748;
}

/* Navegación contextual — 3 clics / orientación */
.public-jump-nav {
  position: sticky;
  z-index: 70;
  top: 76px;
  display: flex;
  min-height: 58px;
  gap: 4px;
  align-items: center;
  width: min(1180px,calc(100% - 32px));
  margin: -1px auto 0;
  padding: 7px 9px;
  overflow-x: auto;
  border: 1px solid var(--amv-line);
  border-radius: 0 0 15px 15px;
  background: rgba(255,255,255,.96);
  box-shadow: 0 12px 26px rgba(31,48,73,.07);
  backdrop-filter: blur(12px);
  scrollbar-width: none;
}

.public-jump-nav::-webkit-scrollbar { display: none; }

.public-jump-nav > span {
  flex: 0 0 auto;
  padding: 0 9px;
  color: var(--amv-gold-dark);
  font-size: .52rem;
  font-weight: 900;
  letter-spacing: .12em;
}

.public-jump-nav a {
  display: inline-flex;
  min-height: 42px;
  flex: 0 0 auto;
  align-items: center;
  padding: 0 12px;
  border-radius: 9px;
  color: #56657a;
  font-size: .68rem;
  font-weight: 850;
  text-decoration: none;
}

.public-jump-nav a:hover {
  color: var(--amv-wine);
  background: var(--amv-wine-soft);
}

.public-jump-nav a:last-child {
  margin-left: auto;
  color: #fff;
  background: var(--amv-wine);
}

/* Todas las secciones editoriales pasan a superficies claras */
:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero):not(.academy-cta):not(.cta):not(.final-cta) {
  color: var(--amv-ink) !important;
  background: var(--amv-surface) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:nth-of-type(odd):not(.hero):not(.academy-hero):not(.academy-cta):not(.cta):not(.final-cta) {
  background:
    linear-gradient(180deg,#f8fafc,#f3f6f9) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero)
  :is(h2,h3,h4,strong) {
  color: var(--amv-ink);
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero)
  :is(p,li) {
  color: var(--amv-muted);
}

/* Cards heredadas: mismo lenguaje */
:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero)
  [class*="card"]:not([class*="cta"]) {
  border-color: var(--amv-line) !important;
  background: #fff !important;
  color: var(--amv-ink) !important;
  box-shadow: var(--amv-shadow) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero)
  [class*="card"]:not([class*="cta"]) :is(h2,h3,h4,strong) {
  color: var(--amv-ink) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero)
  [class*="card"]:not([class*="cta"]) :is(p,small) {
  color: var(--amv-muted) !important;
}

/* Eyebrows y acentos */
:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero)
  [class*="eyebrow"] {
  color: var(--amv-gold-dark) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > section:not(.hero):not(.academy-hero)
  :is(h1,h2,h3) em {
  color: var(--amv-wine) !important;
}

/* CTAs finales */
:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > :is(.academy-cta,.cta,.final-cta) {
  color: #fff !important;
  background:
    radial-gradient(circle at 85% 10%, rgba(159,25,69,.2), transparent 30%),
    linear-gradient(135deg,#101a2d,#1b2941) !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > :is(.academy-cta,.cta,.final-cta) :is(h2,h3,strong) {
  color: #fff !important;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  > :is(.academy-cta,.cta,.final-cta) p {
  color: rgba(255,255,255,.68) !important;
}

/* Forms */
.inscription-page :is(input,select,textarea),
.contact-page :is(input,select,textarea) {
  min-height: 48px !important;
  border: 1px solid var(--amv-line-strong) !important;
  border-radius: 11px !important;
  color: var(--amv-ink) !important;
  background: #fff !important;
}

.inscription-page textarea,
.contact-page textarea {
  min-height: 130px !important;
}

.inscription-page :is(input,select,textarea):focus,
.contact-page :is(input,select,textarea):focus {
  border-color: var(--amv-wine) !important;
  box-shadow: 0 0 0 4px rgba(159,25,69,.08) !important;
}

/* Buttons */
:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  :is(.button,.academy-button,[class*="button--primary"]) {
  min-height: 46px;
}

:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  :is(.button--primary,.academy-button--primary,.cta__button) {
  border-color: var(--amv-wine) !important;
  color: #fff !important;
  background: var(--amv-wine) !important;
}

/* Mejora lectura en desktop */
:where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
  .container {
  width: min(1180px,100%) !important;
}

/* Scroll target */
:where(
  #formacion-academia,#metodo-academia,#experiencia-academia,#comunidad-academia,
  #canales-contacto,#ubicacion-contacto,#cierre-contacto,
  #historia-galeria,#explorar-galeria,#proceso-galeria,#cierre-galeria,
  #solicitud-inscripcion,#concepto-musicales,#formato-musicales,#producciones,
  #proceso-musicales,#programa,#pilares-formacion,#recorrido-formacion,#faq-formacion
) {
  scroll-margin-top: 150px;
}

@media (max-width: 760px) {
  .public-jump-nav {
    top: 66px;
    width: calc(100% - 20px);
    min-height: 54px;
    padding-inline: 6px;
  }

  .public-jump-nav > span {
    display: none;
  }

  .public-jump-nav a {
    min-height: 44px;
    font-size: .7rem;
  }

  .public-jump-nav a:last-child {
    margin-left: 0;
  }

  :where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page)
    :is(.button,.academy-button,a[class*="button"]) {
    min-height: 48px !important;
  }
}

@media (prefers-reduced-motion: reduce) {
  :where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page) *,
  :where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page) *::before,
  :where(.academy-page,.contact-page,.gallery-page,.inscription-page,.musicals-page,.training-page) *::after {
    scroll-behavior: auto !important;
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
  }
}


/* Training */
.manifesto,.story,.pillars,.method,.learning,.journey,.classroom,.stage,.results,.community,.audience,.faq {
  color: var(--amv-ink) !important;
}
.pillar,
.method__steps article,
.learning article,
.journey article,
.result-card,
.faq-item {
  border-color: var(--amv-line) !important;
  background: #fff !important;
  box-shadow: var(--amv-shadow) !important;
}
.pillar h3,
.method__steps h3,
.faq-item h3 { color: var(--amv-ink) !important; }
.pillar p,
.method__steps p,
.faq-item p { color: var(--amv-muted) !important; }


.amv-skip-link {
  position: fixed;
  z-index: 9999;
  top: 8px;
  left: 8px;
  padding: 10px 14px;
  border-radius: 9px;
  color: #fff !important;
  background: #9f1945;
  font-size: .75rem;
  font-weight: 900;
  text-decoration: none;
  transform: translateY(-150%);
}
.amv-skip-link:focus { transform: translateY(0); }


/* =========================================================
   TRAINING MAX · V2.1
   Corrige restos del tema oscuro heredado.
========================================================= */

/* HERO FACTS: ya no negro puro, ahora glass coherente */
.training-page .hero__facts {
  gap: 8px !important;
  overflow: visible !important;
  border: 0 !important;
  background: transparent !important;
}

.training-page .hero__facts > div {
  border: 1px solid rgba(255,255,255,.14) !important;
  border-radius: 11px !important;
  background: rgba(255,255,255,.08) !important;
  backdrop-filter: blur(10px) !important;
}

.training-page .hero__facts small {
  color: rgba(255,255,255,.58) !important;
}

.training-page .hero__facts strong {
  color: #fff !important;
}

/* CLASE: datos */
.training-page .classroom__facts {
  gap: 8px !important;
  overflow: visible !important;
  border: 0 !important;
  background: transparent !important;
}

.training-page .classroom__facts > div {
  border: 1px solid var(--amv-line) !important;
  border-radius: 11px !important;
  background: #f8fafc !important;
  box-shadow: none !important;
}

.training-page .classroom__facts small {
  color: #7b8798 !important;
}

.training-page .classroom__facts strong {
  color: var(--amv-ink) !important;
}

/* CLASE: pasos */
.training-page .classroom__timeline article {
  border: 1px solid var(--amv-line) !important;
  border-radius: 14px !important;
  background: #fff !important;
  box-shadow: 0 8px 22px rgba(31,48,73,.035) !important;
}

.training-page .classroom__timeline article > span {
  border-color: #e8d58d !important;
  color: var(--amv-gold-dark) !important;
  background: var(--amv-gold-soft) !important;
}

.training-page .classroom__timeline small {
  color: var(--amv-gold-dark) !important;
}

.training-page .classroom__timeline h3 {
  color: var(--amv-ink) !important;
}

.training-page .classroom__timeline p {
  color: var(--amv-muted) !important;
}

/* OBJETIVOS */
.training-page .results {
  background: #f7f9fc !important;
}

.training-page .results .section-header--center {
  text-align: center !important;
}

.training-page .results .display-title {
  color: var(--amv-ink) !important;
  background: transparent !important;
}

.training-page .results .display-title em {
  color: var(--amv-wine) !important;
  background: transparent !important;
}

.training-page .results .section-header--center > p {
  color: var(--amv-muted) !important;
  background: transparent !important;
}

.training-page .results__grid article {
  min-height: 155px !important;
  padding: 22px !important;
  border: 1px solid var(--amv-line) !important;
  border-radius: 15px !important;
  background: #fff !important;
  box-shadow: 0 9px 24px rgba(31,48,73,.04) !important;
}

.training-page .results__grid article > span {
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  border-radius: 10px;
  color: var(--amv-gold-dark) !important;
  background: var(--amv-gold-soft) !important;
  font-size: .52rem !important;
  font-weight: 900 !important;
}

.training-page .results__grid h3 {
  margin: 15px 0 7px !important;
  color: var(--amv-ink) !important;
}

.training-page .results__grid p {
  color: var(--amv-muted) !important;
}

/* PARA QUIÉN */
.training-page .audience {
  background: #fff !important;
}

.training-page .audience__list article {
  border: 1px solid var(--amv-line) !important;
  border-radius: 14px !important;
  background: #fff !important;
  box-shadow: 0 8px 22px rgba(31,48,73,.035) !important;
}

.training-page .audience__list article > span {
  display: grid;
  width: 34px;
  height: 34px;
  flex: 0 0 34px;
  place-items: center;
  border-radius: 10px;
  color: var(--amv-gold-dark) !important;
  background: var(--amv-gold-soft) !important;
}

.training-page .audience__list strong {
  color: var(--amv-ink) !important;
}

.training-page .audience__list p {
  color: var(--amv-muted) !important;
}

.training-page .audience__intro {
  color: var(--amv-muted) !important;
}

/* cualquier superficie oscura residual de estas zonas */
.training-page .classroom :is(
  .classroom__facts > div,
  .classroom__timeline article
),
.training-page .results :is(
  .results__grid article
),
.training-page .audience :is(
  .audience__list article
) {
  background-color: #fff !important;
}

/* responsive */
@media (max-width: 760px) {
  .training-page .hero__facts,
  .training-page .classroom__facts {
    grid-template-columns: repeat(2,minmax(0,1fr)) !important;
  }

  .training-page .classroom__timeline article,
  .training-page .audience__list article {
    padding: 16px !important;
  }

  .training-page .results__grid {
    grid-template-columns: 1fr !important;
  }
}



/* =========================================================
   AMV UI SYSTEM · PUBLIC EXPERIENCE v1.0
   Consistencia, accesibilidad y movimiento fluido
========================================================= */
.training-page {
  --amv-ink: #172033;
  --amv-body: #344359;
  --amv-muted: #667085;
  --amv-wine: #9f1945;
  --amv-wine-dark: #7f1237;
  --amv-gold: #d9a91d;
  --amv-line: #dbe3ec;
  --amv-canvas: #f5f7fb;
  --amv-card: #ffffff;
  --amv-shadow: 0 18px 48px rgba(23, 32, 51, .09);
  --amv-radius: 20px;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
}

.training-page :where(a, button, input, textarea, select) {
  transition: color .22s ease, background-color .22s ease, border-color .22s ease, box-shadow .22s ease, transform .22s ease, opacity .22s ease;
}

.training-page :where(a, button, input, textarea, select):focus-visible {
  outline: 3px solid rgba(159, 25, 69, .22) !important;
  outline-offset: 3px;
}

.training-page :where(button, [role="button"], .button, .btn):not(:disabled):active {
  transform: translateY(1px) scale(.99);
}

.training-page :where(img) {
  transition: transform .45s cubic-bezier(.2,.75,.25,1), filter .35s ease;
}

.training-page :where(article, .card, [class*="__card"]):hover {
  transition: transform .28s cubic-bezier(.2,.75,.25,1), box-shadow .28s ease, border-color .28s ease;
}

.training-page :where(input, textarea, select) {
  font-size: max(16px, 1em);
}

@media (prefers-reduced-motion: reduce) {
  .training-page *, .training-page *::before, .training-page *::after {
    scroll-behavior: auto !important;
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
  }
}


/* =========================================================
   AMV LMS · FLUID MOTION & PREMIUM INTERACTION v2.0
   Capa visual segura: no modifica lógica, datos ni estructura.
========================================================= */
.training-page {
  animation: amvViewEnter .46s cubic-bezier(.2,.75,.25,1) both;
}

.training-page :where(
  article,
  [class$="__card"],
  [class*="-card"],
  [class*="_card"]
) {
  transition:
    transform .24s cubic-bezier(.2,.75,.25,1),
    box-shadow .24s ease,
    border-color .24s ease,
    background-color .24s ease;
}

@media (hover: hover) and (pointer: fine) {
  .training-page :where(
    article,
    [class$="__card"],
    [class*="-card"],
    [class*="_card"]
  ):hover {
    transform: translateY(-2px);
  }

  .training-page :where(
    button,
    .button,
    .btn,
    a[class*="button"],
    a[class*="cta"]
  ):not(:disabled):hover {
    transform: translateY(-2px);
    filter: saturate(1.04);
  }

  .training-page :where(img) {
    transition: transform .55s cubic-bezier(.2,.75,.25,1), filter .35s ease;
  }

  .training-page :where(
    [class*="cover"],
    [class*="hero"],
    [class*="visual"],
    [class*="gallery"]
  ):hover img {
    transform: scale(1.018);
  }
}

.training-page :where(
  button,
  .button,
  .btn,
  a[class*="button"],
  a[class*="cta"]
) {
  will-change: transform;
}

.training-page :where(input, textarea, select):focus {
  transform: translateY(-1px);
}

.training-page :where(
  [class*="progress"] > *,
  [class*="bar"] > *,
  progress
) {
  transition: width .55s cubic-bezier(.2,.75,.25,1), transform .35s ease;
}

.training-page ::selection {
  color: #ffffff;
  background: #9f1945;
}

@keyframes amvViewEnter {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (prefers-reduced-motion: reduce) {
  .training-page,
  .training-page *,
  .training-page *::before,
  .training-page *::after {
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
    scroll-behavior: auto !important;
  }
}

</style>

<style lang="scss">
/* AMV UI POLISH 2026 — visual consistency, accessibility and mobile resilience. */
.amv-view-shell {
  --amv-ui-wine: #9f1945;
  --amv-ui-wine-deep: #7f1237;
  --amv-ui-gold: #d9a91d;
  --amv-ui-purple: #7657d9;
  --amv-ui-cyan: #20b8ae;
  --amv-ui-ink: #172033;
  --amv-ui-muted: #6f7c8f;
  --amv-ui-line: rgba(122, 137, 158, 0.20);
  --amv-ui-focus: rgba(159, 25, 69, 0.38);
  --amv-ui-radius-sm: 12px;
  --amv-ui-radius-md: 18px;
  --amv-ui-radius-lg: 26px;
  --amv-ui-shadow: 0 18px 55px rgba(17, 25, 39, 0.09);
  --amv-ui-shadow-hover: 0 22px 65px rgba(17, 25, 39, 0.14);
  position: relative;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  isolation: isolate;
  overflow-x: clip;
  -webkit-tap-highlight-color: transparent;
}

.amv-view-shell::before {
  content: '';
  position: absolute;
  inset: -150px -120px auto auto;
  width: 420px;
  height: 420px;
  pointer-events: none;
  border-radius: 50%;
  background:
    radial-gradient(circle at 35% 35%, rgba(159, 25, 69, 0.10), transparent 52%),
    radial-gradient(circle at 68% 62%, rgba(217, 169, 29, 0.08), transparent 58%);
  filter: blur(6px);
  opacity: 0.82;
  z-index: -1;
}

.amv-view-shell :where(*, *::before, *::after) {
  box-sizing: border-box;
}

.amv-view-shell :where(img, video, svg, canvas) {
  max-width: 100%;
}

.amv-view-shell :where(h1, h2, h3, h4, h5, h6) {
  text-wrap: balance;
}

.amv-view-shell :where(p, li, td, th, label, small) {
  overflow-wrap: anywhere;
}

.amv-view-shell :where(a, button, input, select, textarea, [role='button']) {
  touch-action: manipulation;
}

.amv-view-shell :where(button, input, select, textarea) {
  font: inherit;
}

.amv-view-shell :where(button) {
  min-height: 42px;
}

.amv-view-shell :where(input, select, textarea) {
  max-width: 100%;
}

.amv-view-shell :where(a, button, input, select, textarea, [role='button']):focus-visible {
  outline: 3px solid var(--amv-ui-focus);
  outline-offset: 3px;
}

.amv-view-shell :where(button, [role='button']):disabled,
.amv-view-shell :where(input, select, textarea):disabled {
  cursor: not-allowed;
}

.amv-view-shell :where(.button, .btn, .lux-button, .amv-primary-btn, .amv-secondary-action,
  .primary-action, .secondary-action, .danger-action, .text-link, .action-link,
  .lightbox__close, .lightbox__nav, .today-button, .quick-action) {
  -webkit-user-select: none;
  user-select: none;
}

/* Premium surface language without changing each view's semantic palette. */
.amv-view-shell :where(.card, .panel, .surface, .summary-card, .metric-card,
  .focus-card, .next-class-card, .insight-card, .agenda-card, .quiz-card,
  .resource-card, .student-card, .lesson-card, .task-card, .format-card,
  .production, .sound-console, .state-card, .empty-card, .workspace,
  .profile-card, .profile-panel, .vocal-card, .weighted-student, .weighted-category) {
  border-radius: var(--amv-ui-radius-md);
}

.amv-view-shell :where(.resource-card, .student-card, .lesson-card, .metric-card,
  .focus-card, .next-class-card, .summary-card, .insight-card, .quiz-card,
  .task-card, .format-card, .production, .state-card, .empty-card) {
  transition:
    transform 180ms ease,
    box-shadow 180ms ease,
    border-color 180ms ease,
    background-color 180ms ease;
}

@media (hover: hover) and (pointer: fine) {
  .amv-view-shell :where(.resource-card, .student-card, .lesson-card, .metric-card,
    .focus-card, .next-class-card, .summary-card, .insight-card, .quiz-card,
    .task-card, .format-card, .production):not(.is-disabled):hover {
    transform: translateY(-2px);
  }
}

/* Toolbars wrap rather than squeezing controls into unreadable rows. */
.amv-view-shell :where(.toolbar, .students-toolbar, .calendar-toolbar, .resources-controls,
  .resources-controls__row, .gradebook-legacy-toolbar, .hero-actions, .actions,
  .action-row, .question-actions, .filters, .public-jump-nav, .classes-header__actions,
  .result-action-row, .form-actions, .footer-actions) {
  min-width: 0;
}

.amv-view-shell :where(.table-shell, .quiz-table-wrap, .table-wrap, .grade-table-wrap,
  .data-table-wrap, .scroll-region, .horizontal-scroll) {
  max-width: 100%;
  overflow-x: auto;
  overflow-y: visible;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: thin;
}

.amv-view-shell :where(.table-shell table, .quiz-table-wrap table, .table-wrap table,
  .grade-table-wrap table, .data-table-wrap table) {
  max-width: none;
}

/* Prevent long controls and badges from forcing page-level horizontal overflow. */
.amv-view-shell :where(.badge, .pill, .chip, .status-pill, .source-badge, .event-chip,
  .lesson-detail, .student-card__voice, .student-card__status, .course-kicker,
  .hero-stat, .count, .filename, .meta, .eyebrow) {
  max-width: 100%;
}

/* Dialogs/lightboxes stay usable on short laptop and phone viewports. */
.amv-view-shell :where(.modal, .dialog, .drawer, .lightbox, .lightbox__content,
  .modal__content, .dialog__content, [role='dialog']) {
  max-width: min(100%, 100vw);
}

.amv-view-shell :where(.modal__content, .dialog__content, .lightbox__content,
  [role='dialog']) {
  max-height: calc(100dvh - 28px);
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Public pages: a cleaner editorial frame around content-heavy sections. */
.amv-view-shell :where(.hero, .hero-panel, .calendar-hero, .resources-hero, .amv-hero,
  .students__header, .gradebook__hero, .classes-header, .contact-hero, .training-hero,
  .academy-hero, .inscription-hero) {
  isolation: isolate;
}

.amv-view-shell :where(.hero__grid, .hero-panel__grid, .resources-hero__grid) {
  min-width: 0;
}

/* Mobile-first resilience. Existing view-specific breakpoints still win where more
   specific rules exist, while these defaults catch edge cases and tiny screens. */
@media (max-width: 760px) {
  .amv-view-shell {
    overflow-x: clip;
  }

  .amv-view-shell :where(.hero, .hero-panel, .amv-hero, .calendar-hero,
    .resources-hero, .classes-header, .students__header, .gradebook__hero) {
    border-radius: 22px;
  }

  .amv-view-shell :where(.hero__grid, .hero-panel__grid, .resources-hero__grid,
    .calendar-layout, .quiz-layout, .program-layout, .student-profile__grid,
    .dashboard-grid, .content-grid, .page-grid, .split-layout) {
    grid-template-columns: minmax(0, 1fr) !important;
  }

  .amv-view-shell :where(.hero-actions, .actions, .action-row, .form-actions,
    .footer-actions, .question-actions, .students__header-actions, .hero-stat,
    .calendar-toolbar, .resources-controls__row) {
    flex-wrap: wrap;
  }

  .amv-view-shell :where(.hero-actions > *, .form-actions > *, .footer-actions > *,
    .question-actions > *, .result-action > *, .result-next-step__actions > *) {
    min-width: min(100%, 190px);
  }

  .amv-view-shell :where(.display-title, .page-title, .hero-title, .section-title,
    .hero-panel__title, .amv-hero h1, .calendar-hero h1, .students__header h1,
    .gradebook__hero h1) {
    font-size: clamp(1.8rem, 7vw, 3rem);
    line-height: 1.05;
  }

  .amv-view-shell :where(.metric-grid, .focus-grid, .student-grid, .resource-grid,
    .lessons-list, .quiz-stack, .summary-grid, .insight-row, .calendar-insight-row,
    .format__grid, .sound__grid, .skills__grid, .productions__grid) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .amv-view-shell :where(.students-toolbar, .resources-controls, .calendar-toolbar,
    .gradebook-legacy-toolbar, .classes-header, .section-heading, .profile-actions) {
    gap: 10px;
  }

  .amv-view-shell :where(input, select, textarea, .select, .search-input) {
    min-height: 44px;
  }
}

@media (max-width: 520px) {
  .amv-view-shell :where(.metric-grid, .focus-grid, .student-grid, .resource-grid,
    .lessons-list, .quiz-stack, .summary-grid, .insight-row, .calendar-insight-row,
    .format__grid, .sound__grid, .skills__grid, .productions__grid) {
    grid-template-columns: minmax(0, 1fr);
  }

  .amv-view-shell :where(.hero, .hero-panel, .amv-hero, .calendar-hero,
    .resources-hero, .classes-header, .students__header, .gradebook__hero) {
    border-radius: 18px;
  }

  .amv-view-shell :where(.card, .panel, .surface, .summary-card, .metric-card,
    .focus-card, .next-class-card, .insight-card, .agenda-card, .quiz-card,
    .resource-card, .student-card, .lesson-card, .task-card, .format-card,
    .production, .state-card, .empty-card) {
    border-radius: 16px;
  }

  .amv-view-shell :where(.hero-actions > *, .form-actions > *, .footer-actions > *,
    .question-actions > *, .result-action > *, .result-next-step__actions > *) {
    width: 100%;
    min-width: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .amv-view-shell,
  .amv-view-shell :where(*, *::before, *::after) {
    scroll-behavior: auto !important;
    transition-duration: 0.01ms !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
  }
}
</style>
