<template>
  <section class="review-page amv-view-shell">
    <section
      v-if="isLoading"
      class="state-screen"
    >
      <div class="spinner"></div>

      <span>
        REVISIÓN
      </span>

      <h1>
        Preparando tu resultado
      </h1>

      <p>
        Estamos cargando tus respuestas y la retroalimentación disponible.
      </p>
    </section>

    <section
      v-else-if="loadError"
      class="state-screen state-screen--error"
    >
      <div class="state-icon">
        !
      </div>

      <span>
        NO PUDIMOS CONTINUAR
      </span>

      <h1>
        No pudimos abrir esta revisión
      </h1>

      <p>
        {{ loadError }}
      </p>

      <div class="state-actions">
        <button
          type="button"
          @click="loadReview"
        >
          Reintentar
        </button>

        <RouterLink
          to="/aula/evaluaciones"
        >
          Volver a Mis evaluaciones
        </RouterLink>
      </div>
    </section>

    <template v-else-if="attempt">
      <header class="review-hero">
        <div>
          <RouterLink
            to="/aula/evaluaciones"
            class="back-link"
          >
            ← Mis evaluaciones
          </RouterLink>

          <div class="review-hero__eyebrow">
            <span>
              {{
                attempt.assessmentType === 'test'
                  ? 'PRUEBA EVALUADA'
                  : 'QUIZ FORMATIVO'
              }}
            </span>

            <span>
              Intento {{ attempt.attemptNumber }}
            </span>
          </div>

          <h1>
            {{ attempt.quizTitle }}
          </h1>

          <p>
            {{ attempt.lessonTitle }}
          </p>
        </div>

        <aside class="result-badge">
          <small>
            RESULTADO
          </small>

          <strong>
            {{ percentageLabel }}
          </strong>

          <span
            :class="{
              'is-passed':
                attempt.passed === true,
              'is-failed':
                attempt.passed === false
            }"
          >
            {{
              attempt.passed === true
                ? 'Aprobada'
                : attempt.passed === false
                  ? 'Por reforzar'
                  : 'Pendiente'
            }}
          </span>
        </aside>
      </header>

      <section class="summary-grid">
        <article>
          <span>
            Correctas
          </span>

          <strong class="summary-good">
            {{ correctCount }}
          </strong>

          <small>
            respuestas acertadas
          </small>
        </article>

        <article>
          <span>
            Por reforzar
          </span>

          <strong class="summary-bad">
            {{ incorrectCount }}
          </strong>

          <small>
            respuestas incorrectas
          </small>
        </article>

        <article>
          <span>
            Pendientes
          </span>

          <strong>
            {{ pendingCount }}
          </strong>

          <small>
            revisión manual
          </small>
        </article>

        <article>
          <span>
            Puntaje
          </span>

          <strong>
            {{ scoreLabel }}
          </strong>

          <small>
            puntaje obtenido
          </small>
        </article>
      </section>

      <section
        v-if="!attempt.showCorrectAnswers"
        class="privacy-notice"
      >
        <div>
          i
        </div>

        <div>
          <strong>
            Revisión limitada por el profesor
          </strong>

          <p>
            Puedes ver tu puntaje y retroalimentación, pero las respuestas
            correctas de esta evaluación están ocultas.
          </p>
        </div>
      </section>

      <section
        v-if="incorrectCount"
        class="reinforcement-panel"
      >
        <div class="reinforcement-panel__icon">
          ↗
        </div>

        <div>
          <span>
            PARA REFORZAR
          </span>

          <h2>
            Hay {{ incorrectCount }}
            {{
              incorrectCount === 1
                ? 'pregunta que conviene revisar'
                : 'preguntas que conviene revisar'
            }}
          </h2>

          <p>
            Lee la explicación de cada respuesta incorrecta y vuelve al
            material de la clase antes de repetir el quiz.
          </p>
        </div>

        <RouterLink
          :to="`/aula/clase/${attempt.lessonId}`"
        >
          Volver a la clase
          <span>→</span>
        </RouterLink>
      </section>

      <section class="filter-bar">
        <button
          v-for="filter in filters"
          :key="filter.value"
          type="button"
          :class="{
            'filter-button--active':
              activeFilter === filter.value
          }"
          @click="
            activeFilter =
              filter.value
          "
        >
          {{ filter.label }}

          <span>
            {{ countForFilter(filter.value) }}
          </span>
        </button>
      </section>

      <section class="question-list">
        <article
          v-for="question in filteredQuestions"
          :key="question.id"
          class="question-card"
          :class="`question-card--${getQuestionState(question)}`"
        >
          <header class="question-card__header">
            <div>
              <span>
                PREGUNTA
                {{ String(question.position).padStart(2, '0') }}
              </span>

              <strong>
                {{ question.points }}
                {{
                  Number(question.points) === 1
                    ? 'punto'
                    : 'puntos'
                }}
              </strong>
            </div>

            <div
              class="question-state"
              :class="`question-state--${getQuestionState(question)}`"
            >
              {{ getQuestionStateLabel(question) }}
            </div>
          </header>

          <div class="question-card__body">
            <h2>
              {{ question.prompt }}
            </h2>

            <div
              v-if="hasOptions(question)"
              class="answer-options"
            >
              <article
                v-for="option in question.options"
                :key="option.id"
                class="answer-option"
                :class="{
                  'answer-option--selected':
                    isSelected(question, option.id),
                  'answer-option--correct':
                    isCorrectOption(question, option.id),
                  'answer-option--wrong-selected':
                    isSelected(question, option.id) &&
                    attempt.showCorrectAnswers &&
                    !isCorrectOption(question, option.id)
                }"
              >
                <span class="answer-option__marker">
                  {{
                    getOptionLetter(
                      question.options,
                      option.id,
                    )
                  }}
                </span>

                <strong>
                  {{ option.text }}
                </strong>

                <small
                  v-if="isSelected(question, option.id)"
                >
                  Tu respuesta
                </small>

                <small
                  v-if="isCorrectOption(question, option.id)"
                  class="correct-label"
                >
                  Correcta
                </small>
              </article>
            </div>

            <section
              v-if="question.textAnswer"
              class="text-answer"
            >
              <span>
                TU RESPUESTA
              </span>

              <p>
                {{ question.textAnswer }}
              </p>
            </section>

            <section
              v-if="
                question.scoreAwarded !== null
              "
              class="awarded-score"
            >
              <span>
                PUNTAJE OBTENIDO
              </span>

              <strong>
                {{ formatScore(question.scoreAwarded) }}
                /
                {{ formatScore(question.points) }}
              </strong>
            </section>

            <section
              v-if="
                attempt.showCorrectAnswers &&
                question.explanation
              "
              class="explanation-box"
            >
              <span>
                ¿POR QUÉ?
              </span>

              <p>
                {{ question.explanation }}
              </p>
            </section>

            <section
              v-if="question.teacherFeedback"
              class="feedback-box"
            >
              <span>
                RETROALIMENTACIÓN DEL PROFESOR
              </span>

              <p>
                {{ question.teacherFeedback }}
              </p>
            </section>

            <section
              v-if="
                getQuestionState(question) === 'incorrect'
              "
              class="reinforce-box"
            >
              <span>
                REFORZAR
              </span>

              <p>
                Revisa este concepto en el material de la clase antes de
                realizar un nuevo intento.
              </p>
            </section>
          </div>
        </article>
      </section>

      <footer class="review-footer">
        <div>
          <span>
            SIGUIENTE PASO
          </span>

          <strong>
            {{
              attempt.assessmentType === 'quiz'
                ? 'Revisa, refuerza y vuelve a practicar'
                : 'Continúa con tu programa formativo'
            }}
          </strong>
        </div>

        <div class="review-footer__actions">
          <RouterLink
            :to="`/aula/clase/${attempt.lessonId}`"
            class="secondary-action"
          >
            Ver clase
          </RouterLink>

          <RouterLink
            v-if="attempt.assessmentType === 'quiz'"
            :to="
              `/aula/clase/${attempt.lessonId}/evaluacion/${attempt.quizId}`
            "
            class="primary-action"
          >
            Practicar nuevamente
            <span>→</span>
          </RouterLink>
        </div>
      </footer>
    </template>
  </section>
</template>

<script setup>
import {
  computed,
  onMounted,
  ref,
} from 'vue'

import {
  RouterLink,
  useRoute,
} from 'vue-router'

import {
  fetchMyEvaluationReview,
  getReviewQuestionState,
} from '@/services/evaluationReviewService'

const route =
  useRoute()

const attempt =
  ref(null)

const questions =
  ref([])

const isLoading =
  ref(true)

const loadError =
  ref('')

const activeFilter =
  ref('all')

const filters = [
  {
    value: 'all',
    label: 'Todas',
  },
  {
    value: 'correct',
    label: 'Correctas',
  },
  {
    value: 'incorrect',
    label: 'Por reforzar',
  },
  {
    value: 'pending',
    label: 'Pendientes',
  },
]

const attemptId =
  computed(() =>
    Number(
      route.params.attemptId,
    ),
  )

const loadReview =
  async () => {
    isLoading.value = true
    loadError.value = ''

    try {
      const review =
        await fetchMyEvaluationReview(
          attemptId.value,
        )

      attempt.value =
        review.attempt

      questions.value =
        review.questions
    } catch (error) {
      console.error(
        'Error cargando revisión:',
        error,
      )

      attempt.value = null
      questions.value = []

      loadError.value =
        error?.message ||
        'No fue posible cargar esta revisión.'
    } finally {
      isLoading.value = false
    }
  }

const getQuestionState =
  question =>
    getReviewQuestionState(
      question,
    )

const correctCount =
  computed(() =>
    questions.value.filter(
      question =>
        getQuestionState(question) ===
        'correct',
    ).length,
  )

const incorrectCount =
  computed(() =>
    questions.value.filter(
      question =>
        getQuestionState(question) ===
        'incorrect',
    ).length,
  )

const pendingCount =
  computed(() =>
    questions.value.filter(
      question =>
        [
          'pending',
          'reviewed',
        ].includes(
          getQuestionState(
            question,
          ),
        ),
    ).length,
  )

const filteredQuestions =
  computed(() => {
    if (
      activeFilter.value ===
      'all'
    ) {
      return questions.value
    }

    if (
      activeFilter.value ===
      'pending'
    ) {
      return questions.value.filter(
        question =>
          [
            'pending',
            'reviewed',
          ].includes(
            getQuestionState(
              question,
            ),
          ),
      )
    }

    return questions.value.filter(
      question =>
        getQuestionState(
          question,
        ) ===
        activeFilter.value,
    )
  })

const percentageLabel =
  computed(() => {
    const value =
      Number(
        attempt.value
          ?.percentage,
      )

    return Number.isFinite(value)
      ? `${Math.round(value)}%`
      : '—'
  })

const scoreLabel =
  computed(() => {
    const score =
      attempt.value?.score

    const max =
      attempt.value?.maxScore

    if (
      score === null ||
      max === null
    ) {
      return '—'
    }

    return `${formatScore(score)} / ${formatScore(max)}`
  })

const countForFilter =
  value => {
    if (
      value === 'all'
    ) {
      return questions.value.length
    }

    if (
      value === 'correct'
    ) {
      return correctCount.value
    }

    if (
      value === 'incorrect'
    ) {
      return incorrectCount.value
    }

    return pendingCount.value
  }

const getQuestionStateLabel =
  question => {
    const state =
      getQuestionState(
        question,
      )

    const labels = {
      correct:
        '✓ Correcta',
      incorrect:
        '✕ Por reforzar',
      reviewed:
        'Revisada',
      pending:
        'Pendiente',
    }

    return (
      labels[state] ||
      'Pendiente'
    )
  }

const hasOptions =
  question =>
    Array.isArray(
      question?.options,
    ) &&
    question.options.length > 0

const isSelected = (
  question,
  optionId,
) =>
  (
    question
      ?.selectedOptionIds ||
    []
  )
    .map(Number)
    .includes(
      Number(optionId),
    )

const isCorrectOption = (
  question,
  optionId,
) => {
  if (
    !attempt.value
      ?.showCorrectAnswers ||
    !Array.isArray(
      question?.correctOptionIds,
    )
  ) {
    return false
  }

  return question
    .correctOptionIds
    .map(Number)
    .includes(
      Number(optionId),
    )
}

const getOptionLetter = (
  options,
  optionId,
) => {
  const index =
    options.findIndex(
      option =>
        Number(option.id) ===
        Number(optionId),
    )

  return index >= 0
    ? String.fromCharCode(
        65 + index,
      )
    : '•'
}

const formatScore =
  value => {
    const number =
      Number(value)

    if (
      !Number.isFinite(number)
    ) {
      return '0'
    }

    return Number.isInteger(number)
      ? String(number)
      : number.toFixed(1)
  }

onMounted(
  loadReview,
)
</script>

<style lang="scss" scoped>
@use '@/assets/styles/abstracts/variables' as variables;

.review-page {
  width: min(1400px, 100%);
  margin: 0 auto;
  padding:
    clamp(1rem, 3vw, 2.4rem)
    clamp(1rem, 3vw, 2.5rem)
    5rem;
}

.state-screen {
  display: grid;
  min-height: 62vh;
  gap: 0.8rem;
  place-items: center;
  align-content: center;
  text-align: center;
}

.spinner {
  width: 48px;
  height: 48px;
  border:
    3px solid
    rgba(255, 255, 255, 0.08);
  border-top-color:
    variables.$color-primary;
  border-radius: 50%;
  animation:
    spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.state-screen > span,
.review-hero__eyebrow span,
.question-card__header span,
.reinforcement-panel span,
.review-footer > div > span {
  color:
    variables.$color-primary;
  font-size: 0.7rem;
  font-weight: 900;
  letter-spacing: 0.12em;
}

.state-screen h1 {
  margin: 0;
  font-size:
    clamp(2rem, 5vw, 4rem);
}

.state-screen p {
  max-width: 650px;
  margin: 0;
  color:
    rgba(255, 255, 255, 0.55);
  line-height: 1.65;
}

.state-icon {
  display: grid;
  width: 60px;
  height: 60px;
  place-items: center;
  border:
    1px solid
    #ef6767;
  border-radius: 50%;
  color: #ff8585;
  font-size: 1.4rem;
  font-weight: 900;
}

.state-actions {
  display: flex;
  gap: 0.7rem;
  flex-wrap: wrap;
  margin-top: 0.7rem;
}

.state-actions button,
.state-actions a {
  min-height: 46px;
  padding:
    0.7rem
    1rem;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 10px;
  background: transparent;
  color:
    variables.$color-primary;
  font: inherit;
  font-weight: 900;
  text-decoration: none;
  cursor: pointer;
}

.review-hero {
  display: grid;
  gap: 2rem;
  grid-template-columns:
    minmax(0, 1fr)
    auto;
  align-items: end;
  margin-bottom: 1rem;
  padding:
    clamp(1.4rem, 4vw, 3rem);
  border:
    1px solid
    rgba(255, 196, 0, 0.23);
  border-radius: 24px;
  background:
    radial-gradient(
      circle at 90% 0%,
      rgba(255, 196, 0, 0.1),
      transparent 35%
    ),
    variables.$color-surface;
}

.back-link {
  display: inline-flex;
  min-height: 44px;
  align-items: center;
  margin-bottom: 1rem;
  color:
    rgba(255, 255, 255, 0.62);
  font-size: 0.82rem;
  font-weight: 800;
  text-decoration: none;
}

.review-hero__eyebrow {
  display: flex;
  gap: 0.45rem;
  flex-wrap: wrap;
}

.review-hero__eyebrow span {
  padding:
    0.3rem
    0.55rem;
  border:
    1px solid
    rgba(255, 196, 0, 0.28);
  border-radius: 999px;
}

.review-hero h1 {
  margin:
    0.65rem
    0
    0;
  font-size:
    clamp(2.5rem, 6vw, 5.5rem);
  line-height: 0.98;
}

.review-hero p {
  margin:
    0.6rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.52);
}

.result-badge {
  display: grid;
  width: 150px;
  min-height: 150px;
  place-items: center;
  align-content: center;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 50%;
  text-align: center;
}

.result-badge small,
.result-badge span {
  color:
    rgba(255, 255, 255, 0.48);
  font-size: 0.68rem;
}

.result-badge strong {
  margin:
    0.25rem
    0;
  color:
    variables.$color-primary;
  font-size: 2.5rem;
}

.result-badge .is-passed {
  color: #79df98;
}

.result-badge .is-failed {
  color: #ef8585;
}

.summary-grid {
  display: grid;
  gap: 0.75rem;
  grid-template-columns:
    repeat(4, minmax(0, 1fr));
  margin-bottom: 1rem;
}

.summary-grid article {
  padding: 1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 14px;
  background:
    variables.$color-surface;
}

.summary-grid span,
.summary-grid strong,
.summary-grid small {
  display: block;
}

.summary-grid span {
  color:
    rgba(255, 255, 255, 0.48);
  font-size: 0.75rem;
  font-weight: 800;
}

.summary-grid strong {
  margin:
    0.3rem
    0
    0.1rem;
  color:
    variables.$color-primary;
  font-size: 1.9rem;
}

.summary-grid .summary-good {
  color: #79df98;
}

.summary-grid .summary-bad {
  color: #ef8585;
}

.summary-grid small {
  color:
    rgba(255, 255, 255, 0.35);
  font-size: 0.68rem;
}

.privacy-notice,
.reinforcement-panel {
  display: grid;
  gap: 1rem;
  grid-template-columns:
    auto
    minmax(0, 1fr);
  align-items: center;
  margin-bottom: 1rem;
  padding: 1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 15px;
  background:
    variables.$color-surface;
}

.privacy-notice > div:first-child,
.reinforcement-panel__icon {
  display: grid;
  width: 44px;
  height: 44px;
  place-items: center;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-weight: 900;
}

.privacy-notice p,
.reinforcement-panel p {
  margin:
    0.25rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.5);
  font-size: 0.82rem;
  line-height: 1.6;
}

.reinforcement-panel {
  grid-template-columns:
    auto
    minmax(0, 1fr)
    auto;
  border-color:
    rgba(239, 103, 103, 0.28);
  background:
    rgba(239, 103, 103, 0.035);
}

.reinforcement-panel h2 {
  margin:
    0.25rem
    0
    0;
  font-size: 1.15rem;
}

.reinforcement-panel a {
  display: inline-flex;
  min-height: 44px;
  gap: 0.5rem;
  align-items: center;
  padding:
    0.65rem
    0.8rem;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 9px;
  color:
    variables.$color-primary;
  font-size: 0.78rem;
  font-weight: 900;
  text-decoration: none;
}

.filter-bar {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
  margin-bottom: 1rem;
}

.filter-bar button {
  display: inline-flex;
  min-height: 44px;
  gap: 0.5rem;
  align-items: center;
  padding:
    0.65rem
    0.8rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 999px;
  background: transparent;
  color:
    rgba(255, 255, 255, 0.6);
  font: inherit;
  font-size: 0.78rem;
  font-weight: 900;
  cursor: pointer;
}

.filter-bar button span {
  display: grid;
  min-width: 23px;
  height: 23px;
  place-items: center;
  border-radius: 999px;
  background:
    rgba(255, 255, 255, 0.06);
  font-size: 0.67rem;
}

.filter-bar
button.filter-button--active {
  border-color:
    variables.$color-primary;
  background:
    rgba(255, 196, 0, 0.08);
  color:
    variables.$color-primary;
}

.question-list {
  display: grid;
  gap: 0.9rem;
}

.question-card {
  overflow: hidden;
  border:
    1px solid
    variables.$color-border;
  border-radius: 17px;
  background:
    variables.$color-surface;
}

.question-card--correct {
  border-color:
    rgba(103, 217, 139, 0.35);
}

.question-card--incorrect {
  border-color:
    rgba(239, 103, 103, 0.35);
}

.question-card__header {
  display: flex;
  gap: 1rem;
  align-items: center;
  justify-content: space-between;
  padding:
    0.85rem
    1rem;
  border-bottom:
    1px solid
    variables.$color-border;
}

.question-card__header > div:first-child {
  display: flex;
  gap: 0.7rem;
  align-items: center;
  flex-wrap: wrap;
}

.question-card__header strong {
  color:
    rgba(255, 255, 255, 0.46);
  font-size: 0.72rem;
}

.question-state {
  padding:
    0.35rem
    0.55rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 999px;
  font-size: 0.7rem;
  font-weight: 900;
}

.question-state--correct {
  border-color:
    rgba(103, 217, 139, 0.42);
  color: #8ee3a7;
}

.question-state--incorrect {
  border-color:
    rgba(239, 103, 103, 0.42);
  color: #ef8585;
}

.question-card__body {
  padding:
    clamp(1rem, 3vw, 1.6rem);
}

.question-card h2 {
  max-width: 980px;
  margin:
    0
    0
    1rem;
  font-size:
    clamp(1.15rem, 3vw, 1.55rem);
  line-height: 1.4;
}

.answer-options {
  display: grid;
  gap: 0.55rem;
}

.answer-option {
  display: grid;
  gap: 0.7rem;
  grid-template-columns:
    auto
    minmax(0, 1fr)
    auto
    auto;
  align-items: center;
  min-height: 54px;
  padding:
    0.7rem
    0.8rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 11px;
}

.answer-option__marker {
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  border:
    1px solid
    variables.$color-border;
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-size: 0.78rem;
  font-weight: 900;
}

.answer-option strong {
  font-size: 0.88rem;
}

.answer-option small {
  color:
    rgba(255, 255, 255, 0.45);
  font-size: 0.67rem;
  font-weight: 800;
}

.answer-option--selected {
  border-color:
    rgba(255, 196, 0, 0.36);
  background:
    rgba(255, 196, 0, 0.04);
}

.answer-option--correct {
  border-color:
    rgba(103, 217, 139, 0.5);
  background:
    rgba(103, 217, 139, 0.06);
}

.answer-option--wrong-selected {
  border-color:
    rgba(239, 103, 103, 0.5);
  background:
    rgba(239, 103, 103, 0.055);
}

.correct-label {
  color:
    #8ee3a7 !important;
}

.text-answer,
.awarded-score,
.explanation-box,
.feedback-box,
.reinforce-box {
  margin-top: 0.8rem;
  padding: 0.85rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 11px;
  background:
    rgba(255, 255, 255, 0.018);
}

.text-answer span,
.awarded-score span,
.explanation-box span,
.feedback-box span,
.reinforce-box span {
  color:
    variables.$color-primary;
  font-size: 0.66rem;
  font-weight: 900;
  letter-spacing: 0.09em;
}

.text-answer p,
.explanation-box p,
.feedback-box p,
.reinforce-box p {
  margin:
    0.35rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.58);
  font-size: 0.85rem;
  line-height: 1.65;
}

.awarded-score strong {
  display: block;
  margin-top: 0.3rem;
  color:
    variables.$color-primary;
  font-size: 1rem;
}

.feedback-box {
  border-color:
    rgba(255, 196, 0, 0.25);
}

.reinforce-box {
  border-color:
    rgba(239, 103, 103, 0.3);
  background:
    rgba(239, 103, 103, 0.04);
}

.review-footer {
  display: flex;
  gap: 1.5rem;
  align-items: center;
  justify-content: space-between;
  margin-top: 1rem;
  padding: 1.1rem;
  border:
    1px solid
    rgba(255, 196, 0, 0.25);
  border-radius: 15px;
  background:
    variables.$color-surface;
}

.review-footer strong {
  display: block;
  margin-top: 0.25rem;
}

.review-footer__actions {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
}

.primary-action,
.secondary-action {
  display: inline-flex;
  min-height: 46px;
  gap: 0.5rem;
  align-items: center;
  justify-content: center;
  padding:
    0.7rem
    0.9rem;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 10px;
  font-size: 0.78rem;
  font-weight: 900;
  text-decoration: none;
}

.primary-action {
  background:
    variables.$color-primary;
  color: #080808;
}

.secondary-action {
  color:
    variables.$color-primary;
}

.review-page button:focus-visible,
.review-page a:focus-visible {
  outline:
    3px solid
    rgba(255, 196, 0, 0.58);
  outline-offset: 3px;
}

@media (
  max-width: 850px
) {
  .summary-grid {
    grid-template-columns:
      repeat(2, minmax(0, 1fr));
  }

  .reinforcement-panel {
    grid-template-columns:
      auto
      minmax(0, 1fr);
  }

  .reinforcement-panel a {
    grid-column: 2;
    justify-self: start;
  }
}

@media (
  max-width: 680px
) {
  .review-page {
    padding:
      0.85rem
      0.75rem
      4rem;
  }

  .review-hero {
    grid-template-columns: 1fr;
  }

  .result-badge {
    width: 120px;
    min-height: 120px;
  }

  .answer-option {
    grid-template-columns:
      auto
      minmax(0, 1fr);
  }

  .answer-option small {
    grid-column: 2;
  }

  .review-footer {
    align-items: flex-start;
    flex-direction: column;
  }

  .review-footer__actions {
    width: 100%;
  }

  .primary-action,
  .secondary-action {
    flex: 1;
  }
}

@media (
  max-width: 460px
) {
  .summary-grid {
    grid-template-columns: 1fr;
  }

  .reinforcement-panel {
    grid-template-columns: 1fr;
  }

  .reinforcement-panel a {
    grid-column: auto;
  }

  .primary-action,
  .secondary-action {
    width: 100%;
  }
}


/* =========================================================
   V7.7 · REVIEW EVALUATION · PREMIUM LIGHT LMS
   Rediseño completo de la revisión del estudiante.
========================================================= */

.review-page {
  --rv-ink: #152033;
  --rv-ink-soft: #344359;
  --rv-muted: #6f7c8f;
  --rv-muted-2: #8b98aa;
  --rv-line: #dbe3ec;
  --rv-line-strong: #cbd6e2;
  --rv-surface: #ffffff;
  --rv-surface-soft: #f7f9fc;
  --rv-wine: #9f1945;
  --rv-wine-dark: #7f1237;
  --rv-gold: #d9a91d;
  --rv-gold-dark: #987000;
  --rv-gold-soft: #fff8e7;
  --rv-green: #2d8a63;
  --rv-green-soft: #edf8f3;
  --rv-red: #be4856;
  --rv-red-soft: #fff3f5;
  --rv-blue: #3f6fa8;
  --rv-blue-soft: #eef5fc;

  width: min(1240px, calc(100% - 40px)) !important;
  margin-inline: auto !important;
  padding: 38px 0 72px !important;
  color: var(--rv-ink) !important;
}

/* =========================================================
   HERO
========================================================= */

.review-page .review-hero {
  position: relative;
  display: grid !important;
  gap: 26px !important;
  grid-template-columns: minmax(0,1fr) auto !important;
  align-items: center !important;
  margin-bottom: 16px !important;
  padding: 30px 32px !important;
  overflow: hidden !important;
  border: 1px solid var(--rv-line) !important;
  border-radius: 22px !important;
  background:
    radial-gradient(circle at 92% 8%, rgba(217,169,29,.12), transparent 30%),
    linear-gradient(135deg,#fff 0%,#fbfcfe 68%,#fffaf0 100%) !important;
  box-shadow: 0 14px 36px rgba(31,48,73,.055) !important;
}

.review-page .review-hero::before {
  position: absolute;
  top: 0;
  left: 0;
  width: 130px;
  height: 3px;
  content: '';
  background: linear-gradient(90deg,var(--rv-wine),var(--rv-gold));
}

.review-page .back-link {
  margin-bottom: 14px !important;
  color: #718095 !important;
  font-size: .68rem !important;
  font-weight: 850 !important;
}

.review-page .back-link:hover {
  color: var(--rv-wine) !important;
}

.review-page .review-hero__eyebrow {
  gap: 7px !important;
}

.review-page .review-hero__eyebrow span {
  padding: 6px 9px !important;
  border: 1px solid #e4d08a !important;
  border-radius: 999px !important;
  color: var(--rv-gold-dark) !important;
  background: var(--rv-gold-soft) !important;
  font-size: .53rem !important;
  font-weight: 900 !important;
}

.review-page .review-hero h1 {
  margin: 10px 0 0 !important;
  color: var(--rv-ink) !important;
  font-size: clamp(2.7rem,5.5vw,4.8rem) !important;
  line-height: .98 !important;
  letter-spacing: -.045em !important;
}

.review-page .review-hero p {
  margin-top: 9px !important;
  color: var(--rv-muted) !important;
  font-size: .82rem !important;
  line-height: 1.55 !important;
}

.review-page .result-badge {
  display: grid !important;
  width: 150px !important;
  min-height: 150px !important;
  place-items: center !important;
  align-content: center !important;
  border: 1px solid #e4cf86 !important;
  border-radius: 50% !important;
  background: #fffaf0 !important;
  box-shadow: inset 0 0 0 6px rgba(217,169,29,.04) !important;
}

.review-page .result-badge small {
  color: #8b7d52 !important;
  font-size: .5rem !important;
  font-weight: 900 !important;
  letter-spacing: .08em !important;
}

.review-page .result-badge strong {
  margin: 4px 0 !important;
  color: var(--rv-gold-dark) !important;
  font-size: 2.45rem !important;
}

.review-page .result-badge span {
  color: #7b8798 !important;
  font-size: .63rem !important;
  font-weight: 800 !important;
}

.review-page .result-badge .is-passed {
  color: var(--rv-green) !important;
}

.review-page .result-badge .is-failed {
  color: var(--rv-red) !important;
}

/* =========================================================
   SUMMARY
========================================================= */

.review-page .summary-grid {
  gap: 12px !important;
  margin-bottom: 16px !important;
}

.review-page .summary-grid article {
  min-height: 112px !important;
  padding: 17px !important;
  border: 1px solid var(--rv-line) !important;
  border-radius: 16px !important;
  background: #fff !important;
  box-shadow: 0 7px 20px rgba(31,48,73,.035) !important;
}

.review-page .summary-grid article:nth-child(1) {
  border-color: #cce2d5 !important;
  background: linear-gradient(145deg,#fff,#f4faf7) !important;
}

.review-page .summary-grid article:nth-child(2) {
  border-color: #ecd4d8 !important;
  background: linear-gradient(145deg,#fff,#fff6f7) !important;
}

.review-page .summary-grid article:nth-child(3) {
  border-color: #e9d79a !important;
  background: linear-gradient(145deg,#fff,#fffaf0) !important;
}

.review-page .summary-grid article:nth-child(4) {
  background: linear-gradient(145deg,#fff,#f7f9fc) !important;
}

.review-page .summary-grid span {
  color: var(--rv-muted-2) !important;
  font-size: .48rem !important;
  font-weight: 900 !important;
  letter-spacing: .08em !important;
}

.review-page .summary-grid strong {
  margin: 5px 0 2px !important;
  color: var(--rv-ink) !important;
  font-size: 1.45rem !important;
}

.review-page .summary-grid .summary-good {
  color: var(--rv-green) !important;
}

.review-page .summary-grid .summary-bad {
  color: var(--rv-red) !important;
}

.review-page .summary-grid small {
  color: var(--rv-muted) !important;
  font-size: .57rem !important;
}

/* =========================================================
   NOTICE / REFORZAR
========================================================= */

.review-page .privacy-notice,
.review-page .reinforcement-panel {
  margin-bottom: 16px !important;
  padding: 17px !important;
  border: 1px solid var(--rv-line) !important;
  border-radius: 15px !important;
  background: #fff !important;
}

.review-page .privacy-notice {
  border-color: #d9e4ef !important;
  background: var(--rv-blue-soft) !important;
}

.review-page .privacy-notice > div:first-child {
  border-color: #bcd0e5 !important;
  color: var(--rv-blue) !important;
  background: #fff !important;
}

.review-page .privacy-notice strong,
.review-page .reinforcement-panel h2 {
  color: var(--rv-ink) !important;
}

.review-page .privacy-notice p,
.review-page .reinforcement-panel p {
  color: var(--rv-muted) !important;
}

.review-page .reinforcement-panel {
  border-color: #edd1d6 !important;
  background: var(--rv-red-soft) !important;
}

.review-page .reinforcement-panel__icon {
  border-color: #e7bcc4 !important;
  color: var(--rv-red) !important;
  background: #fff !important;
}

.review-page .reinforcement-panel span {
  color: var(--rv-red) !important;
}

.review-page .reinforcement-panel a {
  border-color: #deb3bc !important;
  color: var(--rv-red) !important;
  background: #fff !important;
}

/* =========================================================
   FILTROS
========================================================= */

.review-page .filter-bar {
  gap: 6px !important;
  margin: 0 0 18px !important;
  padding: 8px !important;
  border: 1px solid var(--rv-line) !important;
  border-radius: 14px !important;
  background: #fff !important;
}

.review-page .filter-bar button {
  min-height: 38px !important;
  padding: 8px 11px !important;
  border: 1px solid transparent !important;
  color: #637186 !important;
  background: #f7f9fc !important;
  font-size: .64rem !important;
}

.review-page .filter-bar button span {
  color: #718095 !important;
  background: #fff !important;
}

.review-page .filter-bar button.filter-button--active {
  border-color: #e2ca78 !important;
  color: #765800 !important;
  background: var(--rv-gold-soft) !important;
}

.review-page .filter-bar button.filter-button--active span {
  color: #765800 !important;
  background: #f3d66b !important;
}

/* =========================================================
   QUESTION CARDS
========================================================= */

.review-page .question-list {
  gap: 14px !important;
}

.review-page .question-card {
  overflow: hidden !important;
  border: 1px solid var(--rv-line) !important;
  border-radius: 18px !important;
  background: #fff !important;
  box-shadow: 0 9px 26px rgba(31,48,73,.04) !important;
}

.review-page .question-card--correct {
  border-color: #bfe0cd !important;
}

.review-page .question-card--incorrect {
  border-color: #edc9cf !important;
}

.review-page .question-card__header {
  padding: 15px 18px !important;
  border-bottom: 1px solid #e7ecf1 !important;
  background: #f8fafc !important;
}

.review-page .question-card--correct .question-card__header {
  background: #f4faf7 !important;
}

.review-page .question-card--incorrect .question-card__header {
  background: #fff5f6 !important;
}

.review-page .question-card__header span {
  color: var(--rv-gold-dark) !important;
  font-size: .55rem !important;
  font-weight: 900 !important;
}

.review-page .question-card__header strong {
  color: #68768a !important;
  font-size: .62rem !important;
}

.review-page .question-state {
  padding: 6px 9px !important;
  border: 1px solid #dbe2e9 !important;
  border-radius: 999px !important;
  color: #718095 !important;
  background: #fff !important;
  font-size: .55rem !important;
  font-weight: 900 !important;
}

.review-page .question-state--correct {
  border-color: #bfe0cd !important;
  color: var(--rv-green) !important;
  background: var(--rv-green-soft) !important;
}

.review-page .question-state--incorrect {
  border-color: #efcbd1 !important;
  color: var(--rv-red) !important;
  background: var(--rv-red-soft) !important;
}

.review-page .question-state--pending,
.review-page .question-state--reviewed {
  border-color: #ead79c !important;
  color: var(--rv-gold-dark) !important;
  background: var(--rv-gold-soft) !important;
}

.review-page .question-card__body {
  padding: 24px !important;
  background: #fff !important;
}

.review-page .question-card__body h2 {
  margin: 0 0 18px !important;
  color: var(--rv-ink) !important;
  font-size: clamp(1.35rem,2.8vw,2rem) !important;
  line-height: 1.25 !important;
  letter-spacing: -.02em !important;
}

/* =========================================================
   ANSWERS
========================================================= */

.review-page .answer-options {
  gap: 10px !important;
}

.review-page .answer-option {
  min-height: 68px !important;
  gap: 12px !important;
  padding: 14px 16px !important;
  border: 1px solid #dfe5ec !important;
  border-radius: 13px !important;
  background: #fbfcfe !important;
}

.review-page .answer-option__marker {
  width: 36px !important;
  height: 36px !important;
  border: 1px solid #d7dfe7 !important;
  color: #657386 !important;
  background: #fff !important;
}

.review-page .answer-option strong {
  color: var(--rv-ink-soft) !important;
  font-size: .78rem !important;
}

.review-page .answer-option small {
  color: var(--rv-muted) !important;
}

.review-page .answer-option--selected {
  border-color: #e2cf8a !important;
  background: #fffaf0 !important;
}

.review-page .answer-option--correct {
  border-color: #bfe0cd !important;
  background: var(--rv-green-soft) !important;
}

.review-page .answer-option--correct .answer-option__marker {
  border-color: #9fd1b6 !important;
  color: var(--rv-green) !important;
  background: #fff !important;
}

.review-page .answer-option--wrong-selected {
  border-color: #efcbd1 !important;
  background: var(--rv-red-soft) !important;
}

.review-page .answer-option--wrong-selected .answer-option__marker {
  border-color: #e6b5be !important;
  color: var(--rv-red) !important;
  background: #fff !important;
}

.review-page .correct-label {
  color: var(--rv-green) !important;
  font-weight: 900 !important;
}

/* =========================================================
   SCORE / EXPLANATION / FEEDBACK
========================================================= */

.review-page .text-answer,
.review-page .awarded-score,
.review-page .explanation-box,
.review-page .feedback-box,
.review-page .reinforce-box {
  margin-top: 14px !important;
  padding: 14px !important;
  border: 1px solid #e2e7ed !important;
  border-radius: 12px !important;
  background: #f8fafc !important;
}

.review-page .text-answer span,
.review-page .awarded-score span,
.review-page .explanation-box span,
.review-page .feedback-box span,
.review-page .reinforce-box span {
  color: var(--rv-gold-dark) !important;
  font-size: .5rem !important;
  font-weight: 900 !important;
  letter-spacing: .09em !important;
}

.review-page .text-answer p,
.review-page .explanation-box p,
.review-page .feedback-box p,
.review-page .reinforce-box p {
  margin: 5px 0 0 !important;
  color: var(--rv-muted) !important;
  font-size: .68rem !important;
  line-height: 1.58 !important;
}

.review-page .awarded-score {
  border-color: #e6d392 !important;
  background: var(--rv-gold-soft) !important;
}

.review-page .awarded-score strong {
  display: block !important;
  margin-top: 5px !important;
  color: var(--rv-gold-dark) !important;
  font-size: .95rem !important;
}

.review-page .explanation-box {
  border-color: #d9e4ef !important;
  background: var(--rv-blue-soft) !important;
}

.review-page .explanation-box span {
  color: var(--rv-blue) !important;
}

.review-page .feedback-box {
  border-color: #c9e1d3 !important;
  background: var(--rv-green-soft) !important;
}

.review-page .feedback-box span {
  color: var(--rv-green) !important;
}

.review-page .reinforce-box {
  border-color: #efcbd1 !important;
  background: var(--rv-red-soft) !important;
}

.review-page .reinforce-box span {
  color: var(--rv-red) !important;
}

/* =========================================================
   FOOTER
========================================================= */

.review-page .review-footer {
  display: flex !important;
  gap: 18px !important;
  align-items: center !important;
  justify-content: space-between !important;
  margin-top: 18px !important;
  padding: 18px !important;
  border: 1px solid var(--rv-line) !important;
  border-radius: 16px !important;
  background: #fff !important;
  box-shadow: 0 8px 22px rgba(31,48,73,.03) !important;
}

.review-page .review-footer > div > span {
  color: var(--rv-gold-dark) !important;
}

.review-page .review-footer strong {
  color: var(--rv-ink) !important;
}

.review-page .review-footer__actions {
  display: flex !important;
  gap: 8px !important;
  flex-wrap: wrap !important;
}

.review-page .secondary-action,
.review-page .primary-action {
  min-height: 44px !important;
  padding: 0 14px !important;
  border-radius: 10px !important;
  font-size: .66rem !important;
  font-weight: 900 !important;
}

.review-page .secondary-action {
  border: 1px solid var(--rv-line-strong) !important;
  color: var(--rv-ink-soft) !important;
  background: #fff !important;
}

.review-page .primary-action {
  border: 1px solid var(--rv-wine) !important;
  color: #fff !important;
  background: var(--rv-wine) !important;
}

.review-page .primary-action:hover {
  background: var(--rv-wine-dark) !important;
}

/* =========================================================
   LOADING / ERROR
========================================================= */

.review-page .state-screen {
  min-height: 58vh !important;
  padding: 28px !important;
  border: 1px solid var(--rv-line) !important;
  border-radius: 18px !important;
  background: #fff !important;
}

.review-page .state-screen h1 {
  color: var(--rv-ink) !important;
}

.review-page .state-screen p {
  color: var(--rv-muted) !important;
}

.review-page .spinner {
  border-color: #e2e7ed !important;
  border-top-color: var(--rv-wine) !important;
}

.review-page .state-icon {
  border-color: #e6b8c0 !important;
  color: var(--rv-red) !important;
  background: var(--rv-red-soft) !important;
}

.review-page .state-actions button,
.review-page .state-actions a {
  border-color: var(--rv-line-strong) !important;
  color: var(--rv-ink-soft) !important;
  background: #fff !important;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {
  .review-page .review-hero {
    grid-template-columns: 1fr !important;
    align-items: start !important;
  }

  .review-page .result-badge {
    width: 120px !important;
    min-height: 120px !important;
  }

  .review-page .summary-grid {
    grid-template-columns: repeat(2,minmax(0,1fr)) !important;
  }

  .review-page .reinforcement-panel {
    grid-template-columns: auto minmax(0,1fr) !important;
  }

  .review-page .reinforcement-panel a {
    grid-column: 2 !important;
    justify-self: start !important;
  }
}

@media (max-width: 650px) {
  .review-page {
    width: min(100% - 28px,1240px) !important;
    padding: 28px 0 54px !important;
  }

  .review-page .review-hero {
    padding: 22px !important;
  }

  .review-page .summary-grid {
    grid-template-columns: 1fr !important;
  }

  .review-page .question-card__body {
    padding: 18px !important;
  }

  .review-page .answer-option {
    align-items: start !important;
  }

  .review-page .review-footer {
    align-items: flex-start !important;
    flex-direction: column !important;
  }

  .review-page .review-footer__actions {
    width: 100% !important;
  }

  .review-page .secondary-action,
  .review-page .primary-action {
    flex: 1 1 100% !important;
    justify-content: center !important;
  }
}



/* =========================================================
   AMV LMS UI SYSTEM · ACADEMIC EXPERIENCE v1.0
   Sistema visual común para el SaaS
========================================================= */
.review-page {
  --amv-canvas: #f5f7fb;
  --amv-card: #ffffff;
  --amv-ink: #172033;
  --amv-body: #344359;
  --amv-muted: #667085;
  --amv-line: #dbe3ec;
  --amv-wine: #9f1945;
  --amv-wine-dark: #7f1237;
  --amv-gold: #d9a91d;
  --amv-gold-soft: #fff8e7;
  --amv-green: #2d8a63;
  --amv-red: #be4856;
  --amv-shadow-sm: 0 8px 24px rgba(23, 32, 51, .055);
  --amv-shadow-md: 0 18px 46px rgba(23, 32, 51, .085);
  --amv-radius-sm: 12px;
  --amv-radius-md: 18px;
  --amv-radius-lg: 24px;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
}

.review-page :where(a, button, input, textarea, select, [role="button"]) {
  transition: color .2s ease, background-color .2s ease, border-color .2s ease, box-shadow .2s ease, transform .2s ease, opacity .2s ease;
}

.review-page :where(a, button, input, textarea, select, [role="button"]):focus-visible {
  outline: 3px solid rgba(159, 25, 69, .22) !important;
  outline-offset: 3px;
}

.review-page :where(button, [role="button"], .button, .btn):not(:disabled):active {
  transform: translateY(1px) scale(.99);
}

.review-page :where(input, textarea, select) {
  font-size: max(16px, 1em);
}

.review-page :where(table tbody tr) {
  transition: background-color .18s ease;
}

.review-page :where(table tbody tr):hover {
  background-color: rgba(159, 25, 69, .025);
}

.review-page :where(.card, [class*="-card"], [class*="__card"]) {
  transition: transform .24s cubic-bezier(.2,.75,.25,1), box-shadow .24s ease, border-color .24s ease;
}

.review-page :where(.card, [class*="-card"], [class*="__card"]):hover {
  border-color: rgba(159, 25, 69, .16);
}

@media (prefers-reduced-motion: reduce) {
  .review-page *, .review-page *::before, .review-page *::after {
    scroll-behavior: auto !important;
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
  }
}


/* =========================================================
   AMV LMS · FLUID MOTION & PREMIUM INTERACTION v2.0
   Capa visual segura: no modifica lógica, datos ni estructura.
========================================================= */
.review-page {
  animation: amvViewEnter .46s cubic-bezier(.2,.75,.25,1) both;
}

.review-page :where(
  article,
  [class$="__card"],
  [class*="-card"],
  [class*="_card"]
) {
  transition:
    transform .24s cubic-bezier(.2,.75,.25,1),
    box-shadow .24s ease,
    border-color .24s ease,
    background-color .24s ease;
}

@media (hover: hover) and (pointer: fine) {
  .review-page :where(
    article,
    [class$="__card"],
    [class*="-card"],
    [class*="_card"]
  ):hover {
    transform: translateY(-2px);
  }

  .review-page :where(
    button,
    .button,
    .btn,
    a[class*="button"],
    a[class*="cta"]
  ):not(:disabled):hover {
    transform: translateY(-2px);
    filter: saturate(1.04);
  }

  .review-page :where(img) {
    transition: transform .55s cubic-bezier(.2,.75,.25,1), filter .35s ease;
  }

  .review-page :where(
    [class*="cover"],
    [class*="hero"],
    [class*="visual"],
    [class*="gallery"]
  ):hover img {
    transform: scale(1.018);
  }
}

.review-page :where(
  button,
  .button,
  .btn,
  a[class*="button"],
  a[class*="cta"]
) {
  will-change: transform;
}

.review-page :where(input, textarea, select):focus {
  transform: translateY(-1px);
}

.review-page :where(
  [class*="progress"] > *,
  [class*="bar"] > *,
  progress
) {
  transition: width .55s cubic-bezier(.2,.75,.25,1), transform .35s ease;
}

.review-page ::selection {
  color: #ffffff;
  background: #9f1945;
}

@keyframes amvViewEnter {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (prefers-reduced-motion: reduce) {
  .review-page,
  .review-page *,
  .review-page *::before,
  .review-page *::after {
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
    scroll-behavior: auto !important;
  }
}

</style>


<style lang="scss">
/* AMV UI POLISH 2026 — visual consistency, accessibility and mobile resilience. */
.amv-view-shell {
  --amv-ui-wine: #9f1945;
  --amv-ui-wine-deep: #7f1237;
  --amv-ui-gold: #d9a91d;
  --amv-ui-purple: #7657d9;
  --amv-ui-cyan: #20b8ae;
  --amv-ui-ink: #172033;
  --amv-ui-muted: #6f7c8f;
  --amv-ui-line: rgba(122, 137, 158, 0.20);
  --amv-ui-focus: rgba(159, 25, 69, 0.38);
  --amv-ui-radius-sm: 12px;
  --amv-ui-radius-md: 18px;
  --amv-ui-radius-lg: 26px;
  --amv-ui-shadow: 0 18px 55px rgba(17, 25, 39, 0.09);
  --amv-ui-shadow-hover: 0 22px 65px rgba(17, 25, 39, 0.14);
  position: relative;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  isolation: isolate;
  overflow-x: clip;
  -webkit-tap-highlight-color: transparent;
}

.amv-view-shell::before {
  content: '';
  position: absolute;
  inset: -150px -120px auto auto;
  width: 420px;
  height: 420px;
  pointer-events: none;
  border-radius: 50%;
  background:
    radial-gradient(circle at 35% 35%, rgba(159, 25, 69, 0.10), transparent 52%),
    radial-gradient(circle at 68% 62%, rgba(217, 169, 29, 0.08), transparent 58%);
  filter: blur(6px);
  opacity: 0.82;
  z-index: -1;
}

.amv-view-shell :where(*, *::before, *::after) {
  box-sizing: border-box;
}

.amv-view-shell :where(img, video, svg, canvas) {
  max-width: 100%;
}

.amv-view-shell :where(h1, h2, h3, h4, h5, h6) {
  text-wrap: balance;
}

.amv-view-shell :where(p, li, td, th, label, small) {
  overflow-wrap: anywhere;
}

.amv-view-shell :where(a, button, input, select, textarea, [role='button']) {
  touch-action: manipulation;
}

.amv-view-shell :where(button, input, select, textarea) {
  font: inherit;
}

.amv-view-shell :where(button) {
  min-height: 42px;
}

.amv-view-shell :where(input, select, textarea) {
  max-width: 100%;
}

.amv-view-shell :where(a, button, input, select, textarea, [role='button']):focus-visible {
  outline: 3px solid var(--amv-ui-focus);
  outline-offset: 3px;
}

.amv-view-shell :where(button, [role='button']):disabled,
.amv-view-shell :where(input, select, textarea):disabled {
  cursor: not-allowed;
}

.amv-view-shell :where(.button, .btn, .lux-button, .amv-primary-btn, .amv-secondary-action,
  .primary-action, .secondary-action, .danger-action, .text-link, .action-link,
  .lightbox__close, .lightbox__nav, .today-button, .quick-action) {
  -webkit-user-select: none;
  user-select: none;
}

/* Premium surface language without changing each view's semantic palette. */
.amv-view-shell :where(.card, .panel, .surface, .summary-card, .metric-card,
  .focus-card, .next-class-card, .insight-card, .agenda-card, .quiz-card,
  .resource-card, .student-card, .lesson-card, .task-card, .format-card,
  .production, .sound-console, .state-card, .empty-card, .workspace,
  .profile-card, .profile-panel, .vocal-card, .weighted-student, .weighted-category) {
  border-radius: var(--amv-ui-radius-md);
}

.amv-view-shell :where(.resource-card, .student-card, .lesson-card, .metric-card,
  .focus-card, .next-class-card, .summary-card, .insight-card, .quiz-card,
  .task-card, .format-card, .production, .state-card, .empty-card) {
  transition:
    transform 180ms ease,
    box-shadow 180ms ease,
    border-color 180ms ease,
    background-color 180ms ease;
}

@media (hover: hover) and (pointer: fine) {
  .amv-view-shell :where(.resource-card, .student-card, .lesson-card, .metric-card,
    .focus-card, .next-class-card, .summary-card, .insight-card, .quiz-card,
    .task-card, .format-card, .production):not(.is-disabled):hover {
    transform: translateY(-2px);
  }
}

/* Toolbars wrap rather than squeezing controls into unreadable rows. */
.amv-view-shell :where(.toolbar, .students-toolbar, .calendar-toolbar, .resources-controls,
  .resources-controls__row, .gradebook-legacy-toolbar, .hero-actions, .actions,
  .action-row, .question-actions, .filters, .public-jump-nav, .classes-header__actions,
  .result-action-row, .form-actions, .footer-actions) {
  min-width: 0;
}

.amv-view-shell :where(.table-shell, .quiz-table-wrap, .table-wrap, .grade-table-wrap,
  .data-table-wrap, .scroll-region, .horizontal-scroll) {
  max-width: 100%;
  overflow-x: auto;
  overflow-y: visible;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: thin;
}

.amv-view-shell :where(.table-shell table, .quiz-table-wrap table, .table-wrap table,
  .grade-table-wrap table, .data-table-wrap table) {
  max-width: none;
}

/* Prevent long controls and badges from forcing page-level horizontal overflow. */
.amv-view-shell :where(.badge, .pill, .chip, .status-pill, .source-badge, .event-chip,
  .lesson-detail, .student-card__voice, .student-card__status, .course-kicker,
  .hero-stat, .count, .filename, .meta, .eyebrow) {
  max-width: 100%;
}

/* Dialogs/lightboxes stay usable on short laptop and phone viewports. */
.amv-view-shell :where(.modal, .dialog, .drawer, .lightbox, .lightbox__content,
  .modal__content, .dialog__content, [role='dialog']) {
  max-width: min(100%, 100vw);
}

.amv-view-shell :where(.modal__content, .dialog__content, .lightbox__content,
  [role='dialog']) {
  max-height: calc(100dvh - 28px);
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Public pages: a cleaner editorial frame around content-heavy sections. */
.amv-view-shell :where(.hero, .hero-panel, .calendar-hero, .resources-hero, .amv-hero,
  .students__header, .gradebook__hero, .classes-header, .contact-hero, .training-hero,
  .academy-hero, .inscription-hero) {
  isolation: isolate;
}

.amv-view-shell :where(.hero__grid, .hero-panel__grid, .resources-hero__grid) {
  min-width: 0;
}

/* Mobile-first resilience. Existing view-specific breakpoints still win where more
   specific rules exist, while these defaults catch edge cases and tiny screens. */
@media (max-width: 760px) {
  .amv-view-shell {
    overflow-x: clip;
  }

  .amv-view-shell :where(.hero, .hero-panel, .amv-hero, .calendar-hero,
    .resources-hero, .classes-header, .students__header, .gradebook__hero) {
    border-radius: 22px;
  }

  .amv-view-shell :where(.hero__grid, .hero-panel__grid, .resources-hero__grid,
    .calendar-layout, .quiz-layout, .program-layout, .student-profile__grid,
    .dashboard-grid, .content-grid, .page-grid, .split-layout) {
    grid-template-columns: minmax(0, 1fr) !important;
  }

  .amv-view-shell :where(.hero-actions, .actions, .action-row, .form-actions,
    .footer-actions, .question-actions, .students__header-actions, .hero-stat,
    .calendar-toolbar, .resources-controls__row) {
    flex-wrap: wrap;
  }

  .amv-view-shell :where(.hero-actions > *, .form-actions > *, .footer-actions > *,
    .question-actions > *, .result-action > *, .result-next-step__actions > *) {
    min-width: min(100%, 190px);
  }

  .amv-view-shell :where(.display-title, .page-title, .hero-title, .section-title,
    .hero-panel__title, .amv-hero h1, .calendar-hero h1, .students__header h1,
    .gradebook__hero h1) {
    font-size: clamp(1.8rem, 7vw, 3rem);
    line-height: 1.05;
  }

  .amv-view-shell :where(.metric-grid, .focus-grid, .student-grid, .resource-grid,
    .lessons-list, .quiz-stack, .summary-grid, .insight-row, .calendar-insight-row,
    .format__grid, .sound__grid, .skills__grid, .productions__grid) {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .amv-view-shell :where(.students-toolbar, .resources-controls, .calendar-toolbar,
    .gradebook-legacy-toolbar, .classes-header, .section-heading, .profile-actions) {
    gap: 10px;
  }

  .amv-view-shell :where(input, select, textarea, .select, .search-input) {
    min-height: 44px;
  }
}

@media (max-width: 520px) {
  .amv-view-shell :where(.metric-grid, .focus-grid, .student-grid, .resource-grid,
    .lessons-list, .quiz-stack, .summary-grid, .insight-row, .calendar-insight-row,
    .format__grid, .sound__grid, .skills__grid, .productions__grid) {
    grid-template-columns: minmax(0, 1fr);
  }

  .amv-view-shell :where(.hero, .hero-panel, .amv-hero, .calendar-hero,
    .resources-hero, .classes-header, .students__header, .gradebook__hero) {
    border-radius: 18px;
  }

  .amv-view-shell :where(.card, .panel, .surface, .summary-card, .metric-card,
    .focus-card, .next-class-card, .insight-card, .agenda-card, .quiz-card,
    .resource-card, .student-card, .lesson-card, .task-card, .format-card,
    .production, .state-card, .empty-card) {
    border-radius: 16px;
  }

  .amv-view-shell :where(.hero-actions > *, .form-actions > *, .footer-actions > *,
    .question-actions > *, .result-action > *, .result-next-step__actions > *) {
    width: 100%;
    min-width: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .amv-view-shell,
  .amv-view-shell :where(*, *::before, *::after) {
    scroll-behavior: auto !important;
    transition-duration: 0.01ms !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
  }
}
</style>
