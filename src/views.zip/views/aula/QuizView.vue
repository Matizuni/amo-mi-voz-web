<template>
  <section class="quiz-page">
    <!-- =====================================================
         LOADING
    ====================================================== -->
    <section
      v-if="isLoading"
      class="quiz-state"
    >
      <div class="quiz-state__spinner"></div>

      <span class="quiz-state__eyebrow">
        EVALUACIÓN
      </span>

      <h1>
        Preparando tu evaluación
      </h1>

      <p>
        Estamos cargando las preguntas y recuperando
        tu avance guardado.
      </p>
    </section>

    <!-- =====================================================
         ERROR
    ====================================================== -->
    <section
      v-else-if="loadError"
      class="quiz-state quiz-state--error"
    >
      <div class="quiz-state__icon">
        !
      </div>

      <span class="quiz-state__eyebrow">
        NO PUDIMOS CONTINUAR
      </span>

      <h1>
        Ocurrió un problema
      </h1>

      <p>
        {{ loadError }}
      </p>

      <div class="quiz-state__actions">
        <button
          type="button"
          @click="loadQuiz"
        >
          Reintentar
        </button>

        <RouterLink
          :to="lessonRoute"
        >
          Volver a la clase
        </RouterLink>
      </div>
    </section>

    <!-- =====================================================
         RESULTADO · PREMIUM LIGHT
    ====================================================== -->
    <section
      v-else-if="submissionResult"
      class="result-screen result-screen--premium"
    >
      <header class="result-hero">
        <div
          class="result-hero__status"
          :class="{
            'result-hero__status--pending':
              submissionResult.requiresManualGrading,
            'result-hero__status--success':
              !submissionResult.requiresManualGrading &&
              submissionResult.passed === true,
            'result-hero__status--reinforce':
              !submissionResult.requiresManualGrading &&
              submissionResult.passed === false
          }"
        >
          <span>
            {{
              submissionResult.requiresManualGrading
                ? '…'
                : submissionResult.passed === false
                  ? '↗'
                  : '✓'
            }}
          </span>
        </div>

        <span class="result-screen__eyebrow">
          {{
            submissionResult.requiresManualGrading
              ? 'EVALUACIÓN ENTREGADA'
              : 'RESULTADO DISPONIBLE'
          }}
        </span>

        <h1>
          {{
            submissionResult.requiresManualGrading
              ? 'Tu evaluación fue enviada'
              : 'Tu evaluación fue corregida'
          }}
        </h1>

        <p>
          {{
            submissionResult.requiresManualGrading
              ? 'Tu entrega quedó registrada correctamente. Algunas respuestas necesitan revisión del profesor.'
              : 'Tu entrega quedó registrada correctamente. Revisa el resultado y continúa con el siguiente paso.'
          }}
        </p>
      </header>

      <div
        v-if="
          submissionResult.score !== null &&
          submissionResult.score !== undefined
        "
        class="result-score result-score--premium"
      >
        <article>
          <span class="result-score__visual">#</span>
          <div>
            <small>PUNTAJE</small>
            <strong>
              {{ formatScore(submissionResult.score) }}
              <em>/ {{ formatScore(submissionResult.maxScore) }}</em>
            </strong>
          </div>
        </article>

        <article
          v-if="
            submissionResult.percentage !== null &&
            submissionResult.percentage !== undefined
          "
        >
          <span class="result-score__visual">%</span>
          <div>
            <small>RESULTADO</small>
            <strong>{{ Math.round(submissionResult.percentage) }}%</strong>
          </div>
        </article>

        <article
          v-if="
            submissionResult.passed !== null &&
            submissionResult.passed !== undefined
          "
        >
          <span class="result-score__visual">✓</span>
          <div>
            <small>ESTADO</small>
            <strong
              :class="{
                'result-score__passed':
                  submissionResult.passed,
                'result-score__failed':
                  !submissionResult.passed
              }"
            >
              {{
                submissionResult.passed
                  ? 'Aprobada'
                  : 'Por reforzar'
              }}
            </strong>
          </div>
        </article>
      </div>

      <div
        v-else
        class="result-notice result-notice--premium"
      >
        <span>✓</span>
        <div>
          <strong>Entrega registrada</strong>
          <p>
            El resultado no está configurado para mostrarse
            inmediatamente.
          </p>
        </div>
      </div>

      <section class="result-guidance result-guidance--premium">
        <article>
          <span>01</span>
          <div>
            <small>TIPO DE EVALUACIÓN</small>
            <strong>
              {{
                quiz?.assessmentType === 'test'
                  ? 'Prueba evaluada'
                  : 'Quiz formativo'
              }}
            </strong>
          </div>
        </article>

        <article>
          <span>02</span>
          <div>
            <small>INTENTOS</small>
            <strong>{{ attemptRuleLabel }}</strong>
          </div>
        </article>

        <article>
          <span>03</span>
          <div>
            <small>SIGUIENTE PASO</small>
            <strong>{{ resultNextStepLabel }}</strong>
          </div>
        </article>
      </section>

      <section class="result-next-step result-next-step--premium">
        <div class="result-next-step__copy">
          <span>SIGUIENTE PASO</span>

          <h2>
            {{
              submissionResult.requiresManualGrading
                ? 'Espera la revisión del profesor'
                : submissionResult.percentage >= 80
                  ? 'Consolida lo aprendido'
                  : 'Revisa tus errores antes de volver a practicar'
            }}
          </h2>

          <p>
            {{
              submissionResult.requiresManualGrading
                ? 'Cuando el profesor termine la corrección podrás revisar el resultado desde Mis evaluaciones.'
                : 'Abre la revisión para ver tus respuestas, detectar qué conceptos reforzar y consultar las explicaciones disponibles.'
            }}
          </p>
        </div>

        <div class="result-next-step__actions">
          <RouterLink
            v-if="reviewAttemptId"
            :to="`/aula/evaluaciones/intento/${reviewAttemptId}`"
            class="result-action result-action--primary"
          >
            <span class="result-action__icon">✓</span>
            <div>
              <small>APRENDER DEL RESULTADO</small>
              <strong>Ver revisión completa</strong>
            </div>
            <b>→</b>
          </RouterLink>

          <RouterLink
            to="/aula/evaluaciones"
            class="result-action"
          >
            <span class="result-action__icon">%</span>
            <div>
              <small>MI HISTORIAL</small>
              <strong>Mis evaluaciones</strong>
            </div>
            <b>→</b>
          </RouterLink>

          <RouterLink
            :to="lessonRoute"
            class="result-action"
          >
            <span class="result-action__icon">♪</span>
            <div>
              <small>VOLVER A ESTUDIAR</small>
              <strong>Material de la clase</strong>
            </div>
            <b>→</b>
          </RouterLink>
        </div>
      </section>

      <section
        v-if="
          !submissionResult.requiresManualGrading &&
          submissionResult.percentage !== null &&
          submissionResult.percentage !== undefined
        "
        class="result-learning-summary result-learning-summary--premium"
        :class="{
          'result-learning-summary--excellent':
            submissionResult.percentage >= 90,
          'result-learning-summary--good':
            submissionResult.percentage >= 70 &&
            submissionResult.percentage < 90,
          'result-learning-summary--reinforce':
            submissionResult.percentage < 70
        }"
      >
        <div class="result-learning-summary__icon">
          {{
            submissionResult.percentage >= 90
              ? '★'
              : submissionResult.percentage >= 70
                ? '✓'
                : '↗'
          }}
        </div>

        <div class="result-learning-summary__content">
          <span>LECTURA PEDAGÓGICA</span>

          <h2>
            {{
              submissionResult.percentage >= 90
                ? 'Dominio muy sólido'
                : submissionResult.percentage >= 70
                  ? 'Buen avance'
                  : 'Hay contenidos que conviene reforzar'
            }}
          </h2>

          <p>
            {{
              submissionResult.percentage >= 90
                ? 'Tu resultado muestra un dominio muy sólido. Revisa igualmente las preguntas para consolidar lo aprendido.'
                : submissionResult.percentage >= 70
                  ? 'Vas por buen camino. La revisión te ayudará a detectar los conceptos que todavía necesitan práctica.'
                  : 'Antes de repetir el quiz, revisa las preguntas incorrectas y vuelve al material de la clase.'
            }}
          </p>

          <div class="result-learning-summary__tips">
            <span>Revisa tus respuestas</span>
            <span>Vuelve al material</span>
            <span>Inténtalo nuevamente</span>
          </div>
        </div>
      </section>

      <div
        v-if="
          quiz?.assessmentType === 'quiz' &&
          canRetakeQuiz
        "
        class="result-practice-card"
      >
        <div>
          <span>PRÁCTICA DISPONIBLE</span>
          <strong>¿Quieres intentarlo nuevamente?</strong>
          <p>
            Repite el quiz cuando quieras comparar tu progreso.
          </p>
        </div>

        <button
          type="button"
          class="button button--primary"
          @click="startNewPracticeAttempt"
        >
          Reintentar quiz
        </button>
      </div>

      <div
        v-else-if="quiz?.assessmentType === 'test'"
        class="result-practice-card result-practice-card--locked"
      >
        <div>
          <span>PRUEBA EVALUADA</span>
          <strong>Intento registrado</strong>
          <p>
            Los intentos disponibles dependen de la configuración
            definida por tu profesor.
          </p>
        </div>
      </div>

      <footer class="result-screen__footer">
        <RouterLink
          to="/aula/programa-formativo"
          class="button button--secondary"
        >
          ← Ver programa completo
        </RouterLink>

        <RouterLink
          :to="lessonRoute"
          class="button button--primary"
        >
          Volver a la clase →
        </RouterLink>
      </footer>
    </section>

    <!-- =====================================================
         QUIZ
    ====================================================== -->
    <template v-else-if="quiz && attempt">
      <!-- TOPBAR -->
      <header class="quiz-topbar">
        <RouterLink
          :to="lessonRoute"
          class="quiz-back"
        >
          <span>←</span>
          Volver a la clase
        </RouterLink>

        <div class="quiz-topbar__status">
          <span
            class="save-indicator"
            :class="{
              'save-indicator--saving':
                isSavingAnyAnswer,
              'save-indicator--error':
                Boolean(saveError)
            }"
          ></span>

          {{
            saveError
              ? 'No se pudo guardar una respuesta'
              : isSavingAnyAnswer
                ? 'Guardando...'
                : 'Respuestas guardadas'
          }}
        </div>
      </header>

      <!-- HERO -->
      <section class="quiz-hero">
        <div class="quiz-hero__main">
          <div class="quiz-hero__eyebrow">
            <span>
              {{
                quiz.assessmentType === 'test'
                  ? 'PRUEBA'
                  : 'QUIZ'
              }}
            </span>

            <span>
              Clase {{ lessonNumberLabel }}
            </span>
          </div>

          <h1>
            {{ quiz.title }}
          </h1>

          <p v-if="quiz.description">
            {{ quiz.description }}
          </p>

          <div
            class="assessment-purpose"
            :class="{
              'assessment-purpose--test':
                quiz.assessmentType === 'test'
            }"
          >
            <strong>
              {{
                quiz.assessmentType === 'test'
                  ? 'Prueba evaluada'
                  : 'Quiz formativo'
              }}
            </strong>

            <span>
              {{
                quiz.assessmentType === 'test'
                  ? 'Tu resultado quedará registrado como evaluación formal.'
                  : 'Úsalo para practicar, detectar errores y reforzar contenidos.'
              }}
            </span>
          </div>

          <div class="quiz-hero__meta">
            <span>
              {{ quiz.totalPoints || totalQuestionPoints }} pts
            </span>

            <span>
              {{ questions.length }}
              {{
                questions.length === 1
                  ? 'pregunta'
                  : 'preguntas'
              }}
            </span>

            <span v-if="quiz.attemptsAllowed">
              {{
                quiz.attemptsAllowed === 1
                  ? '1 intento'
                  : `${quiz.attemptsAllowed} intentos`
              }}
            </span>

            <span v-if="quiz.timeLimitMinutes">
              {{ quiz.timeLimitMinutes }} min
            </span>
          </div>
        </div>

        <aside
          v-if="quiz.timeLimitMinutes"
          class="timer-card"
          :class="{
            'timer-card--warning':
              remainingSeconds <= 300 &&
              remainingSeconds > 60,
            'timer-card--critical':
              remainingSeconds <= 60
          }"
        >
          <small>
            TIEMPO RESTANTE
          </small>

          <strong>
            {{ remainingTimeLabel }}
          </strong>

          <span>
            {{
              remainingSeconds <= 60
                ? 'Entrega pronto'
                : 'Tu progreso se guarda'
            }}
          </span>
        </aside>
      </section>

      <!-- PROGRESS -->
      <section class="quiz-progress">
        <div class="quiz-progress__heading">
          <div>
            <span>
              TU AVANCE
            </span>

            <strong>
              {{ answeredCount }}
              de {{ questions.length }}
              respondidas
            </strong>
          </div>

          <b>
            {{ progressPercentage }}%
          </b>
        </div>

        <div class="quiz-progress__bar">
          <span
            :style="{
              width: `${progressPercentage}%`
            }"
          ></span>
        </div>
      </section>

      <!-- MAIN LAYOUT -->
      <div class="quiz-layout">
        <!-- QUESTION -->
        <main class="question-panel">
          <header class="question-header">
            <div>
              <span class="question-number">
                PREGUNTA
                {{
                  String(
                    currentQuestionIndex + 1,
                  ).padStart(2, '0')
                }}
              </span>

              <span
                v-if="currentQuestion.required"
                class="required-badge"
              >
                Obligatoria
              </span>

              <span class="question-format-badge">
                {{ questionTypeLabel(currentQuestion.type) }}
              </span>
            </div>

            <strong>
              {{ currentQuestion.points }}
              {{
                Number(currentQuestion.points) === 1
                  ? 'punto'
                  : 'puntos'
              }}
            </strong>
          </header>

          <section class="question-content">
            <h2>
              {{ currentQuestion.prompt }}
            </h2>

            <div
              v-if="currentQuestion.mediaUrl"
              class="question-media"
            >
              <div
                v-if="currentQuestion.mediaType === 'audio'"
                class="audio-experience"
              >
                <div class="audio-experience__icon" aria-hidden="true">♪</div>
                <div class="audio-experience__content">
                  <span>ESCUCHA CON ATENCIÓN</span>
                  <strong>Reproduce el audio antes de responder</strong>
                  <audio
                    :src="currentQuestion.mediaUrl"
                    controls
                    preload="metadata"
                  ></audio>
                  <small>Puedes volver a escucharlo mientras la evaluación esté abierta.</small>
                </div>
              </div>

              <img
                v-else-if="currentQuestion.mediaType === 'image'"
                :src="currentQuestion.mediaUrl"
                alt="Material visual de la pregunta"
              >
            </div>

            <!-- SINGLE / TRUE FALSE -->
            <div
              v-if="
                currentQuestion.type === 'single_choice' ||
                currentQuestion.type === 'true_false' ||
                currentQuestion.type === 'audio_choice'
              "
              class="options-list"
            >
              <label
                v-for="option in currentQuestion.options"
                :key="option.id"
                class="option-card"
                :class="{
                  'option-card--selected':
                    isOptionSelected(
                      currentQuestion.id,
                      option.id,
                    )
                }"
              >
                <input
                  type="radio"
                  :name="`question-${currentQuestion.id}`"
                  :value="option.id"
                  :checked="
                    isOptionSelected(
                      currentQuestion.id,
                      option.id,
                    )
                  "
                  @change="
                    selectSingleOption(
                      currentQuestion,
                      option.id,
                    )
                  "
                >

                <span class="option-card__marker">
                  {{
                    optionLetter(
                      currentQuestion.options,
                      option.id,
                    )
                  }}
                </span>

                <strong>
                  {{ option.text }}
                </strong>
              </label>
            </div>

            <!-- MULTIPLE -->
            <div
              v-else-if="
                currentQuestion.type === 'multiple_choice'
              "
              class="options-list"
            >
              <p class="question-hint">
                Puedes seleccionar más de una alternativa.
              </p>

              <label
                v-for="option in currentQuestion.options"
                :key="option.id"
                class="option-card"
                :class="{
                  'option-card--selected':
                    isOptionSelected(
                      currentQuestion.id,
                      option.id,
                    )
                }"
              >
                <input
                  type="checkbox"
                  :value="option.id"
                  :checked="
                    isOptionSelected(
                      currentQuestion.id,
                      option.id,
                    )
                  "
                  @change="
                    toggleMultipleOption(
                      currentQuestion,
                      option.id,
                    )
                  "
                >

                <span class="option-card__marker">
                  {{
                    optionLetter(
                      currentQuestion.options,
                      option.id,
                    )
                  }}
                </span>

                <strong>
                  {{ option.text }}
                </strong>
              </label>
            </div>

            <!-- EMPAREJAMIENTO -->
            <div
              v-else-if="currentQuestion.type === 'matching'"
              class="matching-question interactive-question"
            >
              <div class="interactive-question__intro">
                <div>
                  <span>EMPAREJAMIENTO</span>
                  <p class="question-hint">Relaciona cada concepto con una respuesta. Cada alternativa puede usarse una sola vez.</p>
                </div>
                <strong>{{ getMatchingCompletedCount(currentQuestion) }}/{{ getMatchingPairs(currentQuestion).length }}</strong>
              </div>

              <div class="matching-question__list">
                <label
                  v-for="(pair, pairIndex) in getMatchingPairs(currentQuestion)"
                  :key="`${pair.left}-${pairIndex}`"
                  class="matching-question__row"
                  :class="{
                    'matching-question__row--complete': getMatchingSelection(currentQuestion.id, pair.left)
                  }"
                >
                  <span class="matching-question__number">{{ pairIndex + 1 }}</span>
                  <strong>{{ pair.left }}</strong>
                  <span class="matching-question__arrow" aria-hidden="true">→</span>
                  <select
                    :value="getMatchingSelection(currentQuestion.id, pair.left)"
                    :aria-label="`Relacionar ${pair.left}`"
                    @change="updateMatchingSelection(currentQuestion, pair.left, $event.target.value)"
                  >
                    <option value="">Selecciona una respuesta...</option>
                    <option
                      v-for="choice in getMatchingChoices(currentQuestion)"
                      :key="choice"
                      :value="choice"
                      :disabled="isMatchingChoiceUsed(currentQuestion, pair.left, choice)"
                    >
                      {{ choice }}
                    </option>
                  </select>
                  <button
                    v-if="getMatchingSelection(currentQuestion.id, pair.left)"
                    type="button"
                    class="matching-question__clear"
                    :aria-label="`Borrar relación de ${pair.left}`"
                    @click="updateMatchingSelection(currentQuestion, pair.left, '')"
                  >
                    ×
                  </button>
                </label>
              </div>
            </div>

            <!-- ORDENAR ELEMENTOS -->
            <div
              v-else-if="currentQuestion.type === 'ordering'"
              class="ordering-question interactive-question"
            >
              <div class="interactive-question__intro">
                <div>
                  <span>ORDENAMIENTO</span>
                  <p class="question-hint">Arrastra los elementos o usa las flechas. Cuando estés conforme, confirma el orden.</p>
                </div>
                <strong>{{ getOrderingAnswer(currentQuestion).length }} elementos</strong>
              </div>

              <div class="ordering-question__list">
                <article
                  v-for="(item, itemIndex) in getOrderingAnswer(currentQuestion)"
                  :key="item.id"
                  class="ordering-question__item"
                  :class="{ 'ordering-question__item--dragging': draggedOrderingIndex === itemIndex }"
                  draggable="true"
                  @dragstart="startOrderingDrag(itemIndex)"
                  @dragover.prevent
                  @drop="dropOrderingItem(currentQuestion, itemIndex)"
                  @dragend="endOrderingDrag"
                >
                  <span class="ordering-question__position">{{ itemIndex + 1 }}</span>
                  <span class="ordering-question__handle" aria-hidden="true">⋮⋮</span>
                  <strong>{{ item.text }}</strong>
                  <div class="ordering-question__controls">
                    <button
                      type="button"
                      :disabled="itemIndex === 0"
                      :aria-label="`Mover ${item.text} arriba`"
                      @click="moveOrderingAnswer(currentQuestion, itemIndex, -1)"
                    >↑</button>
                    <button
                      type="button"
                      :disabled="itemIndex === getOrderingAnswer(currentQuestion).length - 1"
                      :aria-label="`Mover ${item.text} abajo`"
                      @click="moveOrderingAnswer(currentQuestion, itemIndex, 1)"
                    >↓</button>
                  </div>
                </article>
              </div>

              <div class="ordering-question__footer">
                <button type="button" class="interactive-secondary" @click="resetOrderingAnswer(currentQuestion)">Restablecer mezcla</button>
                <button type="button" class="interactive-primary" @click="confirmOrderingAnswer(currentQuestion)">✓ Confirmar este orden</button>
              </div>
            </div>

            <!-- SHORT -->
            <div
              v-else-if="
                currentQuestion.type === 'short_answer'
              "
              class="text-answer"
            >
              <label
                :for="`answer-${currentQuestion.id}`"
              >
                Tu respuesta
              </label>

              <input
                :id="`answer-${currentQuestion.id}`"
                :value="
                  getAnswer(
                    currentQuestion.id,
                  ).textAnswer
                "
                type="text"
                maxlength="500"
                placeholder="Escribe tu respuesta aquí..."
                @input="
                  updateTextAnswer(
                    currentQuestion,
                    $event.target.value,
                  )
                "
                @blur="
                  flushQuestionSave(
                    currentQuestion.id,
                  )
                "
              >
            </div>

            <!-- ESSAY -->
            <div
              v-else-if="
                currentQuestion.type === 'essay'
              "
              class="text-answer"
            >
              <label
                :for="`answer-${currentQuestion.id}`"
              >
                Tu respuesta
              </label>

              <textarea
                :id="`answer-${currentQuestion.id}`"
                :value="
                  getAnswer(
                    currentQuestion.id,
                  ).textAnswer
                "
                rows="10"
                maxlength="10000"
                placeholder="Desarrolla tu respuesta..."
                @input="
                  updateTextAnswer(
                    currentQuestion,
                    $event.target.value,
                  )
                "
                @blur="
                  flushQuestionSave(
                    currentQuestion.id,
                  )
                "
              ></textarea>
            </div>

            <div
              v-else
              class="unsupported-question"
            >
              Esta pregunta utiliza un formato que todavía
              no está habilitado.
            </div>
          </section>

          <!-- QUESTION NAV -->
          <footer class="question-actions">
            <button
              type="button"
              class="button button--secondary"
              :disabled="currentQuestionIndex === 0"
              @click="previousQuestion"
            >
              ← Anterior
            </button>

            <div class="question-actions__center">
              <span
                v-if="currentQuestion.required"
              >
                {{
                  isQuestionAnswered(
                    currentQuestion,
                    getAnswer(currentQuestion.id),
                  )
                    ? '✓ Respondida'
                    : 'Respuesta obligatoria'
                }}
              </span>
            </div>

            <button
              v-if="
                currentQuestionIndex <
                questions.length - 1
              "
              type="button"
              class="button button--primary"
              @click="nextQuestion"
            >
              Siguiente →
            </button>

            <button
              v-else
              type="button"
              class="button button--primary"
              @click="openSubmitDialog"
            >
              Revisar y entregar →
            </button>
          </footer>
        </main>

        <!-- SIDEBAR -->
        <aside class="question-sidebar">
          <section class="navigator-card">
            <span class="navigator-card__eyebrow">
              PREGUNTAS
            </span>

            <div class="question-grid">
              <button
                v-for="(question, index) in questions"
                :key="question.id"
                type="button"
                class="question-dot"
                :class="{
                  'question-dot--current':
                    index === currentQuestionIndex,
                  'question-dot--answered':
                    isQuestionAnswered(
                      question,
                      getAnswer(question.id),
                    ),
                  'question-dot--pending':
                    !isQuestionAnswered(
                      question,
                      getAnswer(question.id),
                    ),
                  'question-dot--required':
                    question.required
                }"
                :aria-label="
                  `Ir a pregunta ${index + 1}`
                "
                @click="
                  goToQuestion(index)
                "
              >
                <span>
                  {{ index + 1 }}
                </span>

                <b
                  v-if="
                    isQuestionAnswered(
                      question,
                      getAnswer(question.id),
                    ) &&
                    index !== currentQuestionIndex
                  "
                  aria-hidden="true"
                >
                  ✓
                </b>
              </button>
            </div>

            <div class="navigator-legend">
              <span>
                <i class="legend-box legend-box--current"></i>
                Actual
              </span>

              <span>
                <i class="legend-box legend-box--answered"></i>
                Respondida
              </span>

              <span>
                <i class="legend-box legend-box--pending"></i>
                Pendiente
              </span>
            </div>
          </section>

          <section class="summary-card">
            <span class="navigator-card__eyebrow">
              RESUMEN
            </span>

            <div class="summary-row">
              <span>
                Respondidas
              </span>

              <strong>
                {{ answeredCount }}
              </strong>
            </div>

            <div class="summary-row">
              <span>
                Pendientes
              </span>

              <strong>
                {{ unansweredCount }}
              </strong>
            </div>

            <div class="summary-row">
              <span>
                Obligatorias pendientes
              </span>

              <strong>
                {{ requiredUnansweredCount }}
              </strong>
            </div>

            <button
              type="button"
              class="submit-sidebar-button"
              :disabled="
                isSubmitting ||
                isSavingAnyAnswer ||
                Boolean(saveError)
              "
              @click="openSubmitDialog"
            >
              Entregar evaluación
              <span>→</span>
            </button>
          </section>

          <section
            class="autosave-card"
            :class="{
              'autosave-card--error':
                Boolean(saveError)
            }"
          >
            <div>
              {{ saveError ? '!' : '✓' }}
            </div>

            <p>
              {{
                saveError
                  ? 'Hubo un problema de conexión. Revisa internet antes de entregar.'
                  : 'Tus respuestas se guardan automáticamente mientras avanzas.'
              }}
            </p>
          </section>
        </aside>
      </div>
    </template>

    <!-- =====================================================
         CONFIRMAR ENTREGA
    ====================================================== -->
    <Teleport to="body">
      <Transition name="modal">
        <div
          v-if="showSubmitDialog"
          class="modal-backdrop"
          @click.self="
            !isSubmitting &&
            closeSubmitDialog()
          "
        >
          <article
            class="submit-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="submit-dialog-title"
          >
            <div class="submit-dialog__icon">
              ✓
            </div>

            <span class="submit-dialog__eyebrow">
              ENTREGA FINAL
            </span>

            <h2 id="submit-dialog-title">
              ¿Entregar esta evaluación?
            </h2>

            <p>
              Has respondido
              <strong>{{ answeredCount }}</strong>
              de
              <strong>{{ questions.length }}</strong>
              preguntas.
            </p>

            <div
              v-if="requiredUnansweredCount"
              class="submit-warning"
            >
              <strong>
                Te faltan
                {{ requiredUnansweredCount }}
                {{
                  requiredUnansweredCount === 1
                    ? 'pregunta obligatoria'
                    : 'preguntas obligatorias'
                }}.
              </strong>

              <p>
                Puedes volver y responderlas antes de entregar.
              </p>
            </div>

            <div
              v-else-if="unansweredCount"
              class="submit-notice"
            >
              Quedan {{ unansweredCount }}
              {{
                unansweredCount === 1
                  ? 'pregunta sin responder'
                  : 'preguntas sin responder'
              }}.
            </div>

            <div
              v-else
              class="submit-success"
            >
              <strong>
                ✓ Todas las preguntas están respondidas
              </strong>

              <p>
                Revisa una última vez y entrega cuando estés listo.
              </p>
            </div>

            <div class="submit-dialog__actions">
              <button
                type="button"
                class="button button--secondary"
                :disabled="isSubmitting"
                @click="closeSubmitDialog"
              >
                Seguir revisando
              </button>

              <button
                type="button"
                class="button button--primary"
                :disabled="
                  isSubmitting ||
                  isSavingAnyAnswer ||
                  Boolean(saveError) ||
                  requiredUnansweredCount > 0
                "
                @click="submitEvaluation"
              >
                {{
                  isSubmitting
                    ? 'Entregando...'
                    : 'Sí, entregar'
                }}
              </button>
            </div>
          </article>
        </div>
      </Transition>
    </Teleport>
  </section>
</template>

<script setup>
import {
  computed,
  nextTick,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
} from 'vue'

import {
  RouterLink,
  useRoute,
} from 'vue-router'

import {
  calculateRemainingSeconds,
  fetchAttemptAnswers,
  fetchStudentQuizContent,
  formatRemainingTime,
  saveQuizAnswer,
  startQuizAttempt,
  submitQuizAttempt,
} from '@/services/quizAttemptService'

import {
  fetchLessonById,
  fetchLessons,
} from '@/services/lessonService'

import {
  useAuth,
} from '@/composables/useAuth'

const route = useRoute()

const {
  isStudent,
} = useAuth()

/* =========================================================
   IDS
========================================================= */

const lessonId =
  computed(() =>
    Number(
      route.params.id,
    ),
  )

const quizId =
  computed(() =>
    Number(
      route.params.quizId,
    ),
  )

const lessonRoute =
  computed(() =>
    `/aula/clase/${lessonId.value}`,
  )

const resultStorageKey =
  computed(() =>
    `amv-quiz-result-${quizId.value}`,
  )

const saveResultCache =
  result => {
    try {
      window.localStorage
        .setItem(
          resultStorageKey.value,
          JSON.stringify({
            ...result,
            quizId:
              quizId.value,
            savedAt:
              new Date()
                .toISOString(),
          }),
        )
    } catch {
      // El cache local es solo una ayuda visual.
    }
  }

const readResultCache =
  () => {
    try {
      const raw =
        window.localStorage
          .getItem(
            resultStorageKey.value,
          )

      if (!raw) {
        return null
      }

      const parsed =
        JSON.parse(raw)

      if (
        Number(parsed?.quizId) !==
        Number(quizId.value)
      ) {
        return null
      }

      return parsed
    } catch {
      return null
    }
  }

const clearResultCache =
  () => {
    try {
      window.localStorage
        .removeItem(
          resultStorageKey.value,
        )
    } catch {
      // Sin acción.
    }
  }

/* =========================================================
   ESTADO
========================================================= */

const quiz = ref(null)
const questions = ref([])
const attempt = ref(null)
const lesson = ref(null)
const allLessons = ref([])

const answers = ref({})

const isLoading = ref(true)
const isSubmitting = ref(false)

const loadError = ref('')
const saveError = ref('')

const currentQuestionIndex = ref(0)
const draggedOrderingIndex = ref(null)

const submissionResult = ref(null)

const showSubmitDialog = ref(false)

const remainingSeconds = ref(0)

const resultWasRestored =
  ref(false)

const savingQuestionIds =
  ref(new Set())

const saveTimers =
  new Map()

let timerInterval = null
let hasAutoSubmitted = false

/* =========================================================
   CARGA
========================================================= */

const normalizeStudentQuestion =
  question => {
    const options =
      Array.isArray(
        question?.options,
      )
        ? question.options
        : []

    return {
      ...question,

      id:
        Number(
          question?.id,
        ),

      type:
        question?.type ??
        question?.questionType ??
        question?.question_type ??
        '',

      questionType:
        question?.questionType ??
        question?.question_type ??
        question?.type ??
        '',

      prompt:
        question?.prompt ??
        question?.question ??
        '',

      mediaType:
        question?.mediaType ??
        question?.media_type ??
        'none',

      mediaUrl:
        question?.mediaUrl ??
        question?.media_url ??
        '',

      points:
        Number(
          question?.points ??
          0,
        ),

      required:
        Boolean(
          question?.required,
        ),

      autoGradable:
        Boolean(
          question?.autoGradable ??
          question?.auto_gradable,
        ),

      options:
        options
          .map(
            option => ({
              ...option,

              id:
                Number(
                  option?.id,
                ),

              text:
                option?.text ??
                option?.optionText ??
                option?.option_text ??
                '',

              position:
                Number(
                  option?.position ??
                  0,
                ),
            }),
          )
          .sort(
            (a, b) =>
              Number(
                a.position,
              ) -
              Number(
                b.position,
              ),
          ),
    }
  }

const loadQuiz =
  async () => {
    isLoading.value = true
    loadError.value = ''
    saveError.value = ''
    submissionResult.value = null

    try {
      if (
        !isStudent.value
      ) {
        throw new Error(
          'Esta evaluación está disponible para estudiantes.',
        )
      }

      if (
        !Number.isFinite(
          lessonId.value,
        ) ||
        lessonId.value <= 0 ||
        !Number.isFinite(
          quizId.value,
        ) ||
        quizId.value <= 0
      ) {
        throw new Error(
          'La evaluación solicitada no es válida.',
        )
      }

      const [
        loadedLesson,
        loadedLessons,
        loadedQuiz,
      ] =
        await Promise.all([
          fetchLessonById(
            lessonId.value,
          ),

          fetchLessons(),

          fetchStudentQuizContent(
            quizId.value,
          ),
        ])

      lesson.value =
        loadedLesson

      allLessons.value =
        loadedLessons || []

      quiz.value =
        loadedQuiz

      questions.value =
        Array.isArray(
          loadedQuiz?.questions,
        )
          ? loadedQuiz.questions
              .map(
                normalizeStudentQuestion,
              )
          : []

      /*
       * El RPC seguro puede responder en camelCase o snake_case.
       * Solo bloqueamos si realmente recibimos un lessonId válido
       * y este corresponde a otra clase.
       */
      const loadedQuizLessonId =
        Number(
          loadedQuiz?.lessonId ??
          loadedQuiz?.lesson_id ??
          loadedQuiz?.quiz?.lessonId ??
          loadedQuiz?.quiz?.lesson_id ??
          0,
        )

      if (
        loadedQuizLessonId > 0 &&
        loadedQuizLessonId !==
          Number(
            lessonId.value,
          )
      ) {
        throw new Error(
          'Esta evaluación pertenece a otra clase.',
        )
      }

      if (
        !questions.value.length
      ) {
        throw new Error(
          'La evaluación todavía no tiene preguntas disponibles.',
        )
      }

      /*
       * Si existe un resultado reciente en este dispositivo,
       * lo mostramos antes de iniciar automáticamente otro intento.
       * El servidor sigue siendo quien debe hacer cumplir
       * attempts_allowed.
       */
      const cachedResult =
        readResultCache()

      if (
        cachedResult &&
        cachedResult.status ===
          'submitted'
      ) {
        submissionResult.value =
          cachedResult

        resultWasRestored.value =
          true

        return
      }

      attempt.value =
        await startQuizAttempt(
          quizId.value,
        )

      const savedAnswers =
        await fetchAttemptAnswers(
          attempt.value.id,
        )

      answers.value = {}

      for (
        const question of
        questions.value
      ) {
        answers.value[
          question.id
        ] = {
          questionId:
            question.id,

          selectedOptionIds:
            [],

          textAnswer:
            '',
        }
      }

      for (
        const saved of
        savedAnswers || []
      ) {
        const savedQuestionId =
          Number(
            saved.questionId ??
            saved.question_id,
          )

        if (
          !Number.isFinite(
            savedQuestionId,
          )
        ) {
          continue
        }

        const selectedOptionIds =
          saved.selectedOptionIds ??
          saved.selected_option_ids ??
          []

        const textAnswer =
          saved.textAnswer ??
          saved.text_answer ??
          ''

        answers.value[
          savedQuestionId
        ] = {
          questionId:
            savedQuestionId,

          selectedOptionIds:
            Array.isArray(
              selectedOptionIds,
            )
              ? selectedOptionIds
                  .map(Number)
                  .filter(Number.isFinite)
              : [],

          textAnswer:
            String(
              textAnswer || '',
            ),
        }
      }

      startTimer()
    } catch (error) {
      console.error(
        'Error cargando evaluación:',
        error,
      )

      loadError.value =
        error?.message ||
        'No fue posible cargar la evaluación.'
    } finally {
      isLoading.value = false
    }
  }

/* =========================================================
   NÚMERO ACADÉMICO
========================================================= */

const unitLessons =
  computed(() => {
    const unitId =
      Number(
        lesson.value?.unitId,
      )

    if (!unitId) {
      return []
    }

    return allLessons.value
      .filter(
        item =>
          Number(item.unitId) ===
          unitId,
      )
      .sort(
        (a, b) =>
          Number(a.id) -
          Number(b.id),
      )
  })

const lessonNumber =
  computed(() => {
    const index =
      unitLessons.value
        .findIndex(
          item =>
            Number(item.id) ===
            Number(
              lesson.value?.id,
            ),
        )

    return index >= 0
      ? index + 1
      : 1
  })

const lessonNumberLabel =
  computed(() =>
    String(
      lessonNumber.value,
    ).padStart(2, '0'),
  )

/* =========================================================
   PREGUNTA ACTUAL
========================================================= */

const questionTypeLabel = type => ({
  single_choice: 'Selección única',
  multiple_choice: 'Selección múltiple',
  true_false: 'Verdadero / falso',
  short_answer: 'Respuesta corta',
  essay: 'Desarrollo',
  matching: 'Emparejamiento',
  ordering: 'Ordenamiento',
  audio_choice: 'Escucha y responde',
}[type] || 'Pregunta')

const currentQuestion =
  computed(() =>
    questions.value[
      currentQuestionIndex.value
    ] ||
    questions.value[0] ||
    null,
  )

const getAnswer =
  questionId => {
    return (
      answers.value[
        questionId
      ] || {
        questionId:
          Number(questionId),

        selectedOptionIds:
          [],

        textAnswer:
          '',
      }
    )
  }

/* =========================================================
   DETECTAR RESPUESTAS
   Compatible con estado local y respuestas del RPC
========================================================= */

const isQuestionAnswered = (
  question,
  answer,
) => {
  if (!question || !answer) return false

  const selectedOptionIds =
    answer.selectedOptionIds ??
    answer.selected_option_ids ??
    []

  const textAnswer =
    answer.textAnswer ??
    answer.text_answer ??
    ''

  const questionType =
    question.type ??
    question.questionType ??
    question.question_type ??
    ''

  if ([
    'single_choice',
    'multiple_choice',
    'true_false',
    'audio_choice',
  ].includes(questionType)) {
    return Array.isArray(selectedOptionIds) && selectedOptionIds.length > 0
  }

  if (['short_answer', 'short', 'essay'].includes(questionType)) {
    return Boolean(String(textAnswer || '').trim())
  }

  if (questionType === 'matching') {
    let parsed = null
    try { parsed = JSON.parse(String(textAnswer || '')) } catch { parsed = null }
    const pairs = getMatchingPairs(question)
    if (parsed?.kind !== 'matching' || !pairs.length) return false
    const values = pairs.map(pair => String(parsed.matches?.[pair.left] || '').trim())
    return values.every(Boolean) && new Set(values).size === values.length
  }

  if (questionType === 'ordering') {
    let parsed = null
    try { parsed = JSON.parse(String(textAnswer || '')) } catch { parsed = null }
    return parsed?.kind === 'ordering' &&
      parsed?.confirmed === true &&
      Array.isArray(parsed.items) &&
      parsed.items.length === (question?.options || []).length
  }

  return Boolean(
    (Array.isArray(selectedOptionIds) && selectedOptionIds.length > 0) ||
    String(textAnswer || '').trim(),
  )
}

/* =========================================================
   CONTADORES
========================================================= */

const answeredCount =
  computed(() =>
    questions.value
      .filter(
        question =>
          isQuestionAnswered(
            question,
            getAnswer(question.id),
          ),
      )
      .length,
  )

const unansweredCount =
  computed(() =>
    Math.max(
      0,
      questions.value.length -
      answeredCount.value,
    ),
  )

const requiredUnansweredCount =
  computed(() =>
    questions.value
      .filter(
        question =>
          question.required &&
          !isQuestionAnswered(
            question,
            getAnswer(question.id),
          ),
      )
      .length,
  )

const progressPercentage =
  computed(() => {
    if (
      !questions.value.length
    ) {
      return 0
    }

    return Math.round(
      (
        answeredCount.value /
        questions.value.length
      ) *
        100,
    )
  })

const totalQuestionPoints =
  computed(() =>
    questions.value.reduce(
      (
        total,
        question,
      ) =>
        total +
        Number(
          question.points || 0,
        ),
      0,
    ),
  )

/* =========================================================
   OPCIONES
========================================================= */

const isOptionSelected = (
  questionId,
  optionId,
) => {
  return getAnswer(
    questionId,
  ).selectedOptionIds
    .map(Number)
    .includes(
      Number(optionId),
    )
}

const optionLetter = (
  options,
  optionId,
) => {
  const index =
    options.findIndex(
      option =>
        Number(option.id) ===
        Number(optionId),
    )

  if (
    index < 0
  ) {
    return '•'
  }

  return String.fromCharCode(
    65 + index,
  )
}

const selectSingleOption = (
  question,
  optionId,
) => {
  answers.value = {
    ...answers.value,

    [question.id]: {
      ...getAnswer(
        question.id,
      ),

      selectedOptionIds: [
        Number(optionId),
      ],
    },
  }

  scheduleAnswerSave(
    question.id,
    150,
  )
}

const toggleMultipleOption = (
  question,
  optionId,
) => {
  const current =
    new Set(
      getAnswer(
        question.id,
      ).selectedOptionIds
        .map(Number),
    )

  const parsed =
    Number(optionId)

  if (
    current.has(parsed)
  ) {
    current.delete(parsed)
  } else {
    current.add(parsed)
  }

  answers.value = {
    ...answers.value,

    [question.id]: {
      ...getAnswer(
        question.id,
      ),

      selectedOptionIds:
        Array.from(current),
    },
  }

  scheduleAnswerSave(
    question.id,
    250,
  )
}

/* =========================================================
   EMPAREJAMIENTO · V9
========================================================= */

const parseMatchingOption = option => {
  const raw = String(
    option?.text ?? option?.optionText ?? option?.option_text ?? '',
  )
  const separatorIndex = raw.indexOf('|||')

  if (option?.left && option?.right) {
    return {
      left: String(option.left).trim(),
      right: String(option.right).trim(),
    }
  }

  if (separatorIndex < 0) {
    return { left: raw.trim(), right: raw.trim() }
  }

  return {
    left: raw.slice(0, separatorIndex).trim(),
    right: raw.slice(separatorIndex + 3).trim(),
  }
}

const getMatchingPairs = question =>
  (question?.options || [])
    .map(parseMatchingOption)
    .filter(pair => pair.left && pair.right)

const stableShuffle = (values, seedValue = 1) => {
  const result = [...values]
  let seed = Math.max(1, Number(seedValue) || 1)
  for (let index = result.length - 1; index > 0; index -= 1) {
    seed = (seed * 9301 + 49297) % 233280
    const target = Math.floor((seed / 233280) * (index + 1))
    ;[result[index], result[target]] = [result[target], result[index]]
  }
  return result
}

const getMatchingChoices = question => {
  const choices = getMatchingPairs(question).map(pair => pair.right)
  return stableShuffle(choices, Number(question?.id) + 17)
}

const readStructuredAnswer = questionId => {
  const raw = getAnswer(questionId).textAnswer
  if (!raw) return null
  try { return JSON.parse(raw) } catch { return null }
}

const getMatchingSelection = (questionId, left) => {
  const parsed = readStructuredAnswer(questionId)
  return parsed?.kind === 'matching' ? parsed.matches?.[left] || '' : ''
}

const getMatchingCompletedCount = question =>
  getMatchingPairs(question).filter(pair =>
    Boolean(getMatchingSelection(question.id, pair.left)),
  ).length

const isMatchingChoiceUsed = (question, currentLeft, choice) => {
  const parsed = readStructuredAnswer(question.id)
  if (parsed?.kind !== 'matching') return false
  return Object.entries(parsed.matches || {}).some(([left, selected]) =>
    left !== currentLeft && selected === choice,
  )
}

const updateMatchingSelection = (question, left, value) => {
  const current = readStructuredAnswer(question.id)
  const matches = {
    ...(current?.kind === 'matching' ? current.matches : {}),
  }

  const normalizedValue = String(value || '')
  if (normalizedValue) {
    Object.keys(matches).forEach(key => {
      if (key !== left && matches[key] === normalizedValue) matches[key] = ''
    })
  }
  matches[left] = normalizedValue

  answers.value = {
    ...answers.value,
    [question.id]: {
      ...getAnswer(question.id),
      textAnswer: JSON.stringify({ kind: 'matching', matches }),
    },
  }
  scheduleAnswerSave(question.id, 200)
}

/* =========================================================
   ORDENAR · V9
========================================================= */

const makeInitialOrdering = question => {
  const base = (question?.options || []).map(option => ({
    id: Number(option.id),
    text: option.text,
  }))
  const mixed = stableShuffle(base, Number(question?.id) + 31)

  // Garantiza que no se muestre accidentalmente el orden correcto.
  if (mixed.length > 1 && mixed.every((item, index) => item.id === base[index]?.id)) {
    mixed.push(mixed.shift())
  }
  return mixed
}

const getOrderingAnswer = question => {
  const parsed = readStructuredAnswer(question.id)
  if (parsed?.kind === 'ordering' && Array.isArray(parsed.items)) return parsed.items
  return makeInitialOrdering(question)
}

const persistOrderingState = (question, items, confirmed = false) => {
  answers.value = {
    ...answers.value,
    [question.id]: {
      ...getAnswer(question.id),
      textAnswer: JSON.stringify({ kind: 'ordering', items, confirmed }),
    },
  }
  scheduleAnswerSave(question.id, 200)
}

const moveOrderingAnswer = (question, index, direction) => {
  const items = [...getOrderingAnswer(question)]
  const target = index + direction
  if (target < 0 || target >= items.length) return
  const [item] = items.splice(index, 1)
  items.splice(target, 0, item)
  persistOrderingState(question, items, false)
}

const startOrderingDrag = index => {
  draggedOrderingIndex.value = index
}

const endOrderingDrag = () => {
  draggedOrderingIndex.value = null
}

const dropOrderingItem = (question, targetIndex) => {
  const sourceIndex = draggedOrderingIndex.value
  if (sourceIndex === null || sourceIndex === targetIndex) {
    endOrderingDrag()
    return
  }
  const items = [...getOrderingAnswer(question)]
  const [item] = items.splice(sourceIndex, 1)
  items.splice(targetIndex, 0, item)
  persistOrderingState(question, items, false)
  endOrderingDrag()
}

const resetOrderingAnswer = question => {
  persistOrderingState(question, makeInitialOrdering(question), false)
}

const confirmOrderingAnswer = question => {
  persistOrderingState(question, [...getOrderingAnswer(question)], true)
}

/* =========================================================
   TEXTO
========================================================= */

const updateTextAnswer = (
  question,
  value,
) => {
  answers.value = {
    ...answers.value,

    [question.id]: {
      ...getAnswer(
        question.id,
      ),

      textAnswer:
        String(
          value || '',
        ),
    },
  }

  scheduleAnswerSave(
    question.id,
    700,
  )
}

/* =========================================================
   AUTOGUARDADO
========================================================= */

const isSavingAnyAnswer =
  computed(() =>
    savingQuestionIds.value
      .size > 0,
  )

const setQuestionSaving = (
  questionId,
  saving,
) => {
  const next =
    new Set(
      savingQuestionIds.value,
    )

  if (saving) {
    next.add(
      Number(questionId),
    )
  } else {
    next.delete(
      Number(questionId),
    )
  }

  savingQuestionIds.value =
    next
}

const persistAnswer =
  async questionId => {
    if (
      !attempt.value?.id
    ) {
      return
    }

    const answer =
      getAnswer(
        questionId,
      )

    setQuestionSaving(
      questionId,
      true,
    )

    saveError.value = ''

    try {
      const saved =
        await saveQuizAnswer({
          attemptId:
            attempt.value.id,

          questionId:
            Number(questionId),

          selectedOptionIds:
            answer
              .selectedOptionIds,

          textAnswer:
            answer.textAnswer,
        })

      const savedSelectedOptionIds =
        saved?.selectedOptionIds ??
        saved?.selected_option_ids

      const savedTextAnswer =
        saved?.textAnswer ??
        saved?.text_answer

      answers.value = {
        ...answers.value,

        [questionId]: {
          questionId:
            Number(questionId),

          selectedOptionIds:
            Array.isArray(
              savedSelectedOptionIds,
            )
              ? savedSelectedOptionIds
                  .map(Number)
                  .filter(Number.isFinite)
              : answer.selectedOptionIds,

          textAnswer:
            savedTextAnswer ??
            answer.textAnswer,
        },
      }
    } catch (error) {
      console.error(
        'Error guardando respuesta:',
        error,
      )

      saveError.value =
        error?.message ||
        'No se pudo guardar una respuesta.'
    } finally {
      setQuestionSaving(
        questionId,
        false,
      )
    }
  }

const scheduleAnswerSave = (
  questionId,
  delay = 500,
) => {
  const id =
    Number(questionId)

  if (
    saveTimers.has(id)
  ) {
    clearTimeout(
      saveTimers.get(id),
    )
  }

  const timer =
    setTimeout(
      async () => {
        saveTimers.delete(id)
        await persistAnswer(id)
      },
      delay,
    )

  saveTimers.set(
    id,
    timer,
  )
}

const flushQuestionSave =
  async questionId => {
    const id =
      Number(questionId)

    if (
      saveTimers.has(id)
    ) {
      clearTimeout(
        saveTimers.get(id),
      )

      saveTimers.delete(id)
    }

    await persistAnswer(id)
  }

const flushAllSaves =
  async () => {
    const ids =
      Array.from(
        saveTimers.keys(),
      )

    for (
      const id of ids
    ) {
      clearTimeout(
        saveTimers.get(id),
      )

      saveTimers.delete(id)
    }

    await Promise.all(
      questions.value.map(
        question =>
          persistAnswer(
            question.id,
          ),
      ),
    )
  }

/* =========================================================
   NAVEGACIÓN
========================================================= */

const scrollQuestionTop =
  async () => {
    await nextTick()

    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    })
  }

const goToQuestion =
  index => {
    if (
      index < 0 ||
      index >=
      questions.value.length
    ) {
      return
    }

    currentQuestionIndex.value =
      index

    scrollQuestionTop()
  }

const previousQuestion = () => {
  goToQuestion(
    currentQuestionIndex.value -
      1,
  )
}

const nextQuestion = () => {
  goToQuestion(
    currentQuestionIndex.value +
      1,
  )
}

/* =========================================================
   TIMER
========================================================= */

const remainingTimeLabel =
  computed(() =>
    formatRemainingTime(
      remainingSeconds.value,
    ),
  )

const refreshRemainingTime =
  async () => {
    if (
      !quiz.value
        ?.timeLimitMinutes ||
      !attempt.value
        ?.startedAt
    ) {
      remainingSeconds.value =
        0

      return
    }

    remainingSeconds.value =
      calculateRemainingSeconds(
        attempt.value.startedAt,
        quiz.value
          .timeLimitMinutes,
      )

    if (
      remainingSeconds.value <=
        0 &&
      !hasAutoSubmitted &&
      !submissionResult.value
    ) {
      hasAutoSubmitted = true

      await autoSubmitExpired()
    }
  }

const startTimer = () => {
  stopTimer()

  hasAutoSubmitted = false

  if (
    !quiz.value
      ?.timeLimitMinutes ||
    !attempt.value
      ?.startedAt
  ) {
    return
  }

  refreshRemainingTime()

  timerInterval =
    setInterval(
      refreshRemainingTime,
      1000,
    )
}

const stopTimer = () => {
  if (
    timerInterval
  ) {
    clearInterval(
      timerInterval,
    )

    timerInterval = null
  }
}

const autoSubmitExpired =
  async () => {
    try {
      /*
       * Guardamos todo lo que alcance a estar pendiente.
       * El servidor sigue siendo la autoridad final sobre
       * el tiempo permitido.
       */
      try {
        await flushAllSaves()
      } catch {
        // El RPC puede rechazar saves si el tiempo ya expiró.
      }

      await performSubmit()
    } catch (error) {
      console.error(
        'Error entregando por tiempo:',
        error,
      )

      loadError.value =
        error?.message ||
        'Se acabó el tiempo y no pudimos completar la entrega automáticamente.'
    }
  }

/* =========================================================
   ENTREGA
========================================================= */

const openSubmitDialog = () => {
  showSubmitDialog.value =
    true
}

const closeSubmitDialog = () => {
  if (
    isSubmitting.value
  ) {
    return
  }

  showSubmitDialog.value =
    false
}

const performSubmit =
  async () => {
    if (
      isSubmitting.value ||
      !attempt.value?.id
    ) {
      return
    }

    isSubmitting.value =
      true

    try {
      await flushAllSaves()

      const result =
        await submitQuizAttempt(
          attempt.value.id,
        )

      submissionResult.value = {
        ...result,

        attemptId:
          Number(
            result?.attemptId ??
            result?.attempt_id ??
            attempt.value?.id ??
            0,
          ) || null,

        status:
          'submitted',

        requiresManualGrading:
          Boolean(
            result?.requiresManualGrading ??
            result?.requires_manual_grading ??
            false,
          ),

        score:
          result?.score ??
          null,

        maxScore:
          result?.maxScore ??
          result?.max_score ??
          null,

        percentage:
          result?.percentage ??
          null,

        passed:
          result?.passed ??
          null,
      }

      saveResultCache(
        submissionResult.value,
      )

      resultWasRestored.value =
        false

      showSubmitDialog.value =
        false

      stopTimer()
    } finally {
      isSubmitting.value =
        false
    }
  }

const submitEvaluation =
  async () => {
    if (
      requiredUnansweredCount
        .value > 0
    ) {
      return
    }

    try {
      await performSubmit()
    } catch (error) {
      console.error(
        'Error entregando evaluación:',
        error,
      )

      saveError.value =
        error?.message ||
        'No fue posible entregar la evaluación.'
    }
  }

const reviewAttemptId =
  computed(() => {
    const id =
      Number(
        submissionResult.value
          ?.attemptId ??
        submissionResult.value
          ?.attempt_id ??
        attempt.value
          ?.id ??
        0,
      )

    return (
      Number.isFinite(id) &&
      id > 0
    )
      ? id
      : null
  })

/* =========================================================
   REGLAS DE INTENTOS / RESULTADOS
========================================================= */

const attemptsAllowed =
  computed(() => {
    const value =
      Number(
        quiz.value
          ?.attemptsAllowed,
      )

    if (
      !Number.isFinite(value) ||
      value <= 0
    ) {
      return null
    }

    return value
  })

const currentAttemptNumber =
  computed(() => {
    const value =
      Number(
        attempt.value
          ?.attemptNumber ??
        attempt.value
          ?.attempt_number ??
        submissionResult.value
          ?.attemptNumber ??
        submissionResult.value
          ?.attempt_number ??
        1,
      )

    return (
      Number.isFinite(value) &&
      value > 0
    )
      ? value
      : 1
  })

const canRetakeQuiz =
  computed(() => {
    if (
      quiz.value
        ?.assessmentType !==
      'quiz'
    ) {
      return false
    }

    if (
      attemptsAllowed.value ===
      null
    ) {
      return true
    }

    return (
      currentAttemptNumber.value <
      attemptsAllowed.value
    )
  })

const attemptRuleLabel =
  computed(() => {
    if (
      attemptsAllowed.value ===
      null
    ) {
      return (
        quiz.value
          ?.assessmentType ===
        'quiz'
          ? 'Práctica disponible'
          : 'Según configuración'
      )
    }

    return `${currentAttemptNumber.value} de ${attemptsAllowed.value}`
  })

const resultNextStepLabel =
  computed(() => {
    if (
      submissionResult.value
        ?.requiresManualGrading
    ) {
      return 'Esperar revisión'
    }

    if (
      quiz.value
        ?.assessmentType ===
        'quiz' &&
      canRetakeQuiz.value
    ) {
      return 'Revisar y practicar'
    }

    return 'Continuar aprendiendo'
  })

const startNewPracticeAttempt =
  async () => {
    if (
      !canRetakeQuiz.value
    ) {
      return
    }

    clearResultCache()

    submissionResult.value =
      null

    resultWasRestored.value =
      false

    attempt.value =
      null

    answers.value = {}

    currentQuestionIndex.value =
      0

    await loadQuiz()
  }

/* =========================================================
   HELPERS
========================================================= */

const formatScore =
  value => {
    const number =
      Number(value)

    if (
      !Number.isFinite(number)
    ) {
      return '0'
    }

    return Number.isInteger(
      number,
    )
      ? String(number)
      : number.toFixed(1)
  }

/* =========================================================
   WATCH / LIFECYCLE
========================================================= */

watch(
  () => [
    route.params.id,
    route.params.quizId,
  ],
  async () => {
    stopTimer()

    for (
      const timer of
      saveTimers.values()
    ) {
      clearTimeout(timer)
    }

    saveTimers.clear()

    currentQuestionIndex.value =
      0

    await loadQuiz()
  },
)

onMounted(
  loadQuiz,
)

onBeforeUnmount(() => {
  stopTimer()

  for (
    const timer of
    saveTimers.values()
  ) {
    clearTimeout(timer)
  }

  saveTimers.clear()
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/abstracts/variables' as variables;

/* =========================================================
   PAGE
========================================================= */

.quiz-page {
  width: min(1440px, 100%);
  margin: 0 auto;
  padding:
    clamp(1rem, 2vw, 2rem)
    clamp(1rem, 3vw, 2.5rem)
    5rem;
}

/* =========================================================
   STATE
========================================================= */

.quiz-state,
.result-screen {
  display: grid;
  min-height: 62vh;
  gap: 1rem;
  place-items: center;
  align-content: center;
  text-align: center;
}

.quiz-state__spinner {
  width: 52px;
  height: 52px;
  border:
    3px solid
    rgba(255, 255, 255, 0.1);
  border-top-color:
    variables.$color-primary;
  border-radius: 50%;
  animation:
    spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.quiz-state__eyebrow,
.result-screen__eyebrow {
  color:
    variables.$color-primary;
  font-size: 0.78rem;
  font-weight: 900;
  letter-spacing: 0.16em;
}

.quiz-state h1,
.result-screen h1 {
  max-width: 760px;
  margin: 0;
  font-size:
    clamp(2rem, 5vw, 4rem);
  line-height: 1.05;
}

.quiz-state p,
.result-screen > p {
  max-width: 650px;
  margin: 0;
  color:
    rgba(255, 255, 255, 0.58);
  font-size: 1rem;
  line-height: 1.7;
}

.quiz-state__icon,
.result-screen__icon {
  display: grid;
  width: 72px;
  height: 72px;
  place-items: center;
  border:
    1px solid
    #ef6767;
  border-radius: 50%;
  color: #ff7b7b;
  font-size: 1.7rem;
  font-weight: 900;
}

.result-screen__icon {
  border-color:
    variables.$color-primary;
  color:
    variables.$color-primary;
}

.result-screen__icon--pending {
  font-size: 2rem;
}

.quiz-state__actions,
.result-screen__actions {
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 1rem;
}

.quiz-state__actions button,
.quiz-state__actions a {
  min-height: 46px;
  padding:
    0.75rem
    1rem;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 10px;
  background:
    transparent;
  color:
    variables.$color-primary;
  font: inherit;
  font-weight: 800;
  text-decoration: none;
  cursor: pointer;
}

/* =========================================================
   TOPBAR
========================================================= */

.quiz-topbar {
  display: flex;
  gap: 1rem;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
}

.quiz-back {
  display: inline-flex;
  min-height: 44px;
  gap: 0.55rem;
  align-items: center;
  color:
    rgba(255, 255, 255, 0.75);
  font-size: 0.86rem;
  font-weight: 800;
  text-decoration: none;
}

.quiz-topbar__status {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  color:
    rgba(255, 255, 255, 0.5);
  font-size: 0.8rem;
}

.save-indicator {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background:
    #67d98b;
}

.save-indicator--saving {
  background:
    variables.$color-primary;
  animation:
    pulse 0.8s ease infinite;
}

.save-indicator--error {
  background:
    #ef6767;
}

@keyframes pulse {
  50% {
    opacity: 0.35;
  }
}

/* =========================================================
   HERO
========================================================= */

.quiz-hero {
  display: grid;
  gap: 1.25rem;
  grid-template-columns:
    minmax(0, 1fr)
    auto;
  align-items: stretch;
  margin-bottom: 1rem;
  padding:
    clamp(1.3rem, 3vw, 2.4rem);
  border:
    1px solid
    rgba(255, 196, 0, 0.2);
  border-radius: 22px;
  background:
    radial-gradient(
      circle at top right,
      rgba(255, 196, 0, 0.08),
      transparent 38%
    ),
    variables.$color-surface;
}

.quiz-hero__eyebrow {
  display: flex;
  gap: 0.55rem;
  flex-wrap: wrap;
  margin-bottom: 0.8rem;
}

.quiz-hero__eyebrow span {
  padding:
    0.3rem
    0.55rem;
  border:
    1px solid
    rgba(255, 196, 0, 0.3);
  border-radius: 999px;
  color:
    variables.$color-primary;
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.08em;
}

.quiz-hero h1 {
  max-width: 920px;
  margin: 0;
  font-size:
    clamp(2rem, 4vw, 3.7rem);
  line-height: 1.05;
}

.quiz-hero p {
  max-width: 760px;
  margin:
    0.9rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.6);
  font-size: 0.98rem;
  line-height: 1.7;
}

.quiz-hero__meta {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
  margin-top: 1.2rem;
}

.quiz-hero__meta span {
  padding:
    0.35rem
    0.55rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 8px;
  color:
    rgba(255, 255, 255, 0.6);
  font-size: 0.8rem;
}

.timer-card {
  display: grid;
  min-width: 170px;
  place-items: center;
  align-content: center;
  padding: 1rem;
  border:
    1px solid
    rgba(255, 196, 0, 0.3);
  border-radius: 18px;
  text-align: center;
}

.timer-card small {
  color:
    variables.$color-primary;
  font-size: 0.66rem;
  font-weight: 900;
  letter-spacing: 0.1em;
}

.timer-card strong {
  margin:
    0.4rem
    0;
  color:
    variables.$color-primary;
  font-size: 2rem;
  line-height: 1;
}

.timer-card span {
  color:
    rgba(255, 255, 255, 0.48);
  font-size: 0.75rem;
}

.timer-card--warning {
  border-color:
    #e7a93b;
}

.timer-card--critical {
  border-color:
    #ef6767;
  background:
    rgba(239, 103, 103, 0.06);
}

.timer-card--critical strong,
.timer-card--critical small {
  color:
    #ff8080;
}

.assessment-purpose {
  display: flex;
  gap: 0.65rem;
  align-items: center;
  flex-wrap: wrap;
  margin-top: 1rem;
  padding:
    0.75rem
    0.85rem;
  border:
    1px solid
    rgba(103, 217, 139, 0.26);
  border-radius: 11px;
  background:
    rgba(103, 217, 139, 0.045);
}

.assessment-purpose strong {
  color:
    #8ee3a7;
  font-size: 0.78rem;
}

.assessment-purpose span {
  color:
    rgba(255, 255, 255, 0.57);
  font-size: 0.79rem;
  line-height: 1.5;
}

.assessment-purpose--test {
  border-color:
    rgba(255, 196, 0, 0.28);
  background:
    rgba(255, 196, 0, 0.045);
}

.assessment-purpose--test strong {
  color:
    variables.$color-primary;
}

/* =========================================================
   PROGRESS
========================================================= */

.quiz-progress {
  margin-bottom: 1rem;
  padding: 1rem 1.1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 14px;
  background:
    variables.$color-surface;
}

.quiz-progress__heading {
  display: flex;
  gap: 1rem;
  align-items: end;
  justify-content: space-between;
  margin-bottom: 0.7rem;
}

.quiz-progress__heading span,
.quiz-progress__heading strong {
  display: block;
}

.quiz-progress__heading span {
  margin-bottom: 0.2rem;
  color:
    variables.$color-primary;
  font-size: 0.68rem;
  font-weight: 900;
  letter-spacing: 0.12em;
}

.quiz-progress__heading strong {
  font-size: 0.9rem;
}

.quiz-progress__heading b {
  color:
    variables.$color-primary;
  font-size: 1.2rem;
}

.quiz-progress__bar {
  height: 7px;
  overflow: hidden;
  border-radius: 999px;
  background:
    rgba(255, 255, 255, 0.07);
}

.quiz-progress__bar span {
  display: block;
  width: 0;
  height: 100%;
  border-radius: inherit;
  background:
    variables.$color-primary;
  transition:
    width 0.25s ease;
}

/* =========================================================
   LAYOUT
========================================================= */

.quiz-layout {
  display: grid;
  gap: 1rem;
  grid-template-columns:
    minmax(0, 1fr)
    minmax(260px, 320px);
  align-items: start;
}

/* =========================================================
   QUESTION
========================================================= */

.question-panel {
  overflow: hidden;
  border:
    1px solid
    variables.$color-border;
  border-radius: 20px;
  background:
    variables.$color-surface;
}

.question-header {
  display: flex;
  gap: 1rem;
  align-items: center;
  justify-content: space-between;
  padding:
    1rem
    1.2rem;
  border-bottom:
    1px solid
    variables.$color-border;
}

.question-header > div {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  flex-wrap: wrap;
}

.question-number {
  color:
    variables.$color-primary;
  font-size: 0.72rem;
  font-weight: 900;
  letter-spacing: 0.12em;
}

.required-badge {
  padding:
    0.25rem
    0.45rem;
  border:
    1px solid
    rgba(255, 196, 0, 0.28);
  border-radius: 999px;
  color:
    rgba(255, 255, 255, 0.68);
  font-size: 0.7rem;
  font-weight: 800;
}

.question-header > strong {
  color:
    rgba(255, 255, 255, 0.54);
  font-size: 0.8rem;
}

.question-content {
  min-height: 420px;
  padding:
    clamp(1.2rem, 3vw, 2.2rem);
}

.question-content h2 {
  max-width: 960px;
  margin:
    0
    0
    1.6rem;
  font-size:
    clamp(1.4rem, 3vw, 2rem);
  line-height: 1.35;
}

.question-media {
  margin:
    0
    0
    1.4rem;
}

.question-media audio {
  width: 100%;
}

.question-media img {
  display: block;
  max-width: 100%;
  max-height: 480px;
  object-fit: contain;
  border-radius: 14px;
}

/* =========================================================
   OPTIONS
========================================================= */

.options-list {
  display: grid;
  gap: 0.7rem;
}

.question-hint {
  margin:
    0
    0
    0.2rem;
  color:
    rgba(255, 255, 255, 0.52);
  font-size: 0.86rem;
}

.option-card {
  display: grid;
  min-height: 64px;
  gap: 0.85rem;
  grid-template-columns:
    auto
    auto
    minmax(0, 1fr);
  align-items: center;
  padding:
    0.8rem
    1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 13px;
  background:
    rgba(255, 255, 255, 0.018);
  cursor: pointer;
  transition:
    border-color 0.18s ease,
    background 0.18s ease,
    transform 0.18s ease;
}

.option-card:hover {
  border-color:
    rgba(255, 196, 0, 0.34);
  transform:
    translateY(-1px);
}

.option-card--selected {
  border-color:
    variables.$color-primary;
  background:
    rgba(255, 196, 0, 0.07);
}

.option-card input {
  width: 18px;
  height: 18px;
  accent-color:
    variables.$color-primary;
}

.option-card__marker {
  display: grid;
  width: 36px;
  height: 36px;
  place-items: center;
  border:
    1px solid
    variables.$color-border;
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-size: 0.8rem;
  font-weight: 900;
}

.option-card strong {
  font-size: 0.98rem;
  font-weight: 700;
  line-height: 1.5;
}

/* =========================================================
   TEXT ANSWERS
========================================================= */

.text-answer {
  display: grid;
  gap: 0.55rem;
}

.text-answer label {
  color:
    variables.$color-primary;
  font-size: 0.8rem;
  font-weight: 900;
}

.text-answer input,
.text-answer textarea {
  width: 100%;
  border:
    1px solid
    variables.$color-border;
  border-radius: 12px;
  outline: none;
  background:
    rgba(255, 255, 255, 0.025);
  color:
    variables.$color-white;
  font: inherit;
  font-size: 1rem;
}

.text-answer input {
  min-height: 52px;
  padding:
    0
    0.9rem;
}

.text-answer textarea {
  min-height: 200px;
  padding: 0.9rem;
  resize: vertical;
  line-height: 1.65;
}

.text-answer input:focus,
.text-answer textarea:focus {
  border-color:
    variables.$color-primary;
}

.unsupported-question {
  padding: 1rem;
  border:
    1px dashed
    variables.$color-border;
  border-radius: 12px;
  color:
    rgba(255, 255, 255, 0.55);
}

/* =========================================================
   ACTIONS
========================================================= */

.question-actions {
  display: grid;
  gap: 0.75rem;
  grid-template-columns:
    auto
    1fr
    auto;
  align-items: center;
  padding:
    1rem
    1.2rem;
  border-top:
    1px solid
    variables.$color-border;
}

.question-actions__center {
  text-align: center;
}

.question-actions__center span {
  color:
    rgba(255, 255, 255, 0.5);
  font-size: 0.76rem;
}

.button {
  display: inline-flex;
  min-height: 46px;
  gap: 0.5rem;
  align-items: center;
  justify-content: center;
  padding:
    0.72rem
    1rem;
  border-radius: 10px;
  font: inherit;
  font-size: 0.84rem;
  font-weight: 900;
  text-decoration: none;
  cursor: pointer;
}

.button:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}

.button--primary {
  border:
    1px solid
    variables.$color-primary;
  background:
    variables.$color-primary;
  color: #080808;
}

.button--secondary {
  border:
    1px solid
    variables.$color-border;
  background:
    transparent;
  color:
    variables.$color-white;
}

/* =========================================================
   SIDEBAR
========================================================= */

.question-sidebar {
  position: sticky;
  top: 1rem;
  display: grid;
  gap: 0.8rem;
}

.navigator-card,
.summary-card,
.autosave-card {
  padding: 1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 16px;
  background:
    variables.$color-surface;
}

.navigator-card__eyebrow {
  display: block;
  margin-bottom: 0.8rem;
  color:
    variables.$color-primary;
  font-size: 0.68rem;
  font-weight: 900;
  letter-spacing: 0.12em;
}

.question-grid {
  display: grid;
  gap: 0.45rem;
  grid-template-columns:
    repeat(
      5,
      minmax(0, 1fr)
    );
}

.question-dot {
  aspect-ratio: 1;
  min-height: 42px;
  border:
    1px solid
    variables.$color-border;
  border-radius: 10px;
  background:
    transparent;
  color:
    rgba(255, 255, 255, 0.55);
  font: inherit;
  font-size: 0.78rem;
  font-weight: 900;
  cursor: pointer;
}

.question-dot {
  position: relative;
}

.question-dot > span {
  position: relative;
  z-index: 1;
}

.question-dot > b {
  position: absolute;
  right: 5px;
  bottom: 4px;
  color:
    #8ee3a7;
  font-size: 0.62rem;
  line-height: 1;
}

.question-dot--pending {
  border-color:
    rgba(255, 255, 255, 0.11);
  background:
    rgba(255, 255, 255, 0.018);
  color:
    rgba(255, 255, 255, 0.5);
}

.question-dot--answered {
  border-color:
    rgba(103, 217, 139, 0.62);
  background:
    rgba(103, 217, 139, 0.12);
  color:
    #9be7b0;
  box-shadow:
    inset 0 0 0 1px
    rgba(103, 217, 139, 0.08);
}

.question-dot--answered:hover {
  border-color:
    #79df98;
  background:
    rgba(103, 217, 139, 0.18);
}

.question-dot--current,
.question-dot--current.question-dot--answered {
  border-color:
    variables.$color-primary;
  background:
    variables.$color-primary;
  color: #080808;
  box-shadow:
    0 0 0 3px
    rgba(255, 196, 0, 0.12);
}

.question-dot--current > b {
  display: none;
}

.question-dot--required:not(
  .question-dot--answered
) {
  box-shadow:
    inset 0 0 0 1px
    rgba(255, 255, 255, 0.05);
}

.navigator-legend {
  display: flex;
  gap: 0.7rem;
  flex-wrap: wrap;
  margin-top: 0.8rem;
  color:
    rgba(255, 255, 255, 0.44);
  font-size: 0.7rem;
}

.navigator-legend span {
  display: flex;
  gap: 0.35rem;
  align-items: center;
}

.legend-box {
  width: 10px;
  height: 10px;
  border:
    1px solid
    variables.$color-border;
  border-radius: 3px;
}

.legend-box--current {
  border-color:
    variables.$color-primary;
  background:
    variables.$color-primary;
}

.legend-box--answered {
  border-color:
    rgba(103, 217, 139, 0.62);
  background:
    rgba(103, 217, 139, 0.18);
}

.legend-box--pending {
  border-color:
    rgba(255, 255, 255, 0.15);
  background:
    rgba(255, 255, 255, 0.025);
}

.summary-row {
  display: flex;
  gap: 1rem;
  align-items: center;
  justify-content: space-between;
  padding:
    0.55rem
    0;
  border-bottom:
    1px solid
    rgba(255, 255, 255, 0.05);
}

.summary-row span {
  color:
    rgba(255, 255, 255, 0.52);
  font-size: 0.8rem;
}

.summary-row strong {
  color:
    variables.$color-primary;
}

.submit-sidebar-button {
  display: flex;
  width: 100%;
  min-height: 48px;
  gap: 0.5rem;
  align-items: center;
  justify-content: space-between;
  margin-top: 0.8rem;
  padding:
    0
    0.9rem;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 10px;
  background:
    variables.$color-primary;
  color: #080808;
  font: inherit;
  font-size: 0.8rem;
  font-weight: 900;
  cursor: pointer;
}

.submit-sidebar-button:disabled {
  opacity: 0.5;
  cursor: wait;
}

.autosave-card {
  display: flex;
  gap: 0.75rem;
  align-items: flex-start;
}

.autosave-card > div {
  display: grid;
  width: 32px;
  height: 32px;
  flex-shrink: 0;
  place-items: center;
  border:
    1px solid
    rgba(255, 196, 0, 0.3);
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-weight: 900;
}

.autosave-card p {
  margin: 0;
  color:
    rgba(255, 255, 255, 0.48);
  font-size: 0.76rem;
  line-height: 1.55;
}

.autosave-card--error {
  border-color:
    rgba(239, 103, 103, 0.45);
  background:
    rgba(239, 103, 103, 0.055);
}

.autosave-card--error > div {
  border-color:
    rgba(239, 103, 103, 0.55);
  color:
    #ff8585;
}

/* =========================================================
   MODAL
========================================================= */

.modal-backdrop {
  position: fixed;
  z-index: 9999;
  inset: 0;
  display: grid;
  place-items: center;
  padding: 1rem;
  background:
    rgba(0, 0, 0, 0.78);
  backdrop-filter:
    blur(9px);
}

.submit-dialog {
  width: min(520px, 100%);
  padding:
    clamp(1.3rem, 3vw, 2rem);
  border:
    1px solid
    rgba(255, 196, 0, 0.25);
  border-radius: 20px;
  background:
    #111;
  box-shadow:
    0 25px 80px
    rgba(0, 0, 0, 0.55);
}

.submit-dialog__icon {
  display: grid;
  width: 54px;
  height: 54px;
  place-items: center;
  margin-bottom: 1rem;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-size: 1.2rem;
  font-weight: 900;
}

.submit-dialog__eyebrow {
  color:
    variables.$color-primary;
  font-size: 0.7rem;
  font-weight: 900;
  letter-spacing: 0.13em;
}

.submit-dialog h2 {
  margin:
    0.4rem
    0
    0;
  font-size:
    clamp(1.5rem, 4vw, 2rem);
}

.submit-dialog > p {
  margin:
    0.7rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.58);
  line-height: 1.6;
}

.submit-warning,
.submit-notice {
  margin-top: 1rem;
  padding: 0.9rem;
  border:
    1px solid
    #d89a42;
  border-radius: 11px;
  background:
    rgba(216, 154, 66, 0.06);
}

.submit-warning strong {
  color:
    #efb55c;
}

.submit-warning p,
.submit-notice {
  color:
    rgba(255, 255, 255, 0.58);
  font-size: 0.82rem;
  line-height: 1.55;
}

.submit-warning p {
  margin:
    0.35rem
    0
    0;
}


.submit-success {
  margin-top: 1rem;
  padding: 0.9rem;
  border:
    1px solid
    rgba(103, 217, 139, 0.38);
  border-radius: 11px;
  background:
    rgba(103, 217, 139, 0.055);
}

.submit-success strong {
  color:
    #79df98;
}

.submit-success p {
  margin:
    0.3rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.58);
  font-size: 0.82rem;
  line-height: 1.55;
}

.submit-dialog__actions {
  display: flex;
  gap: 0.7rem;
  justify-content: flex-end;
  margin-top: 1.2rem;
}

.modal-enter-active,
.modal-leave-active {
  transition:
    opacity 0.18s ease;
}

.modal-enter-from,
.modal-leave-to {
  opacity: 0;
}

.result-guidance {
  display: grid;
  width: min(760px, 100%);
  gap: 0.7rem;
  grid-template-columns:
    repeat(
      3,
      minmax(0, 1fr)
    );
  margin-top: 0.9rem;
}

.result-guidance > div {
  padding: 1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 13px;
  background:
    variables.$color-surface;
  text-align: left;
}

.result-guidance small,
.result-guidance strong {
  display: block;
}

.result-guidance small {
  margin-bottom: 0.3rem;
  color:
    rgba(255, 255, 255, 0.43);
  font-size: 0.66rem;
  font-weight: 900;
  letter-spacing: 0.08em;
}

.result-guidance strong {
  font-size: 0.9rem;
}

.result-learning-box {
  width: min(760px, 100%);
  margin-top: 0.9rem;
  padding: 1.1rem;
  border:
    1px solid
    rgba(103, 217, 139, 0.3);
  border-radius: 15px;
  background:
    linear-gradient(
      135deg,
      rgba(103, 217, 139, 0.055),
      transparent 70%
    ),
    variables.$color-surface;
  text-align: left;
}

.result-learning-box > span {
  color:
    #8ee3a7;
  font-size: 0.68rem;
  font-weight: 900;
  letter-spacing: 0.12em;
}

.result-learning-box h2 {
  margin:
    0.35rem
    0
    0;
  font-size: 1.25rem;
}

.result-learning-box p {
  margin:
    0.45rem
    0
    0.9rem;
  color:
    rgba(255, 255, 255, 0.56);
  font-size: 0.88rem;
  line-height: 1.6;
}

.result-learning-box--locked {
  border-color:
    rgba(255, 196, 0, 0.28);
  background:
    linear-gradient(
      135deg,
      rgba(255, 196, 0, 0.05),
      transparent 70%
    ),
    variables.$color-surface;
}

.result-learning-box--locked > span {
  color:
    variables.$color-primary;
}

.result-next-step {
  width: min(900px, 100%);
  margin-top: 1rem;
  padding:
    clamp(1rem, 3vw, 1.4rem);
  border:
    1px solid
    rgba(255, 196, 0, 0.25);
  border-radius: 18px;
  background:
    radial-gradient(
      circle at 100% 0%,
      rgba(255, 196, 0, 0.075),
      transparent 35%
    ),
    variables.$color-surface;
  text-align: left;
}

.result-next-step__copy > span,
.result-learning-summary span {
  color:
    variables.$color-primary;
  font-size: 0.68rem;
  font-weight: 900;
  letter-spacing: 0.12em;
}

.result-next-step__copy h2,
.result-learning-summary h2 {
  margin:
    0.35rem
    0
    0;
  font-size:
    clamp(1.3rem, 3vw, 1.8rem);
}

.result-next-step__copy p,
.result-learning-summary p {
  max-width: 760px;
  margin:
    0.45rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.56);
  font-size: 0.88rem;
  line-height: 1.65;
}

.result-next-step__actions {
  display: grid;
  gap: 0.7rem;
  grid-template-columns:
    repeat(
      3,
      minmax(0, 1fr)
    );
  margin-top: 1rem;
}

.result-action {
  display: grid;
  min-height: 78px;
  gap: 0.75rem;
  grid-template-columns:
    auto
    minmax(0, 1fr)
    auto;
  align-items: center;
  padding:
    0.85rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 13px;
  color:
    variables.$color-white;
  text-decoration: none;
  transition:
    border-color 0.18s ease,
    background 0.18s ease,
    transform 0.18s ease;
}

.result-action:hover {
  border-color:
    rgba(255, 196, 0, 0.42);
  background:
    rgba(255, 196, 0, 0.035);
  transform:
    translateY(-1px);
}

.result-action--primary {
  border-color:
    variables.$color-primary;
  background:
    rgba(255, 196, 0, 0.065);
}

.result-action__icon {
  display: grid;
  width: 42px;
  height: 42px;
  place-items: center;
  border:
    1px solid
    rgba(255, 196, 0, 0.3);
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-weight: 900;
}

.result-action small,
.result-action strong {
  display: block;
}

.result-action small {
  margin-bottom: 0.2rem;
  color:
    rgba(255, 255, 255, 0.4);
  font-size: 0.6rem;
  font-weight: 900;
  letter-spacing: 0.08em;
}

.result-action strong {
  font-size: 0.85rem;
  line-height: 1.35;
}

.result-action b {
  color:
    variables.$color-primary;
  font-size: 1rem;
}

.result-learning-summary {
  display: grid;
  width: min(900px, 100%);
  gap: 1rem;
  grid-template-columns:
    auto
    minmax(0, 1fr);
  align-items: start;
  margin-top: 0.8rem;
  padding: 1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 15px;
  background:
    variables.$color-surface;
  text-align: left;
}

.result-learning-summary__icon {
  display: grid;
  width: 48px;
  height: 48px;
  place-items: center;
  border:
    1px solid
    variables.$color-primary;
  border-radius: 50%;
  color:
    variables.$color-primary;
  font-size: 1rem;
  font-weight: 900;
}

.result-learning-summary--excellent {
  border-color:
    rgba(103, 217, 139, 0.34);
}

.result-learning-summary--excellent
.result-learning-summary__icon {
  border-color:
    #79df98;
  color:
    #79df98;
}

.result-learning-summary--good {
  border-color:
    rgba(255, 196, 0, 0.3);
}

.result-learning-summary--reinforce {
  border-color:
    rgba(239, 103, 103, 0.34);
}

.result-learning-summary--reinforce
.result-learning-summary__icon {
  border-color:
    #ef8585;
  color:
    #ef8585;
}

.result-screen__actions--secondary {
  margin-top: 0.75rem;
}

/* =========================================================
   RESULT
========================================================= */

.result-score {
  display: grid;
  width: min(680px, 100%);
  gap: 0.7rem;
  grid-template-columns:
    repeat(
      3,
      minmax(0, 1fr)
    );
  margin-top: 0.8rem;
}

.result-score > div {
  padding: 1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 14px;
  background:
    variables.$color-surface;
}

.result-score small,
.result-score strong {
  display: block;
}

.result-score small {
  margin-bottom: 0.35rem;
  color:
    rgba(255, 255, 255, 0.48);
  font-size: 0.68rem;
  font-weight: 900;
}

.result-score strong {
  color:
    variables.$color-primary;
  font-size: 1.3rem;
}

.result-score__passed {
  color:
    #6ed58b !important;
}

.result-score__failed {
  color:
    #ef7878 !important;
}

.result-notice {
  width: min(580px, 100%);
  margin-top: 0.8rem;
  padding: 1rem;
  border:
    1px solid
    variables.$color-border;
  border-radius: 13px;
  background:
    variables.$color-surface;
}

.result-notice p {
  margin:
    0.35rem
    0
    0;
  color:
    rgba(255, 255, 255, 0.5);
  font-size: 0.86rem;
}

/* =========================================================
   ACCESSIBILITY
========================================================= */

.quiz-page button,
.quiz-page a {
  min-height: 44px;
}

.quiz-page button:focus-visible,
.quiz-page a:focus-visible,
.quiz-page input:focus-visible,
.quiz-page textarea:focus-visible {
  outline:
    3px solid
    rgba(255, 196, 0, 0.62);
  outline-offset: 3px;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (
  max-width: 980px
) {
  .quiz-layout {
    grid-template-columns: 1fr;
  }

  .question-sidebar {
    position: static;
    grid-template-columns:
      repeat(
        2,
        minmax(0, 1fr)
      );
  }

  .autosave-card {
    grid-column:
      1 / -1;
  }
}

@media (
  max-width: 720px
) {
  .quiz-page {
    padding:
      0.85rem
      0.75rem
      4rem;
  }

  .quiz-topbar {
    align-items: flex-start;
    flex-direction: column;
  }

  .quiz-hero {
    grid-template-columns: 1fr;
  }

  .timer-card {
    min-width: 0;
  }

  .question-content {
    min-height: 360px;
    padding: 1rem;
  }

  .question-actions {
    grid-template-columns:
      1fr
      1fr;
  }

  .question-actions__center {
    grid-column:
      1 / -1;
    grid-row: 1;
  }

  .question-sidebar {
    grid-template-columns: 1fr;
  }

  .autosave-card {
    grid-column: auto;
  }

  .result-score,
  .result-guidance,
  .result-next-step__actions {
    grid-template-columns: 1fr;
  }

  .submit-dialog__actions {
    flex-direction: column-reverse;
  }

  .submit-dialog__actions .button {
    width: 100%;
  }
}

@media (
  max-width: 480px
) {
  .question-grid {
    grid-template-columns:
      repeat(
        4,
        minmax(0, 1fr)
      );
  }

  .option-card {
    gap: 0.6rem;
    grid-template-columns:
      auto
      minmax(0, 1fr);
  }

  .option-card input {
    display: none;
  }

  .option-card__marker {
    width: 34px;
    height: 34px;
  }

  .question-actions {
    grid-template-columns: 1fr;
  }

  .question-actions__center {
    grid-column: auto;
  }

  .question-actions .button {
    width: 100%;
  }
}


/* =========================================================
   V7.3 · QUIZ VIEW · PREMIUM LIGHT LMS
   Experiencia de evaluación del estudiante
========================================================= */

.quiz-page,
.quiz-view,
.quiz-shell {
  --quiz-ink: #152033;
  --quiz-ink-soft: #344359;
  --quiz-muted: #6f7c8f;
  --quiz-muted-2: #8b98aa;
  --quiz-line: #dbe3ec;
  --quiz-line-strong: #cbd6e2;
  --quiz-surface: #ffffff;
  --quiz-surface-soft: #f7f9fc;
  --quiz-wine: #9f1945;
  --quiz-wine-dark: #7f1237;
  --quiz-gold: #d9a91d;
  --quiz-gold-dark: #987000;
  --quiz-gold-soft: #fff8e7;
  --quiz-green: #2d8a63;
  --quiz-green-soft: #edf8f3;
  --quiz-blue: #3f6fa8;
  --quiz-blue-soft: #eef5fc;
  --quiz-danger: #be4856;
  --quiz-danger-soft: #fff3f5;
}

/* Fallback para la raíz real del componente */
:deep(.quiz-page),
:deep(.quiz-view),
:deep(.quiz-shell) {
  color: var(--quiz-ink);
}

/* =========================================================
   TOPBAR
========================================================= */

.quiz-topbar {
  margin-bottom: 18px;
  padding: 0 2px;
}

.quiz-back {
  color: #718096 !important;
  font-weight: 800;
}

.quiz-back:hover {
  color: var(--quiz-wine) !important;
}

.quiz-topbar__status {
  color: #657386 !important;
  font-size: .64rem;
  font-weight: 750;
}

.save-indicator {
  background: var(--quiz-green) !important;
  box-shadow: 0 0 0 4px rgba(45,138,99,.08);
}

.save-indicator--saving {
  background: var(--quiz-gold) !important;
}

.save-indicator--error {
  background: var(--quiz-danger) !important;
}

/* =========================================================
   HERO
========================================================= */

.quiz-hero {
  position: relative;
  display: flex;
  gap: 28px;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
  padding: 28px 30px;
  overflow: hidden;
  border: 1px solid var(--quiz-line) !important;
  border-radius: 22px;
  background:
    radial-gradient(circle at 92% 8%, rgba(217,169,29,.12), transparent 30%),
    linear-gradient(135deg, #fff 0%, #fbfcfe 68%, #fffaf0 100%) !important;
  box-shadow: 0 14px 36px rgba(31,48,73,.055);
}

.quiz-hero::before {
  position: absolute;
  top: 0;
  left: 0;
  width: 130px;
  height: 3px;
  content: '';
  background: linear-gradient(90deg, var(--quiz-wine), var(--quiz-gold));
}

.quiz-hero__eyebrow {
  gap: 7px;
  margin-bottom: 12px;
}

.quiz-hero__eyebrow span {
  padding: 6px 9px;
  border: 1px solid #e1d08f !important;
  border-radius: 999px;
  color: var(--quiz-gold-dark) !important;
  background: var(--quiz-gold-soft) !important;
  font-size: .53rem;
  font-weight: 900;
  letter-spacing: .07em;
}

.quiz-hero h1 {
  color: var(--quiz-ink) !important;
  font-size: clamp(2.45rem, 5.2vw, 4.5rem);
  line-height: .98;
  letter-spacing: -.045em;
}

.quiz-hero__main > p {
  max-width: 760px;
  color: var(--quiz-muted) !important;
  font-size: .8rem;
  line-height: 1.65;
}

.assessment-purpose {
  margin-top: 16px;
  padding: 13px 14px;
  border: 1px solid #cfe3d8 !important;
  border-radius: 12px;
  background: var(--quiz-green-soft) !important;
}

.assessment-purpose strong {
  color: var(--quiz-green) !important;
}

.assessment-purpose span {
  color: #577565 !important;
}

.assessment-purpose--test {
  border-color: #e8d69d !important;
  background: var(--quiz-gold-soft) !important;
}

.assessment-purpose--test strong {
  color: var(--quiz-gold-dark) !important;
}

.assessment-purpose--test span {
  color: #7d7048 !important;
}

.quiz-hero__meta {
  gap: 7px;
  margin-top: 14px;
}

.quiz-hero__meta span {
  padding: 6px 9px;
  border: 1px solid #dfe5ec !important;
  border-radius: 999px;
  color: #68768a !important;
  background: #fff !important;
  font-size: .55rem;
}

/* =========================================================
   TIMER
========================================================= */

.timer-card {
  min-width: 175px;
  padding: 16px;
  border: 1px solid #ead79c !important;
  border-radius: 14px;
  background: var(--quiz-gold-soft) !important;
  box-shadow: none !important;
}

.timer-card small {
  color: #8b7c4d !important;
}

.timer-card strong {
  color: var(--quiz-gold-dark) !important;
}

.timer-card span {
  color: #7c704e !important;
}

.timer-card--warning {
  border-color: #efd79e !important;
  background: #fff7e8 !important;
}

.timer-card--critical {
  border-color: #efcbd1 !important;
  background: var(--quiz-danger-soft) !important;
}

.timer-card--critical strong {
  color: var(--quiz-danger) !important;
}

/* =========================================================
   PROGRESO
========================================================= */

.quiz-progress {
  margin-bottom: 16px;
  padding: 16px 18px;
  border: 1px solid var(--quiz-line) !important;
  border-radius: 15px;
  background: #fff !important;
  box-shadow: 0 7px 20px rgba(31,48,73,.03);
}

.quiz-progress__heading > div > span {
  color: var(--quiz-gold-dark) !important;
  font-size: .52rem;
  font-weight: 900;
  letter-spacing: .11em;
}

.quiz-progress__heading strong {
  color: var(--quiz-ink-soft) !important;
}

.quiz-progress__heading b {
  color: var(--quiz-gold-dark) !important;
  font-size: 1rem;
}

.quiz-progress__bar {
  height: 7px;
  margin-top: 11px;
  border-radius: 999px;
  background: #e8edf2 !important;
}

.quiz-progress__bar span {
  background: linear-gradient(90deg, #b98a00, #d9a91d) !important;
}

/* =========================================================
   LAYOUT
========================================================= */

.quiz-layout {
  gap: 14px;
}

.quiz-main {
  min-width: 0;
}

.quiz-sidebar {
  gap: 12px;
}

/* =========================================================
   TARJETA DE PREGUNTA
========================================================= */

.question-card {
  overflow: hidden;
  border: 1px solid var(--quiz-line) !important;
  border-radius: 18px;
  background: #fff !important;
  box-shadow: 0 9px 26px rgba(31,48,73,.04);
}

.question-card__top {
  padding: 16px 20px;
  border-bottom: 1px solid #e7ecf1 !important;
  background: #f8fafc !important;
}

.question-card__top > div:first-child > span:first-child,
.question-card__eyebrow {
  color: var(--quiz-gold-dark) !important;
  font-size: .55rem;
  font-weight: 900;
  letter-spacing: .1em;
}

.question-required {
  border-color: #e4d18d !important;
  color: #7b5d00 !important;
  background: var(--quiz-gold-soft) !important;
}

.question-points {
  color: #68768a !important;
}

.question-card__body {
  padding: 24px 22px;
}

.question-card__body h2 {
  max-width: 900px;
  margin-bottom: 12px;
  color: var(--quiz-ink) !important;
  font-size: clamp(1.45rem,3vw,2.2rem);
  line-height: 1.2;
  letter-spacing: -.025em;
}

.question-help {
  color: var(--quiz-muted) !important;
  font-size: .68rem;
}

/* =========================================================
   OPCIONES
========================================================= */

.answer-options {
  gap: 10px;
  margin-top: 18px;
}

.answer-option {
  min-height: 70px;
  padding: 14px 16px;
  border: 1px solid #dfe5ec !important;
  border-radius: 13px;
  color: var(--quiz-ink) !important;
  background: #fbfcfe !important;
  transition:
    border-color .18s ease,
    background .18s ease,
    box-shadow .18s ease,
    transform .18s ease;
}

.answer-option:hover {
  border-color: #c9d5e0 !important;
  background: #fff !important;
  box-shadow: 0 6px 18px rgba(31,48,73,.04);
  transform: translateY(-1px);
}

.answer-option--selected {
  border-color: #d8b02d !important;
  background: #fffaf0 !important;
  box-shadow: inset 0 0 0 1px rgba(216,176,45,.12);
}

.answer-option__letter {
  border: 1px solid #d6dee7 !important;
  color: #68768a !important;
  background: #fff !important;
}

.answer-option--selected .answer-option__letter {
  border-color: #d7b02f !important;
  color: #6d5200 !important;
  background: #f3d15d !important;
}

.answer-option__text,
.answer-option strong,
.answer-option span {
  color: var(--quiz-ink-soft) !important;
}

.answer-option input[type="checkbox"],
.answer-option input[type="radio"] {
  accent-color: var(--quiz-wine);
}

/* =========================================================
   RESPUESTAS ABIERTAS
========================================================= */

.text-answer,
textarea,
input[type="text"].text-answer {
  border: 1px solid var(--quiz-line-strong) !important;
  color: var(--quiz-ink) !important;
  background: #fbfcfe !important;
}

.text-answer:focus,
textarea:focus {
  border-color: #aebfd0 !important;
  background: #fff !important;
  box-shadow: 0 0 0 4px rgba(63,111,168,.08);
}

/* =========================================================
   NAVEGACIÓN DE PREGUNTA
========================================================= */

.question-card__footer {
  padding: 14px 20px;
  border-top: 1px solid #e7ecf1 !important;
  background: #f8fafc !important;
}

.question-card__footer > span {
  color: var(--quiz-muted) !important;
}

.question-nav-button {
  min-height: 44px;
  border: 1px solid var(--quiz-line-strong) !important;
  border-radius: 10px;
  color: var(--quiz-ink-soft) !important;
  background: #fff !important;
}

.question-nav-button--primary {
  border-color: var(--quiz-wine) !important;
  color: #fff !important;
  background: var(--quiz-wine) !important;
}

.question-nav-button--primary:hover:not(:disabled) {
  background: var(--quiz-wine-dark) !important;
}

.question-nav-button:disabled {
  opacity: .5;
  cursor: not-allowed;
}

/* =========================================================
   SIDEBAR
========================================================= */

.navigator-card,
.summary-card,
.autosave-card {
  border: 1px solid var(--quiz-line) !important;
  border-radius: 16px;
  background: #fff !important;
  box-shadow: 0 8px 22px rgba(31,48,73,.035);
}

.navigator-card,
.summary-card {
  padding: 17px;
}

.navigator-card__eyebrow {
  color: var(--quiz-gold-dark) !important;
  font-size: .53rem;
  font-weight: 900;
  letter-spacing: .1em;
}

.question-dots {
  gap: 7px;
  margin-top: 12px;
}

.question-dot {
  min-width: 46px;
  min-height: 46px;
  border: 1px solid #dce3ea !important;
  border-radius: 10px;
  color: #6f7c8f !important;
  background: #f8fafc !important;
}

.question-dot--current {
  border-color: #d5aa22 !important;
  color: #624900 !important;
  background: #f0c943 !important;
}

.question-dot--answered {
  border-color: #bfe0cd !important;
  color: var(--quiz-green) !important;
  background: var(--quiz-green-soft) !important;
}

.question-dot--required:not(.question-dot--current):not(.question-dot--answered) {
  box-shadow: inset 0 0 0 1px rgba(217,169,29,.1);
}

.navigator-legend {
  gap: 10px;
  margin-top: 12px;
}

.navigator-legend span {
  color: var(--quiz-muted) !important;
  font-size: .55rem;
}

.legend-box--current {
  background: var(--quiz-gold) !important;
}

.legend-box--answered {
  border-color: var(--quiz-green) !important;
  background: var(--quiz-green-soft) !important;
}

.legend-box--pending {
  border-color: #cfd8e1 !important;
  background: #f8fafc !important;
}

/* =========================================================
   RESUMEN SIDEBAR
========================================================= */

.summary-row {
  padding: 11px 0;
  border-bottom: 1px solid #e9edf2 !important;
}

.summary-row span {
  color: var(--quiz-muted) !important;
}

.summary-row strong {
  color: var(--quiz-gold-dark) !important;
}

.submit-sidebar-button {
  width: 100%;
  min-height: 46px;
  margin-top: 14px;
  border: 1px solid var(--quiz-wine) !important;
  border-radius: 10px;
  color: #fff !important;
  background: var(--quiz-wine) !important;
  box-shadow: 0 8px 20px rgba(159,25,69,.14);
}

.submit-sidebar-button:hover:not(:disabled) {
  background: var(--quiz-wine-dark) !important;
}

.submit-sidebar-button:disabled {
  border-color: #d8dee5 !important;
  color: #9aa4b0 !important;
  background: #edf1f5 !important;
  box-shadow: none;
}

/* =========================================================
   AUTOGUARDADO
========================================================= */

.autosave-card {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 10px;
  align-items: center;
  padding: 14px;
  border-color: #cfe3d8 !important;
  background: var(--quiz-green-soft) !important;
}

.autosave-card > div {
  border-color: #b9ddc8 !important;
  color: var(--quiz-green) !important;
  background: #fff !important;
}

.autosave-card p {
  color: #557565 !important;
}

.autosave-card--error {
  border-color: #efcbd1 !important;
  background: var(--quiz-danger-soft) !important;
}

.autosave-card--error > div {
  color: var(--quiz-danger) !important;
}

/* =========================================================
   MODAL ENTREGA
========================================================= */

.modal-backdrop {
  background: rgba(15,23,42,.55) !important;
  backdrop-filter: blur(12px);
}

.submit-dialog {
  border: 1px solid var(--quiz-line) !important;
  border-radius: 20px;
  color: var(--quiz-ink) !important;
  background: #fff !important;
  box-shadow: 0 30px 80px rgba(15,23,42,.2);
}

.submit-dialog__icon {
  color: #fff !important;
  background: var(--quiz-green) !important;
}

.submit-dialog__eyebrow {
  color: var(--quiz-gold-dark) !important;
}

.submit-dialog h2 {
  color: var(--quiz-ink) !important;
}

.submit-dialog > p {
  color: var(--quiz-muted) !important;
}

.submit-warning {
  border-color: #ead79c !important;
  background: var(--quiz-gold-soft) !important;
}

.submit-warning strong {
  color: var(--quiz-gold-dark) !important;
}

.submit-warning p {
  color: #7c704d !important;
}

.submit-notice {
  border-color: #d7e2ed !important;
  color: #4f6f95 !important;
  background: var(--quiz-blue-soft) !important;
}

.submit-success {
  border-color: #c7e0d2 !important;
  color: var(--quiz-green) !important;
  background: var(--quiz-green-soft) !important;
}

.submit-dialog__actions .button--secondary {
  border-color: var(--quiz-line-strong) !important;
  color: var(--quiz-ink-soft) !important;
  background: #fff !important;
}

.submit-dialog__actions .button--primary {
  border-color: var(--quiz-wine) !important;
  color: #fff !important;
  background: var(--quiz-wine) !important;
}

/* =========================================================
   RESULTADOS
========================================================= */

.result-screen {
  border: 1px solid var(--quiz-line) !important;
  border-radius: 22px;
  background:
    radial-gradient(circle at 90% 8%, rgba(217,169,29,.1), transparent 28%),
    #fff !important;
  box-shadow: 0 14px 36px rgba(31,48,73,.055);
}

.result-screen__eyebrow {
  color: var(--quiz-gold-dark) !important;
}

.result-screen h1,
.result-screen h2 {
  color: var(--quiz-ink) !important;
}

.result-screen > p,
.result-learning-box p,
.result-notice p {
  color: var(--quiz-muted) !important;
}

.result-score > div,
.result-guidance > div,
.result-learning-box,
.result-notice {
  border-color: #e3e8ee !important;
  background: #f8fafc !important;
}

.result-score small,
.result-guidance small,
.result-learning-box > span {
  color: var(--quiz-muted-2) !important;
}

.result-score strong,
.result-guidance strong {
  color: var(--quiz-ink) !important;
}

.result-score__passed {
  color: var(--quiz-green) !important;
}

.result-score__failed {
  color: var(--quiz-danger) !important;
}

.result-learning-box {
  border-color: #d9e5de !important;
  background: var(--quiz-green-soft) !important;
}

.result-learning-box--locked {
  border-color: #e6d495 !important;
  background: var(--quiz-gold-soft) !important;
}

.result-screen__actions .button--primary {
  border-color: var(--quiz-wine) !important;
  color: #fff !important;
  background: var(--quiz-wine) !important;
}

.result-screen__actions .button--secondary {
  border-color: var(--quiz-line-strong) !important;
  color: var(--quiz-ink-soft) !important;
  background: #fff !important;
}

/* =========================================================
   LOADING / ERROR
========================================================= */

.quiz-state {
  border: 1px solid var(--quiz-line) !important;
  border-radius: 18px;
  background: #fff !important;
}

.quiz-state h1,
.quiz-state h2,
.quiz-state strong {
  color: var(--quiz-ink) !important;
}

.quiz-state p {
  color: var(--quiz-muted) !important;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 1000px) {
  .quiz-layout {
    grid-template-columns: 1fr !important;
  }

  .quiz-sidebar {
    position: static !important;
  }

  .navigator-card,
  .summary-card,
  .autosave-card {
    position: static !important;
  }
}

@media (max-width: 760px) {
  .quiz-hero {
    align-items: flex-start;
    flex-direction: column;
    padding: 22px;
  }

  .timer-card {
    width: 100%;
    min-width: 0;
  }

  .question-card__body {
    padding: 20px 17px;
  }

  .question-card__top,
  .question-card__footer {
    padding-inline: 17px;
  }

  .question-card__footer {
    align-items: stretch;
    flex-direction: column;
  }

  .question-nav-button {
    width: 100%;
  }

  .question-dots {
    grid-template-columns: repeat(5, minmax(0,1fr));
  }
}

@media (max-width: 520px) {
  .quiz-topbar {
    align-items: flex-start;
    flex-direction: column;
    gap: 10px;
  }

  .question-dots {
    grid-template-columns: repeat(4, minmax(0,1fr));
  }

  .answer-option {
    align-items: flex-start;
  }
}



/* =========================================================
   V7.4 · QUIZ QUESTION PANEL FIX
   Corrige el bloque oscuro restante usando las clases REALES
   del componente: question-panel, question-header,
   question-content, option-card y question-actions.
========================================================= */

.question-panel {
  overflow: hidden;
  border: 1px solid #dbe3ec !important;
  border-radius: 18px !important;
  background: #ffffff !important;
  box-shadow: 0 10px 28px rgba(31, 48, 73, 0.05) !important;
}

.question-header {
  display: flex;
  gap: 1rem;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px !important;
  border-bottom: 1px solid #e7ecf1 !important;
  background:
    linear-gradient(135deg, #ffffff 0%, #f8fafc 100%) !important;
}

.question-number {
  color: #987000 !important;
  font-size: 0.58rem !important;
  font-weight: 900 !important;
  letter-spacing: 0.11em !important;
}

.required-badge {
  padding: 5px 8px !important;
  border: 1px solid #e4d18d !important;
  border-radius: 999px !important;
  color: #795b00 !important;
  background: #fff8e7 !important;
  font-size: 0.54rem !important;
  font-weight: 900 !important;
}

.question-header > strong {
  color: #667589 !important;
  font-size: 0.67rem !important;
  font-weight: 800 !important;
}

.question-content {
  min-height: 420px;
  padding: clamp(22px, 3vw, 34px) !important;
  background:
    radial-gradient(circle at 96% 5%, rgba(217,169,29,.045), transparent 28%),
    #ffffff !important;
}

.question-content h2 {
  max-width: 880px !important;
  margin: 0 0 18px !important;
  color: #152033 !important;
  font-size: clamp(1.55rem, 3vw, 2.35rem) !important;
  line-height: 1.22 !important;
  letter-spacing: -0.03em !important;
}

.question-hint {
  margin: 0 0 10px !important;
  color: #6f7c8f !important;
  font-size: 0.72rem !important;
  line-height: 1.55 !important;
}

.options-list {
  display: grid;
  gap: 10px !important;
}

.option-card {
  display: grid;
  min-height: 70px !important;
  gap: 12px !important;
  grid-template-columns: auto auto minmax(0, 1fr);
  align-items: center;
  padding: 14px 16px !important;
  border: 1px solid #dfe5ec !important;
  border-radius: 13px !important;
  background: #fbfcfe !important;
  cursor: pointer;
  box-shadow: none !important;
  transition:
    border-color .18s ease,
    background .18s ease,
    box-shadow .18s ease,
    transform .18s ease;
}

.option-card:hover {
  border-color: #c8d4df !important;
  background: #ffffff !important;
  box-shadow: 0 7px 20px rgba(31,48,73,.045) !important;
  transform: translateY(-1px) !important;
}

.option-card--selected {
  border-color: #d7b02f !important;
  background: #fffaf0 !important;
  box-shadow: inset 0 0 0 1px rgba(215,176,47,.12) !important;
}

.option-card input {
  width: 18px !important;
  height: 18px !important;
  accent-color: #9f1945 !important;
}

.option-card__marker {
  display: grid;
  width: 36px !important;
  height: 36px !important;
  place-items: center;
  border: 1px solid #d6dee7 !important;
  border-radius: 50% !important;
  color: #68768a !important;
  background: #ffffff !important;
  font-size: .76rem !important;
  font-weight: 900 !important;
}

.option-card--selected .option-card__marker {
  border-color: #d7b02f !important;
  color: #684d00 !important;
  background: #f3d15d !important;
}

.option-card strong {
  color: #26364f !important;
  font-size: .82rem !important;
  font-weight: 800 !important;
  line-height: 1.45 !important;
}

.text-answer label {
  color: #987000 !important;
}

.text-answer input,
.text-answer textarea {
  border: 1px solid #cbd6e2 !important;
  color: #152033 !important;
  background: #fbfcfe !important;
}

.text-answer input:focus,
.text-answer textarea:focus {
  border-color: #aec0d3 !important;
  background: #fff !important;
  box-shadow: 0 0 0 4px rgba(63,111,168,.08) !important;
}

.unsupported-question {
  border-color: #d6dfe8 !important;
  color: #6f7c8f !important;
  background: #f8fafc !important;
}

/* Footer de navegación */
.question-actions {
  display: grid;
  gap: 12px;
  grid-template-columns: auto 1fr auto;
  align-items: center;
  padding: 14px 20px !important;
  border-top: 1px solid #e7ecf1 !important;
  background: #f8fafc !important;
}

.question-actions__center span {
  color: #6f7c8f !important;
  font-size: .64rem !important;
}

.question-actions .button {
  min-height: 44px !important;
  border-radius: 10px !important;
  font-size: .68rem !important;
  font-weight: 900 !important;
}

.question-actions .button--secondary {
  border: 1px solid #cbd6e2 !important;
  color: #344359 !important;
  background: #ffffff !important;
}

.question-actions .button--primary {
  border: 1px solid #9f1945 !important;
  color: #ffffff !important;
  background: #9f1945 !important;
  box-shadow: 0 8px 18px rgba(159,25,69,.12) !important;
}

.question-actions .button--primary:hover:not(:disabled) {
  background: #7f1237 !important;
}

/* Sidebar real */
.question-sidebar {
  position: sticky;
  top: 1rem;
  display: grid;
  gap: 12px;
}

.question-sidebar .navigator-card,
.question-sidebar .summary-card {
  border: 1px solid #dbe3ec !important;
  background: #ffffff !important;
}

.question-grid {
  display: grid;
  gap: 8px !important;
  grid-template-columns: repeat(5, minmax(0, 1fr));
}

.question-dot {
  min-height: 48px !important;
  border: 1px solid #d8e0e8 !important;
  color: #68768a !important;
  background: #f8fafc !important;
  box-shadow: none !important;
}

.question-dot--current {
  border-color: #d6aa1d !important;
  color: #5e4600 !important;
  background: #f2cc42 !important;
}

.question-dot--answered {
  border-color: #bfe0cd !important;
  color: #2d8a63 !important;
  background: #edf8f3 !important;
}

.question-sidebar .summary-row {
  border-bottom-color: #e8edf2 !important;
}

.question-sidebar .summary-row span {
  color: #6f7c8f !important;
}

.question-sidebar .summary-row strong {
  color: #987000 !important;
}

.question-sidebar .submit-sidebar-button {
  border-color: #9f1945 !important;
  color: #fff !important;
  background: #9f1945 !important;
}

.question-sidebar .submit-sidebar-button:hover:not(:disabled) {
  background: #7f1237 !important;
}

@media (max-width: 760px) {
  .question-content {
    min-height: auto !important;
    padding: 20px 17px !important;
  }

  .question-actions {
    grid-template-columns: 1fr !important;
  }

  .question-actions__center {
    order: -1;
    text-align: left;
  }

  .question-actions .button {
    width: 100%;
  }
}



/* =========================================================
   V7.5 · SUBMIT MODAL FIX
   El modal usa Teleport a <body>, por eso NO hereda las
   variables CSS definidas dentro de .quiz-page.
   Aquí usamos colores directos para asegurar contraste real.
========================================================= */

.modal-backdrop {
  position: fixed !important;
  z-index: 9999 !important;
  inset: 0 !important;
  display: grid !important;
  place-items: center !important;
  padding: 22px !important;
  overflow-y: auto !important;
  background: rgba(15, 23, 42, .56) !important;
  backdrop-filter: blur(12px) !important;
}

.submit-dialog {
  position: relative !important;
  width: min(620px, 100%) !important;
  max-height: calc(100dvh - 44px) !important;
  overflow-y: auto !important;
  padding: 30px !important;
  border: 1px solid #dbe3ec !important;
  border-radius: 22px !important;
  color: #152033 !important;
  background:
    radial-gradient(circle at 95% 3%, rgba(217,169,29,.10), transparent 28%),
    #ffffff !important;
  box-shadow: 0 34px 90px rgba(15, 23, 42, .24) !important;
}

.submit-dialog::before {
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
  width: 122px !important;
  height: 3px !important;
  content: '' !important;
  background: linear-gradient(90deg, #9f1945, #d9a91d) !important;
}

.submit-dialog__icon {
  display: grid !important;
  width: 54px !important;
  height: 54px !important;
  place-items: center !important;
  margin-bottom: 18px !important;
  border: 1px solid #bfe0cd !important;
  border-radius: 15px !important;
  color: #ffffff !important;
  background: #2d8a63 !important;
  box-shadow: 0 8px 20px rgba(45, 138, 99, .15) !important;
  font-size: 1rem !important;
  font-weight: 900 !important;
}

.submit-dialog__eyebrow {
  display: block !important;
  margin-bottom: 6px !important;
  color: #987000 !important;
  font-size: .58rem !important;
  font-weight: 900 !important;
  letter-spacing: .13em !important;
}

.submit-dialog h2 {
  margin: 0 !important;
  color: #152033 !important;
  font-size: clamp(1.75rem, 4vw, 2.45rem) !important;
  line-height: 1.08 !important;
  letter-spacing: -.035em !important;
}

.submit-dialog > p {
  margin: 11px 0 0 !important;
  color: #6f7c8f !important;
  font-size: .78rem !important;
  line-height: 1.65 !important;
}

.submit-dialog > p strong {
  color: #344359 !important;
  font-weight: 900 !important;
}

/* Estados */
.submit-warning,
.submit-notice,
.submit-success {
  margin-top: 18px !important;
  padding: 15px 16px !important;
  border-radius: 13px !important;
}

.submit-warning {
  border: 1px solid #ead79c !important;
  background: #fff8e7 !important;
}

.submit-warning strong {
  display: block !important;
  color: #8a6500 !important;
  font-size: .72rem !important;
}

.submit-warning p {
  margin: 5px 0 0 !important;
  color: #7b704f !important;
  font-size: .65rem !important;
  line-height: 1.5 !important;
}

.submit-notice {
  border: 1px solid #d7e2ed !important;
  color: #456a95 !important;
  background: #eef5fc !important;
  font-size: .7rem !important;
  font-weight: 750 !important;
}

.submit-success {
  border: 1px solid #c7e0d2 !important;
  background: #edf8f3 !important;
}

.submit-success strong {
  display: block !important;
  color: #2d8a63 !important;
  font-size: .78rem !important;
  font-weight: 900 !important;
}

.submit-success p {
  margin: 5px 0 0 !important;
  color: #5c7868 !important;
  font-size: .65rem !important;
  line-height: 1.5 !important;
}

/* Footer de acciones */
.submit-dialog__actions {
  display: grid !important;
  grid-template-columns: 1fr 1.15fr !important;
  gap: 10px !important;
  margin-top: 22px !important;
  padding-top: 18px !important;
  border-top: 1px solid #e7ecf1 !important;
}

.submit-dialog__actions .button {
  display: inline-flex !important;
  min-height: 48px !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 0 17px !important;
  border-radius: 10px !important;
  font-size: .7rem !important;
  font-weight: 900 !important;
  cursor: pointer !important;
  transition:
    transform .18s ease,
    box-shadow .18s ease,
    background .18s ease !important;
}

.submit-dialog__actions .button--secondary {
  border: 1px solid #cbd6e2 !important;
  color: #344359 !important;
  background: #ffffff !important;
}

.submit-dialog__actions .button--secondary:hover:not(:disabled) {
  border-color: #b7c4d2 !important;
  background: #f8fafc !important;
}

.submit-dialog__actions .button--primary {
  border: 1px solid #9f1945 !important;
  color: #ffffff !important;
  background: #9f1945 !important;
  box-shadow: 0 8px 20px rgba(159,25,69,.14) !important;
}

.submit-dialog__actions .button--primary:hover:not(:disabled) {
  background: #7f1237 !important;
  transform: translateY(-1px) !important;
}

.submit-dialog__actions .button:disabled {
  border-color: #d8dee5 !important;
  color: #9aa4b0 !important;
  background: #edf1f5 !important;
  box-shadow: none !important;
  cursor: not-allowed !important;
}

/* Evita que estilos globales de la web pública coloreen el modal */
.submit-dialog,
.submit-dialog * {
  text-shadow: none !important;
}

@media (max-width: 600px) {
  .modal-backdrop {
    align-items: end !important;
    padding: 10px !important;
  }

  .submit-dialog {
    width: 100% !important;
    max-height: 92dvh !important;
    padding: 22px !important;
    border-radius: 20px 20px 14px 14px !important;
  }

  .submit-dialog__actions {
    grid-template-columns: 1fr !important;
  }

  .submit-dialog__actions .button--primary {
    order: -1 !important;
  }
}



/* =========================================================
   V7.6 · RESULT NEXT STEP · PREMIUM LIGHT
   Corrige el último bloque oscuro de la pantalla de resultado.
========================================================= */

.result-next-step {
  width: min(900px, 100%) !important;
  margin-top: 1rem !important;
  padding: clamp(1.15rem, 3vw, 1.5rem) !important;
  border: 1px solid #dbe3ec !important;
  border-radius: 18px !important;
  background:
    radial-gradient(circle at 96% 4%, rgba(217,169,29,.08), transparent 32%),
    #ffffff !important;
  box-shadow: 0 10px 28px rgba(31, 48, 73, .045) !important;
  text-align: left !important;
}

.result-next-step__copy > span {
  color: #987000 !important;
  font-size: .58rem !important;
  font-weight: 900 !important;
  letter-spacing: .12em !important;
}

.result-next-step__copy h2 {
  margin: .35rem 0 0 !important;
  color: #152033 !important;
  font-size: clamp(1.35rem, 3vw, 1.85rem) !important;
  line-height: 1.14 !important;
  letter-spacing: -.025em !important;
}

.result-next-step__copy p {
  max-width: 760px !important;
  margin: .5rem 0 0 !important;
  color: #6f7c8f !important;
  font-size: .72rem !important;
  line-height: 1.6 !important;
}

.result-next-step__actions {
  display: grid !important;
  gap: .7rem !important;
  grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
  margin-top: 1.05rem !important;
}

.result-action {
  display: grid !important;
  min-height: 88px !important;
  gap: .75rem !important;
  grid-template-columns: auto minmax(0,1fr) auto !important;
  align-items: center !important;
  padding: .9rem !important;
  border: 1px solid #dfe5ec !important;
  border-radius: 13px !important;
  color: #152033 !important;
  background: #f8fafc !important;
  text-decoration: none !important;
  box-shadow: none !important;
  transition:
    border-color .18s ease,
    background .18s ease,
    box-shadow .18s ease,
    transform .18s ease !important;
}

.result-action:hover {
  border-color: #c9d5e0 !important;
  background: #ffffff !important;
  box-shadow: 0 7px 20px rgba(31,48,73,.045) !important;
  transform: translateY(-1px) !important;
}

.result-action--primary {
  border-color: #e5cf82 !important;
  background: #fff8e7 !important;
}

.result-action--primary:hover {
  border-color: #d7b02f !important;
  background: #fffaf0 !important;
}

.result-action__icon {
  display: grid !important;
  width: 42px !important;
  height: 42px !important;
  place-items: center !important;
  border: 1px solid #e4cf86 !important;
  border-radius: 12px !important;
  color: #987000 !important;
  background: #fff8e7 !important;
  font-weight: 900 !important;
}

.result-action--primary .result-action__icon {
  border-color: #d8b22e !important;
  color: #775900 !important;
  background: #f3d15d !important;
}

.result-action small,
.result-action strong {
  display: block !important;
}

.result-action small {
  margin-bottom: .2rem !important;
  color: #8b98aa !important;
  font-size: .52rem !important;
  font-weight: 900 !important;
  letter-spacing: .08em !important;
}

.result-action strong {
  color: #26364f !important;
  font-size: .78rem !important;
  line-height: 1.35 !important;
}

.result-action b {
  color: #9f1945 !important;
  font-size: .9rem !important;
}

.result-action--primary b {
  color: #987000 !important;
}

@media (max-width: 760px) {
  .result-next-step__actions {
    grid-template-columns: 1fr !important;
  }

  .result-action {
    min-height: 76px !important;
  }
}


/* =========================================================
   QUIZ V8 · EXPERIENCIAS INTERACTIVAS
========================================================= */

.matching-question,
.ordering-question {
  display: grid;
  gap: 14px;
}

.matching-question__list,
.ordering-question__list {
  display: grid;
  gap: 9px;
}

.matching-question__row {
  display: grid;
  grid-template-columns:
    minmax(0,1fr)
    34px
    minmax(0,1fr);
  gap: 10px;
  align-items: center;
  min-height: 68px;
  padding: 12px;
  border: 1px solid #dbe3ec;
  border-radius: 13px;
  background: #fff;
}

.matching-question__row > strong {
  color: #152033;
  font-size: .82rem;
}

.matching-question__row > span {
  color: #b18400;
  text-align: center;
  font-weight: 900;
}

.matching-question__row select {
  width: 100%;
  min-height: 44px;
  padding: 0 10px;
  border: 1px solid #cbd6e2;
  border-radius: 10px;
  color: #344359;
  background: #f8fafc;
  font: inherit;
}

.matching-question__row select:focus {
  border-color: #9f1945;
  outline: none;
  box-shadow:
    0 0 0 4px
    rgba(159,25,69,.08);
}

.ordering-question__item {
  display: grid;
  grid-template-columns:
    40px
    minmax(0,1fr)
    auto;
  gap: 12px;
  align-items: center;
  min-height: 66px;
  padding: 11px 12px;
  border: 1px solid #dbe3ec;
  border-radius: 13px;
  background: #fff;
}

.ordering-question__item > span {
  display: grid;
  width: 36px;
  height: 36px;
  place-items: center;
  border-radius: 10px;
  color: #9f1945;
  background: #fff1f5;
  font-size: .7rem;
  font-weight: 900;
}

.ordering-question__item > strong {
  color: #152033;
  font-size: .82rem;
}

.ordering-question__item > div {
  display: flex;
  gap: 6px;
}

.ordering-question__item button {
  display: grid;
  width: 38px;
  height: 38px;
  place-items: center;
  border: 1px solid #d3dde8;
  border-radius: 10px;
  color: #344359;
  background: #f8fafc;
  cursor: pointer;
}

.ordering-question__item button:hover:not(:disabled) {
  border-color: #9f1945;
  color: #9f1945;
  background: #fff1f5;
}

.ordering-question__item button:disabled {
  opacity: .35;
  cursor: not-allowed;
}

@media (max-width: 650px) {
  .matching-question__row {
    grid-template-columns: 1fr;
  }

  .matching-question__row > span {
    transform: rotate(90deg);
  }

  .ordering-question__item {
    grid-template-columns:
      36px
      minmax(0,1fr);
  }

  .ordering-question__item > div {
    grid-column: 1 / -1;
    justify-content: flex-end;
  }

  .ordering-question__item button {
    width: 46px;
    height: 42px;
  }
}



/* =========================================================
   QUIZ V9 · INTERACCIÓN PREMIUM / ACCESIBILIDAD
========================================================= */
.question-format-badge {
  display: inline-flex; align-items: center; min-height: 26px; padding: 0 9px;
  border: 1px solid #dbe3ec; border-radius: 999px; color: #516177;
  background: #f8fafc; font-size: .58rem; font-weight: 900; letter-spacing: .05em;
}

.audio-experience {
  display: grid; grid-template-columns: 56px minmax(0,1fr); gap: 16px; align-items: start;
  padding: 18px; border: 1px solid #d8e1eb; border-radius: 16px;
  background: linear-gradient(135deg,#fff 0%,#f8fafc 100%);
  box-shadow: 0 10px 28px rgba(31,48,73,.05);
}
.audio-experience__icon {
  display: grid; width: 56px; height: 56px; place-items: center; border-radius: 15px;
  color: #fff; background: #9f1945; font-size: 1.45rem; font-weight: 900;
}
.audio-experience__content { display: grid; gap: 7px; min-width: 0; }
.audio-experience__content > span { color:#987000; font-size:.58rem; font-weight:900; letter-spacing:.1em; }
.audio-experience__content > strong { color:#152033; font-size:.88rem; }
.audio-experience__content audio { width:100%; margin-top:4px; }
.audio-experience__content small { color:#718096; font-size:.7rem; }

.interactive-question { gap: 16px !important; }
.interactive-question__intro {
  display:flex; justify-content:space-between; gap:16px; align-items:flex-start;
  padding:14px 16px; border:1px solid #e0e7ef; border-radius:14px; background:#f8fafc;
}
.interactive-question__intro > div > span { color:#987000; font-size:.58rem; font-weight:900; letter-spacing:.1em; }
.interactive-question__intro .question-hint { margin:.3rem 0 0; color:#5f6f84; }
.interactive-question__intro > strong { flex:0 0 auto; padding:6px 9px; border-radius:999px; color:#9f1945; background:#fff1f5; font-size:.66rem; }

.matching-question__row {
  grid-template-columns: 34px minmax(120px,.9fr) 28px minmax(180px,1.2fr) 34px !important;
  min-height:72px !important; padding:12px 13px !important; transition:border-color .18s ease,box-shadow .18s ease,background .18s ease;
}
.matching-question__row--complete { border-color:#bfe0cd !important; background:#fbfffd !important; box-shadow:0 8px 22px rgba(45,138,99,.055); }
.matching-question__number { display:grid; width:30px; height:30px; place-items:center; border-radius:9px; color:#9f1945 !important; background:#fff1f5; font-size:.65rem; font-weight:900; }
.matching-question__arrow { color:#b18400 !important; font-size:1rem; }
.matching-question__row select { min-height:46px !important; background:#fff !important; cursor:pointer; }
.matching-question__row select option:disabled { color:#a2acb9; }
.matching-question__clear {
  display:grid; width:32px; height:32px; place-items:center; border:1px solid #d9e1ea; border-radius:9px;
  color:#7b8798; background:#fff; cursor:pointer; font-size:1rem;
}
.matching-question__clear:hover { border-color:#be4856; color:#be4856; background:#fff5f6; }

.ordering-question__item {
  grid-template-columns:40px 26px minmax(0,1fr) auto !important; cursor:grab; user-select:none;
  transition:transform .16s ease,border-color .16s ease,box-shadow .16s ease,opacity .16s ease;
}
.ordering-question__item:hover { border-color:#c7d3e0; box-shadow:0 8px 22px rgba(31,48,73,.055); }
.ordering-question__item--dragging { opacity:.5; transform:scale(.985); }
.ordering-question__item:active { cursor:grabbing; }
.ordering-question__position { background:#fff1f5 !important; color:#9f1945 !important; }
.ordering-question__handle { color:#9ba8b8; font-size:1rem; letter-spacing:-.2em; }
.ordering-question__controls { display:flex; gap:6px; }
.ordering-question__footer { display:flex; justify-content:flex-end; gap:10px; flex-wrap:wrap; padding-top:4px; }
.interactive-secondary,.interactive-primary {
  min-height:42px; padding:0 14px; border-radius:11px; font:inherit; font-size:.7rem; font-weight:900; cursor:pointer;
}
.interactive-secondary { border:1px solid #cdd8e4; color:#44546a; background:#fff; }
.interactive-primary { border:1px solid #9f1945; color:#fff; background:#9f1945; box-shadow:0 8px 18px rgba(159,25,69,.12); }
.interactive-primary:hover { background:#7f1237; }
.interactive-secondary:hover { background:#f8fafc; }

@media (max-width: 720px) {
  .audio-experience { grid-template-columns:1fr; }
  .audio-experience__icon { width:48px; height:48px; }
  .interactive-question__intro { flex-direction:column; }
  .matching-question__row { grid-template-columns:34px minmax(0,1fr) 34px !important; }
  .matching-question__row > strong { grid-column:2 / 3; }
  .matching-question__arrow { grid-column:1 / 2; grid-row:2; transform:rotate(90deg); }
  .matching-question__row select { grid-column:2 / 3; }
  .matching-question__clear { grid-column:3 / 4; grid-row:2; }
  .ordering-question__item { grid-template-columns:36px 22px minmax(0,1fr) !important; }
  .ordering-question__controls { grid-column:1 / -1; justify-content:flex-end; }
  .ordering-question__footer { display:grid; grid-template-columns:1fr; }
  .interactive-secondary,.interactive-primary { width:100%; }
}


/* =========================================================
   V9.2 · RESULTADO PREMIUM LIGHT
   Pantalla de resultados sin bloques oscuros.
========================================================= */

.result-screen--premium {
  width: min(1120px, 100%) !important;
  min-height: 0 !important;
  margin: 0 auto !important;
  padding: clamp(1.25rem, 3vw, 2.35rem) !important;
  gap: 1.15rem !important;
  place-items: stretch !important;
  align-content: start !important;
  border: 1px solid #dce4ed !important;
  border-radius: 26px !important;
  background:
    radial-gradient(circle at 92% 5%, rgba(217,169,29,.09), transparent 29%),
    radial-gradient(circle at 8% 0%, rgba(159,25,69,.045), transparent 24%),
    #ffffff !important;
  box-shadow: 0 20px 50px rgba(31,48,73,.07) !important;
  text-align: left !important;
}

.result-hero {
  display: grid;
  justify-items: center;
  gap: .65rem;
  padding: .5rem 0 1.1rem;
  text-align: center;
}

.result-hero__status {
  display: grid;
  width: 62px;
  height: 62px;
  place-items: center;
  margin-bottom: .15rem;
  border: 1px solid #d6e5dc;
  border-radius: 50%;
  color: #2d8a63;
  background: #f3fbf6;
  box-shadow: 0 8px 20px rgba(45,138,99,.08);
  font-size: 1.45rem;
  font-weight: 900;
}

.result-hero__status--reinforce {
  border-color: #f0d2d7;
  color: #be4856;
  background: #fff7f8;
  box-shadow: 0 8px 20px rgba(190,72,86,.06);
}

.result-hero__status--pending {
  border-color: #eadcae;
  color: #987000;
  background: #fffaf0;
  box-shadow: 0 8px 20px rgba(217,169,29,.07);
}

.result-screen--premium .result-screen__eyebrow {
  color: #9b7300 !important;
  font-size: .64rem !important;
  font-weight: 900 !important;
  letter-spacing: .16em !important;
}

.result-screen--premium h1 {
  max-width: 820px !important;
  color: #152033 !important;
  font-size: clamp(2.15rem, 5vw, 3.75rem) !important;
  line-height: 1.02 !important;
  letter-spacing: -.045em !important;
}

.result-screen--premium > .result-hero > p {
  max-width: 720px;
  margin: 0;
  color: #6f7c8f !important;
  font-size: .9rem !important;
  line-height: 1.65 !important;
}

.result-score--premium {
  width: 100% !important;
  gap: .85rem !important;
  margin-top: 0 !important;
}

.result-score--premium > article {
  display: flex;
  min-height: 104px;
  gap: .85rem;
  align-items: center;
  padding: 1rem 1.1rem !important;
  border: 1px solid #dfe6ee !important;
  border-radius: 17px !important;
  background: linear-gradient(145deg,#fff,#f8fafc) !important;
  box-shadow: 0 8px 22px rgba(31,48,73,.035);
}

.result-score__visual {
  display: grid;
  width: 44px;
  height: 44px;
  flex: 0 0 44px;
  place-items: center;
  border-radius: 13px;
  color: #9f1945;
  background: #fff1f5;
  font-size: .92rem;
  font-weight: 900;
}

.result-score--premium small {
  margin-bottom: .3rem !important;
  color: #7c899b !important;
  font-size: .58rem !important;
  letter-spacing: .08em;
}

.result-score--premium strong {
  color: #152033 !important;
  font-size: 1.35rem !important;
}

.result-score--premium strong em {
  color: #7d8999;
  font-size: .82rem;
  font-style: normal;
  font-weight: 800;
}

.result-score--premium .result-score__passed { color: #2d8a63 !important; }
.result-score--premium .result-score__failed { color: #be4856 !important; }

.result-guidance--premium {
  display: grid !important;
  width: 100% !important;
  gap: .85rem !important;
  grid-template-columns: repeat(3,minmax(0,1fr)) !important;
}

.result-guidance--premium > article {
  display: flex;
  min-height: 78px;
  gap: .75rem;
  align-items: center;
  padding: .9rem 1rem;
  border: 1px solid #e0e7ef;
  border-radius: 15px;
  background: #fbfcfe;
}

.result-guidance--premium > article > span {
  display: grid;
  width: 34px;
  height: 34px;
  flex: 0 0 34px;
  place-items: center;
  border-radius: 10px;
  color: #987000;
  background: #fff8e7;
  font-size: .58rem;
  font-weight: 900;
}

.result-guidance--premium small,
.result-guidance--premium strong { display: block; }
.result-guidance--premium small { color:#8692a2 !important; font-size:.55rem !important; letter-spacing:.07em; }
.result-guidance--premium strong { margin-top:.25rem; color:#223047 !important; font-size:.8rem !important; }

.result-next-step--premium {
  width: 100% !important;
  padding: clamp(1.1rem,2.5vw,1.45rem) !important;
  border-color: #ecd7df !important;
  background:
    radial-gradient(circle at 100% 0%,rgba(159,25,69,.055),transparent 35%),
    #fffafb !important;
  box-shadow: none !important;
}

.result-next-step--premium .result-next-step__copy > span { color:#9f1945 !important; }
.result-next-step--premium .result-next-step__copy h2 { color:#152033 !important; }
.result-next-step--premium .result-next-step__copy p { color:#67768a !important; font-size:.8rem !important; }

.result-next-step--premium .result-action {
  min-height: 90px !important;
  border-color: #e1e7ee !important;
  color: #152033 !important;
  background: rgba(255,255,255,.88) !important;
}
.result-next-step--premium .result-action:hover {
  border-color: #d2bcc5 !important;
  background: #fff !important;
  box-shadow: 0 8px 20px rgba(31,48,73,.045) !important;
}
.result-next-step--premium .result-action--primary {
  border-color: #e6b9c8 !important;
  background: #fff2f6 !important;
}
.result-next-step--premium .result-action__icon {
  border-color: #efccd7 !important;
  color: #9f1945 !important;
  background: #fff !important;
}
.result-next-step--premium .result-action small { color:#9a6979 !important; }
.result-next-step--premium .result-action strong { color:#172033 !important; }
.result-next-step--premium .result-action b { color:#9f1945 !important; }

.result-learning-summary--premium {
  width: 100% !important;
  gap: 1rem !important;
  padding: clamp(1.1rem,2.7vw,1.5rem) !important;
  border: 1px solid #dde5ed !important;
  border-radius: 18px !important;
  background: #ffffff !important;
  box-shadow: 0 10px 26px rgba(31,48,73,.035) !important;
}

.result-learning-summary--premium.result-learning-summary--excellent {
  border-color: #cde3d5 !important;
  background: linear-gradient(145deg,#fff,#f5fbf7) !important;
}
.result-learning-summary--premium.result-learning-summary--good {
  border-color: #e7ddbd !important;
  background: linear-gradient(145deg,#fff,#fffaf0) !important;
}
.result-learning-summary--premium.result-learning-summary--reinforce {
  border-color: #edd3d8 !important;
  background: linear-gradient(145deg,#fff,#fff7f8) !important;
}

.result-learning-summary--premium .result-learning-summary__icon {
  width: 52px !important;
  height: 52px !important;
  border-color: #e4c6d0 !important;
  color: #9f1945 !important;
  background: rgba(255,255,255,.9);
}
.result-learning-summary--premium.result-learning-summary--excellent .result-learning-summary__icon {
  border-color:#b9ddc7 !important; color:#2d8a63 !important; background:#fff !important;
}
.result-learning-summary--premium.result-learning-summary--good .result-learning-summary__icon {
  border-color:#e6d395 !important; color:#987000 !important; background:#fff !important;
}
.result-learning-summary--premium.result-learning-summary--reinforce .result-learning-summary__icon {
  border-color:#ecc3ca !important; color:#be4856 !important; background:#fff !important;
}

.result-learning-summary--premium span { color:#9f1945 !important; }
.result-learning-summary--premium h2 { color:#152033 !important; margin-top:.3rem !important; }
.result-learning-summary--premium p { color:#637287 !important; font-size:.8rem !important; line-height:1.65 !important; }

.result-learning-summary__tips {
  display: flex;
  gap: .5rem;
  flex-wrap: wrap;
  margin-top: .9rem;
}
.result-learning-summary__tips > span {
  display: inline-flex;
  min-height: 30px;
  align-items: center;
  padding: 0 .75rem;
  border: 1px solid #e1e7ee;
  border-radius: 999px;
  color: #596a80 !important;
  background: #fff;
  font-size: .6rem !important;
  letter-spacing: 0 !important;
}

.result-practice-card {
  display: flex;
  width: 100%;
  gap: 1rem;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.15rem;
  border: 1px solid #dbe6df;
  border-radius: 16px;
  background: #f7fcf9;
}
.result-practice-card > div > span { color:#2d8a63; font-size:.57rem; font-weight:900; letter-spacing:.09em; }
.result-practice-card strong { display:block; margin-top:.22rem; color:#152033; font-size:.9rem; }
.result-practice-card p { margin:.25rem 0 0; color:#6d7b8d; font-size:.72rem; }
.result-practice-card--locked { border-color:#e8ddbb; background:#fffaf0; }
.result-practice-card--locked > div > span { color:#987000; }

.result-screen__footer {
  display: flex;
  width: 100%;
  gap: .75rem;
  align-items: center;
  justify-content: space-between;
  padding-top: .3rem;
}
.result-screen__footer .button { min-height:46px; }

.result-notice--premium {
  display:flex;
  width:100% !important;
  gap:.8rem;
  align-items:center;
  text-align:left;
  border-color:#e3e8ee !important;
  background:#f8fafc !important;
}
.result-notice--premium > span {
  display:grid; width:40px; height:40px; flex:0 0 40px; place-items:center;
  border-radius:12px; color:#2d8a63; background:#edf8f1; font-weight:900;
}
.result-notice--premium p { margin:.25rem 0 0; }

@media (max-width: 860px) {
  .result-score--premium,
  .result-guidance--premium,
  .result-next-step--premium .result-next-step__actions {
    grid-template-columns: 1fr !important;
  }
  .result-score--premium > article { min-height:82px; }
}

@media (max-width: 620px) {
  .result-screen--premium { padding:1rem !important; border-radius:20px !important; }
  .result-learning-summary--premium { grid-template-columns:1fr !important; }
  .result-practice-card,
  .result-screen__footer { align-items:stretch; flex-direction:column; }
  .result-practice-card .button,
  .result-screen__footer .button { width:100%; justify-content:center; }
}

</style>
